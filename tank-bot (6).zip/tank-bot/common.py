"""Общие помощники: клавиатуры, права, уведомления, закрытие заданий, баллы, Guard."""
import asyncio
import logging
import re
from typing import Optional

from aiogram import BaseMiddleware
from aiogram.exceptions import (TelegramAPIError, TelegramBadRequest, TelegramForbiddenError,
                                TelegramRetryAfter)
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message,
                           ReplyParameters)

import config
import db
import logic
import perms
import tasks_filter as tf

log = logging.getLogger("tank-bot")
_bot = None
MAX_TEXT = getattr(config, "MAX_TEXT", 4000)   # бот не падает, даже если константы нет в config.py


class Auth(StatesGroup):
    password = State()


AUTH_STATE = "Auth:password"
HOME = ("🏠 Меню", "menu")


def set_bot(bot) -> None:
    global _bot
    _bot = bot


def get_bot():
    return _bot


# --- Текст и клавиатуры ---------------------------------------------------------------
def clip(text, limit: int = MAX_TEXT) -> str:
    text = str(text)
    return text if len(text) <= limit else text[: limit - 1] + "…"


def preview(text: str, n: int = 40) -> str:
    line = (text or "").strip().replace("\n", " ")
    return line if len(line) <= n else line[: n - 1] + "…"


def kb(*rows) -> InlineKeyboardMarkup:
    """kb([("Текст", "callback")], [("Ссылка", "https://...")]) — строки кнопок."""
    out = []
    for row in rows:
        buttons = []
        for text, data in row:
            if data.startswith(("http://", "https://", "tg://")):
                buttons.append(InlineKeyboardButton(text=text, url=data))
            else:
                buttons.append(InlineKeyboardButton(text=text, callback_data=data))
        out.append(buttons)
    return InlineKeyboardMarkup(inline_keyboard=out)


def pager_row(prefix: str, page: int, total: int, size: int) -> list:
    row = []
    if page > 0:
        row.append(("◀️", f"{prefix}:{page - 1}"))
    if (page + 1) * size < total:
        row.append(("▶️", f"{prefix}:{page + 1}"))
    return row


def fmt_user(u: Optional[dict]) -> str:
    if not u:
        return "—"
    name = u.get("name") or str(u["id"])
    return f"{name} (@{u['username']})" if u.get("username") else name


def pos_label(pos: Optional[str]) -> str:
    return perms.POS_NAMES.get(pos, "не выбрана")


def status_label(status: str) -> str:
    return perms.STATUSES.get(status, status)


def err_text(e: Exception) -> str:
    return getattr(e, "message", None) or str(e)


def is_gone(e: Exception) -> bool:
    """Ошибка Telegram означает «сообщения больше нет»."""
    s = str(e).lower()
    return ("message" in s and "not found" in s) or "message_id_invalid" in s


async def show(target, text: str, markup=None) -> None:
    """Показать экран: у callback редактирует сообщение, у message — отвечает новым."""
    text = clip(text)
    bot = get_bot()
    if isinstance(target, CallbackQuery):
        msg = target.message
        if msg is None:
            await bot.send_message(target.from_user.id, text, reply_markup=markup)
            return
        try:
            await bot.edit_message_text(text, chat_id=msg.chat.id, message_id=msg.message_id,
                                        reply_markup=markup)
        except TelegramBadRequest as e:
            if "not modified" in str(e).lower():
                return
            await bot.send_message(msg.chat.id, text, reply_markup=markup)
    else:
        await target.answer(text, reply_markup=markup)


async def safe_send(chat_id: int, text: str, **kwargs) -> Optional[Message]:
    bot = get_bot()
    for attempt in range(2):
        try:
            return await bot.send_message(chat_id, clip(text), **kwargs)
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
        except (TelegramForbiddenError, TelegramBadRequest) as e:
            log.warning("Не удалось отправить в %s: %s", chat_id, err_text(e))
            return None
        except TelegramAPIError as e:
            log.warning("Ошибка Telegram при отправке в %s: %s", chat_id, err_text(e))
            return None
    return None


async def send_rich(chat_id: int, text: str, photo=None, markup=None, thread=None):
    """Отправка текста, при необходимости — с фото. Фото уходит С ПОДПИСЬЮ (не голым файлом).
    Подпись в Telegram — до 1024 символов: длинный текст добавляется следующим сообщением."""
    kwargs = {"message_thread_id": thread} if thread else {}
    if not photo:
        return await safe_send(chat_id, text, reply_markup=markup, **kwargs)
    long_text = len(text) > 1000
    caption = text[:999] + "…" if long_text else text
    msg = None
    for _ in range(2):
        try:
            msg = await get_bot().send_photo(chat_id, photo, caption=caption, reply_markup=markup, **kwargs)
            break
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
        except TelegramAPIError as e:
            log.warning("Не удалось отправить фото в %s: %s", chat_id, err_text(e))
            return None
    if msg is None:
        return None
    if long_text:
        await safe_send(chat_id, "…продолжение подписи:\n\n" + text[999:], **kwargs)
    return msg


async def notify(uid: int, text: str, markup=None) -> bool:
    return await safe_send(uid, text, reply_markup=markup) is not None


async def notify_owner(text: str) -> None:
    for oid in db.owner_ids():
        await notify(oid, text)


async def send_to_all(ids, text: str, markup=None) -> int:
    sent = 0
    for uid in ids:
        if await notify(uid, text, markup):
            sent += 1
        await asyncio.sleep(0.05)
    return sent


# --- Права ---------------------------------------------------------------------------------
def has_perm(uid: int, perm: str) -> bool:
    u = db.get_user(uid)
    if not u or u["banned"] or not u["role"]:
        return False
    if u["role"] == "owner":
        return True
    if perm == "owner":
        return False
    return u["role"] == "admin" and perm in db.perms_of(u)


async def need(event, perm: str) -> bool:
    """Проверка разрешения. Если нет — отвечает понятной ошибкой и возвращает False."""
    if has_perm(event.from_user.id, perm):
        return True
    if perm == "owner":
        text = "⛔ Эта функция доступна только владельцу."
    else:
        text = f"⛔ Нет разрешения: «{perms.PERMS.get(perm, perm)}». Обратитесь к владельцу."
    if isinstance(event, CallbackQuery):
        await event.answer(text, show_alert=True)
    else:
        await event.answer(text)
    return False


def user_rank(u: Optional[dict]) -> int:
    return perms.rank(u["role"], u["admin_level"]) if u else 0


def can_manage(actor_id: int, target_id: int) -> bool:
    """Менять и банить можно только тех, кто ниже по уровню."""
    if actor_id == target_id:
        return False
    return user_rank(db.get_user(actor_id)) > user_rank(db.get_user(target_id))


def is_staff(uid: int) -> bool:
    u = db.get_user(uid)
    return bool(u and not u["banned"] and u["role"] in ("admin", "owner"))


# --- Шкала до повышения -----------------------------------------------------------------------------
def progress_line(u: dict) -> str:
    """«До статуса Участник: 4/10 баллов» + полоска и сколько осталось. Считается по текущим баллам."""
    if u["status"] == "owner":
        return ""
    lad = db.ladder()
    cur = logic.status_rank(u["status"])
    for st in perms.STATUS_ORDER[1:]:
        need = lad[st]
        if logic.status_rank(st) > cur and u["points"] < need:
            left = need - u["points"]
            pct = int(u["points"] * 100 / need) if need else 100
            return (f"📈 До статуса {status_label(st)}: {u['points']}/{need} баллов\n"
                    f"{logic.progress_bar(u['points'], need)} {pct}% · осталось {left} {logic.points_word(left)} до повышения")
    return "🏆 Вы достигли высшего статуса!"


# --- Три разных меню: участник / админ / владелец --------------------------------------------------------
def participant_menu(uid: int, staff: bool = False):
    u = db.get_user(uid)
    text = (f"🏠 Меню участника\n\n👤 {fmt_user(u)}\n💼 Должность: {pos_label(u['pos'])}\n"
            f"{status_label(u['status'])} · баллов: {u['points']}")
    prog = progress_line(u)
    if prog:
        text += "\n\n" + prog
    rows = [[("📋 Задания", "tasks"), ("📚 Материалы", "mat")],
            [("📤 Мои работы", "mywk"), ("📢 Объявления", "ann")],
            [("👤 Профиль", "prof"), ("💼 Должность", "pos")]]
    for m in db.pinned_materials():
        if db.material_visible(m, u):
            rows.append([(f"📌 {preview(m['title'], 40)}", f"matv:{m['id']}")])
    if staff:
        rows.append([("🛠 Назад в панель", "menu")])
    return text, kb(*rows)


def staff_menu(uid: int):
    """Меню админа и владельца — крупные разделы; кнопки раздела открываются внутри."""
    u = db.get_user(uid)
    if u["role"] == "owner":
        who = "👑 Владелец"
    else:
        who = f"🛠 Админ · {perms.ADMIN_LEVELS.get(u['admin_level'], 'младший').lower()} уровень"
    text = f"{who}\n👤 {fmt_user(u)}\n"
    st = db.stats()
    if has_perm(uid, "works_review"):
        text += f"\n📥 Ждут проверки: {st['works_pending']}"
    if has_perm(uid, "tasks_close"):
        text += f"\n📌 Активных заданий: {st['tasks_active']} · идёт приём работ: {st['tasks_waiting']}"
    text += "\n\nВыберите раздел:"
    buttons = [(title, f"sec:{key}") for key, title, items in perms.SECTIONS
               if any(has_perm(uid, p) for _, _, p in items)]
    rows = [buttons[i:i + 2] for i in range(0, len(buttons), 2)]
    rows.append([("🙋 Меню участника", "pmenu")])
    if not buttons:
        text += "\n\n⚠️ У вас пока нет разрешений — обратитесь к владельцу."
    return text, kb(*rows)


def section_screen(uid: int, key: str):
    """Экран раздела: все кнопки, связанные с ним (по разрешениям)."""
    for k, title, items in perms.SECTIONS:
        if k == key:
            rows = [[(label, data)] for label, data, perm in items if has_perm(uid, perm)]
            if not rows:
                return None
            rows.append([("🏠 Меню", "menu")])
            return title, kb(*rows)
    return None


def main_menu(uid: int):
    u = db.get_user(uid)
    return staff_menu(uid) if u["role"] in ("admin", "owner") else participant_menu(uid)


async def show_menu(target, uid: int, prefix: str = "") -> None:
    text, markup = main_menu(uid)
    await show(target, (prefix + "\n\n" if prefix else "") + text, markup)


# --- Баллы ------------------------------------------------------------------------------------------
async def award(uid: int, points: int, reason: str = "", notify_user: bool = True) -> tuple:
    """Начислить/снять баллы. Повышение статуса автоматическое, понижения нет.
    Возвращает (новая сумма, новый статус или None). Уведомление содержит шкалу до повышения."""
    u = db.get_user(uid)
    if not u:
        return 0, None
    total = max(0, u["points"] + points)
    db.set_user(uid, points=total)
    promoted = None
    if u["status"] != "owner":
        target = logic.status_for_points(total, db.ladder())
        if logic.status_rank(target) > logic.status_rank(u["status"]):
            db.set_user(uid, status=target)
            promoted = target
    if notify_user:
        text = f"{'➕' if points >= 0 else '➖'} {abs(points)} {logic.points_word(points)}"
        if reason:
            text += f"\nПричина: {reason}"
        text += f"\nВсего баллов: {total}"
        if promoted:
            text += f"\n🎉 Новый статус: {status_label(promoted)}!"
        prog = progress_line(db.get_user(uid))
        if prog:
            text += "\n\n" + prog
        if points < 0:
            text += "\n\n" + db.random_phrase()
        await notify(uid, text)
    return total, promoted


# --- Задания: публикация, закрытие, удаление, проверка ---------------------------------------------------
def task_audience(t: dict) -> list:
    return db.audience("pos", t["pos"]) if t["pos"] else db.audience("all")


def task_kb(tid: int):
    return kb([("✅ Выполнено", f"tdone:{tid}"), ("❌ Не действительно", f"tcancel:{tid}")])


def prepare_task(text: str, pos) -> tuple:
    """Добавляет метку aid<номер>_<код>. Возвращает (aid, текст с меткой)."""
    aid = db.next_aid()
    return aid, f"{tf.make_label(aid, pos)}\n{text}"


async def publish_task(text: str, aid, pos, photo=None) -> tuple:
    """Опубликовать задание в группе (с фото — фото с подписью). Возвращает (id задания или None, ошибка)."""
    chat, thread = db.place()
    if not chat:
        return None, "Место публикации не задано. Раздел «📌 Задания» → «📍 Место публикации»."
    if photo and len(text) > 1024:
        return None, (f"С фото текст задания не может быть длиннее 1024 символов (сейчас {len(text)}). "
                      f"Сократите текст.")
    tid = db.add_task(text, aid, pos, chat, thread, None, "bot", photo)
    try:
        if photo:
            msg = await get_bot().send_photo(chat, photo, caption=text, message_thread_id=thread,
                                             reply_markup=task_kb(tid))
        else:
            msg = await get_bot().send_message(chat, text, message_thread_id=thread, reply_markup=task_kb(tid))
    except TelegramAPIError as e:
        db.ex("DELETE FROM tasks WHERE id=?", (tid,))
        return None, (f"Не удалось опубликовать задание: {err_text(e)}. Проверьте, что бот состоит в группе, "
                      f"может писать в выбранную тему и является админом.")
    db.set_task(tid, msg_id=msg.message_id)
    return tid, ""


async def _mark(t: dict, note: str) -> None:
    """Пометка в группе: свои сообщения редактируем, на чужие отвечаем (или правим прошлую пометку)."""
    bot = get_bot()
    try:
        if t["src"] == "bot":
            if t.get("photo"):
                base = clip(t["text"], max(0, 1024 - len(note) - 2))
                await bot.edit_message_caption(chat_id=t["chat_id"], message_id=t["msg_id"],
                                               caption=f"{base}\n\n{note}", reply_markup=None)
            else:
                await bot.edit_message_text(clip(t["text"] + "\n\n" + note), chat_id=t["chat_id"],
                                            message_id=t["msg_id"], reply_markup=None)
        elif t["note_msg"]:
            await bot.edit_message_text(note, chat_id=t["chat_id"], message_id=t["note_msg"])
        else:
            msg = await bot.send_message(
                t["chat_id"], note, message_thread_id=t["thread_id"],
                reply_parameters=ReplyParameters(message_id=t["msg_id"], allow_sending_without_reply=True))
            db.set_task(t["id"], note_msg=msg.message_id)
    except TelegramBadRequest as e:
        if "not modified" in str(e).lower():
            return
        if is_gone(e):
            db.set_task(t["id"], status="gone", final=1)
        else:
            log.warning("Не удалось пометить задание #%s: %s", t["id"], err_text(e))
            await notify_owner(f"⚠️ Не удалось пометить задание #{t['id']} в группе: {err_text(e)}")
    except TelegramForbiddenError as e:
        await notify_owner(f"⚠️ Бот не может писать в группу (задание #{t['id']}): {err_text(e)}. "
                           f"Проверьте, что бот состоит в группе и является админом.")


async def _delete_messages(t: dict) -> tuple:
    """Удалить сообщение задания и пометку бота. Возвращает (всё удалено, причина ошибки)."""
    bot = get_bot()
    ok, reason = True, ""
    for mid in (t["msg_id"], t["note_msg"]):
        if not mid:
            continue
        try:
            await bot.delete_message(t["chat_id"], mid)
        except (TelegramBadRequest, TelegramForbiddenError) as e:
            if not is_gone(e):
                ok, reason = False, err_text(e)
    return ok, reason


async def _warn_not_deleted(t: dict, reason: str) -> None:
    await notify_owner(
        f"⚠️ Не удалось удалить сообщение задания #{t['id']} из группы: {reason}.\n"
        f"Бот должен быть админом группы с правом «Удалять сообщения». Удалите сообщение вручную.")


async def finish_task(task_id: int, how: str, by: Optional[int] = None) -> tuple:
    """Закрыть задание в ЛЮБОЙ момент (даже во время приёма работ).
    how: 'done' — ✅ Выполнено (запускает приём работ); 'cancel' — ❌ Не действительно;
         'close' — закрыть приём работ и убрать из группы прямо сейчас; 'delete' — удалить задание."""
    t = db.get_task(task_id)
    if not t:
        return False, "Задание не найдено."
    open_now = t["status"] in ("active", "done") and not t["final"]
    if how == "done":
        if t["status"] == "done" and not t["final"]:
            return False, "Задание уже выполнено, идёт приём работ."
        if t["status"] != "active":
            return False, "Задание уже закрыто."
        db.set_task(task_id, status="done", done_at=db.now(), closed_by=by)
        hours = logic.fmt_hours(db.grace_hours())
        await _mark(t, f"✅ ВЫПОЛНЕНО, работы принимаются {hours}")
        return True, f"✅ Задание #{task_id} выполнено. Работы принимаются {hours}, потом сообщение удалится."
    if not open_now and how != "delete":
        return False, "Задание уже закрыто."
    if how == "cancel":
        db.set_task(task_id, status="cancelled", done_at=db.now(), closed_by=by, final=1)
        await _mark(t, "❌ НЕ ДЕЙСТВИТЕЛЬНО")
        n = await send_to_all(task_audience(t), f"❌ Задание отменено как недействительное:\n\n{clip(t['text'], 1500)}")
        return True, f"❌ Задание #{task_id} закрыто как недействительное. Уведомлений: {n}."
    if how == "close":
        ok, reason = await _delete_messages(t)
        db.set_task(task_id, status="closed", final=1, closed_by=by)
        if not ok:
            await _warn_not_deleted(t, reason)
            return True, f"🔒 Задание #{task_id} закрыто, но сообщение удалить не удалось: {reason}"
        return True, f"🔒 Задание #{task_id} закрыто, сообщение убрано из группы."
    if how == "delete":
        if t["status"] == "deleted":
            return False, "Задание уже удалено."
        ok, reason = await _delete_messages(t)
        db.set_task(task_id, status="deleted", final=1, closed_by=by)
        if not ok:
            await _warn_not_deleted(t, reason)
            return True, f"🗑 Задание #{task_id} удалено из бота, но сообщение в группе удалить не удалось: {reason}"
        return True, f"🗑 Задание #{task_id} удалено."
    return False, "Неизвестное действие."


async def finalize_task(t: dict) -> bool:
    """Автоудаление после приёма работ: убрать сообщение и пометку из группы. При неудаче — уведомить владельца."""
    ok, reason = await _delete_messages(t)
    db.set_task(t["id"], final=1, status="closed")
    if not ok:
        await _warn_not_deleted(t, reason)
    return ok


async def finalize_due() -> int:
    """Удалить выполненные задания, у которых вышло время приёма работ (grace_hours)."""
    limit = logic.grace_seconds(db.grace_hours())
    n = 0
    for t in db.due_tasks():
        if db.now() - t["done_at"] >= limit:
            await finalize_task(t)
            n += 1
    return n


async def msg_exists(chat_id: int, msg_id: int) -> Optional[bool]:
    """Есть ли сообщение. Проверка без видимых следов: пустая реакция.
    True — есть, False — удалено, None — выяснить не удалось."""
    try:
        await get_bot().set_message_reaction(chat_id=chat_id, message_id=msg_id, reaction=[])
        return True
    except TelegramBadRequest as e:
        return False if is_gone(e) else None
    except TelegramAPIError:
        return None


async def check_deleted_once() -> int:
    """Закрыть задания, сообщения которых удалили вручную."""
    n = 0
    for t in db.open_tasks():
        if not t["chat_id"] or not t["msg_id"]:
            continue
        if await msg_exists(t["chat_id"], t["msg_id"]) is False:
            if t["note_msg"]:
                try:
                    await get_bot().delete_message(t["chat_id"], t["note_msg"])
                except TelegramAPIError:
                    pass
            db.set_task(t["id"], status="gone", final=1)
            n += 1
        await asyncio.sleep(0.05)
    return n


async def check_bot_rights(chat_id: int) -> Optional[str]:
    """None — всё в порядке, иначе текст ошибки."""
    bot = get_bot()
    try:
        me = await bot.me()
        member = await bot.get_chat_member(chat_id, me.id)
    except TelegramAPIError as e:
        return f"Бот не состоит в этой группе или нет доступа: {err_text(e)}"
    if member.status == "creator":
        return None
    if member.status != "administrator":
        return "Бот не админ в группе. Назначьте его администратором с правом «Удалять сообщения»."
    if not getattr(member, "can_delete_messages", False):
        return "У бота нет права «Удалять сообщения» — выдайте его в настройках администратора."
    return None


# --- Баны ------------------------------------------------------------------------------------------------
def ban_user(uid: int, src: str = "manual") -> None:
    db.set_user(uid, banned=1, ban_src=src)


def unban_user(uid: int) -> None:
    """Разбан сбрасывает все права: разрешения, уровень админа, роль админа, куратора."""
    u = db.get_user(uid)
    if not u:
        return
    role = "user" if u["role"] == "admin" else u["role"]
    db.set_user(uid, banned=0, ban_src=None, perms="[]", admin_level=None, role=role)
    db.clear_curator_user(uid)


# --- Разбор ввода ------------------------------------------------------------------------------------------
def parse_topic(text: str, default_chat: Optional[int] = None) -> tuple:
    """Ссылка t.me/c/<чат>/<тема>[/<сообщение>] или числовой ID темы → (chat_id, thread_id, ошибка)."""
    t = (text or "").strip()
    m = re.search(r"t\.me/c/(\d+)/(\d+)", t)
    if m:
        return int("-100" + m.group(1)), int(m.group(2)), None
    if t.isdigit():
        return default_chat, int(t), None
    return None, None, ("Не удалось распознать тему. Пришлите ссылку вида "
                        "https://t.me/c/1234567890/123 или числовой ID темы.")


def resolve_users(text: str) -> tuple:
    """'123, @name' → (найденные пользователи, ненайденные строки)."""
    found, missing = [], []
    for part in re.split(r"[,\s;]+", text or ""):
        part = part.strip()
        if not part:
            continue
        u = db.find_user(part)
        if u and u["role"]:
            if u not in found:
                found.append(u)
        else:
            missing.append(part)
    return found, missing


# --- Guard: проверка доступа для личных сообщений ---------------------------------------------------------
class Guard(BaseMiddleware):
    """В личке: регистрирует пользователя, закрывает доступ забаненным и не авторизованным."""

    async def __call__(self, handler, event, data):
        tg = event.from_user
        if isinstance(event, CallbackQuery):
            chat = event.message.chat if event.message else None
        else:
            chat = event.chat
        if tg is None or tg.is_bot:
            return await handler(event, data)
        if chat is None or chat.type == "private":
            row = db.touch_user(tg.id, tg.username, tg.full_name)
            if getattr(config, "OWNER_ID", None) and tg.id == config.OWNER_ID and row["role"] != "owner":
                db.set_user(tg.id, role="owner", status="owner", admin_level=None, banned=0, ban_src=None)
                row = db.get_user(tg.id)
            if row["banned"]:
                await self._deny(event, "⛔ Доступ закрыт: вы заблокированы в боте.")
                return None
            if row["role"] is None:
                state = data.get("state")
                raw = await state.get_state() if state else None
                text = (event.text or "") if isinstance(event, Message) else ""
                if raw != AUTH_STATE and not text.startswith(("/start", "/login")):
                    await self._deny(event, "🔒 Сначала введите пароль доступа. Отправьте /start")
                    return None
        result = await handler(event, data)
        if isinstance(event, CallbackQuery):
            try:
                await event.answer()
            except TelegramAPIError:
                pass
        return result

    @staticmethod
    async def _deny(event, text: str) -> None:
        try:
            if isinstance(event, CallbackQuery):
                await event.answer(text, show_alert=True)
            else:
                await event.answer(text)
        except TelegramAPIError:
            pass
