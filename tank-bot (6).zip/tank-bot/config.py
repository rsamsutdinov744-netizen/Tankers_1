"""Конфигурация tank-bot: значения по умолчанию, .env и константы.

Бот запускается и БЕЗ файла .env: токен и пароли ролей прописаны ниже как значения по умолчанию.
Приоритет (от высшего): переменные окружения / .env  →  значения из этого файла.
Пароли ролей можно менять прямо в боте (Владелец → 🔐 Пароли) — они сохраняются в базе
и имеют приоритет над всем остальным.
"""
import os
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


def _load_env(path: Path) -> None:
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key, value = key.strip(), value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        os.environ.setdefault(key, value)       # переменные окружения важнее .env


_load_env(BASE_DIR / ".env")

# --- Значения по умолчанию (используются, если нет .env / переменных окружения) ---------------
DEFAULT_BOT_TOKEN = "8781470760:AAGJJt06H88Nztf_RNkuWrdiXuUslc_2JGA"
DEFAULT_USER_PASSWORD = "UT653IO212"
DEFAULT_ADMIN_PASSWORD = "Admin5642iS2"
DEFAULT_OWNER_PASSWORD = "Admin 5642iS25612#"

_problems: list = []


def _env(name: str, default: str = "") -> str:
    return os.getenv(name, "").strip() or default


def _int(name: str, default=None):
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        _problems.append(f"{name} должна быть целым числом, сейчас: {raw!r}")
        return default


BOT_TOKEN = _env("BOT_TOKEN", DEFAULT_BOT_TOKEN)
USER_PASSWORD = _env("USER_PASSWORD", DEFAULT_USER_PASSWORD)
ADMIN_PASSWORD = _env("ADMIN_PASSWORD", DEFAULT_ADMIN_PASSWORD)
OWNER_PASSWORD = _env("OWNER_PASSWORD", DEFAULT_OWNER_PASSWORD)
OWNER_ID = _int("OWNER_ID")                    # необязательно: владельца можно определить и по паролю
SOURCE_GROUP_ID = _int("SOURCE_GROUP_ID")      # группа, откуда читаются задания (по умолчанию)
SOURCE_TOPIC_ID = _int("SOURCE_TOPIC_ID")      # тема группы (по умолчанию)
DB_PATH = _env("DB_PATH", str(BASE_DIR / "tank_bot.db"))
PORT = _int("PORT")                            # для хостингов, которым нужен открытый порт
CHECK_INTERVAL = max(10, _int("CHECK_INTERVAL", 120))

if _problems:
    sys.exit("❌ Ошибка конфигурации:\n" + "\n".join(f"  • {p}" for p in _problems) +
             "\nИсправьте переменные окружения / файл .env или удалите их, чтобы использовались значения по умолчанию.")

# --- Константы -------------------------------------------------------------
REMINDER_TICK = 20          # как часто проверять напоминания, секунд
MAX_TEXT = 4000             # предел длины сообщения Telegram (с запасом)

# Значения настроек по умолчанию (таблица settings)
DEFAULT_SETTINGS = {
    "grace_hours": "24",        # часов приёма работ после «Выполнено»
    "score_right": "5",         # баллы за итог «Правильно»
    "score_partial": "3",       # ... «Частично»
    "score_wrong": "1",         # ... «Неправильно»
    "score_bad": "0",           # ... «Совсем неверно»
    "score_per_grade": "0.5",   # баллов за каждый пункт оценки 1–10
    "best_bonus": "5",          # бонус за лучшую работу
    "report_on": "1",           # недельный отчёт владельцу: 1 — включён
    "report_day": "4",          # день недели отчёта (0 = понедельник ... 4 = пятница)
    "report_time": "13:00",     # время отчёта по Москве
    "ladder_member": "10",      # порог статуса «Участник»
    "ladder_best": "30",        # порог статуса «Лучший участник»
    "ladder_lead": "60",        # порог статуса «Ведущий»
}

DEFAULT_PHRASES = [
    "Не переживай, ошибки — часть пути. В следующий раз получится лучше! 💪",
    "Главное — ты не остановился. Продолжай, команда в тебя верит!",
    "Каждая работа делает тебя сильнее. Так держать! 🚀",
    "Даже лучшие мастера начинали с неудач. Двигаемся дальше!",
    "Ты уже на правильном пути — осталось немного доработать. 🔧",
    "Хороший результат приходит с практикой. Мы рядом и поможем!",
    "Не сдавайся! Твой вклад очень важен для проекта. 🎮",
    "Любая попытка лучше, чем её отсутствие. Горжусь твоим упорством!",
    "Разбор ошибок — быстрый путь к мастерству. Ты справишься! ⭐",
    "Танки не строятся за один день. Шаг за шагом — и всё получится! 🛡",
]
