"""SQLite (tank_bot.db): все таблицы и функции доступа к данным."""
import json
import random
import sqlite3
import time
from typing import Optional

import config
from perms import LADDER

_conn: Optional[sqlite3.Connection] = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY,
    username TEXT, name TEXT,
    role TEXT,                         -- NULL до ввода пароля; user / admin / owner
    admin_level TEXT,                  -- junior / middle / senior
    pos TEXT,                          -- artist / writer / animator / helper
    status TEXT NOT NULL DEFAULT 'newbie',
    points INTEGER NOT NULL DEFAULT 0,
    banned INTEGER NOT NULL DEFAULT 0,
    ban_src TEXT,                      -- manual / group
    perms TEXT NOT NULL DEFAULT '[]',
    created_at INTEGER, last_seen INTEGER
);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS tasks(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    aid INTEGER,                       -- номер из метки aid<номер>_<код>
    pos TEXT,                          -- должность; NULL = для всех
    chat_id INTEGER, thread_id INTEGER, msg_id INTEGER,
    src TEXT NOT NULL DEFAULT 'group', -- group (чужое сообщение) / bot (сообщение бота)
    status TEXT NOT NULL DEFAULT 'active',  -- active / done / cancelled / closed / gone
    done_at INTEGER,
    final INTEGER NOT NULL DEFAULT 0,  -- 1 = сообщения убраны, задание архивное
    note_msg INTEGER,                  -- id пометки бота (для чужих сообщений)
    created_at INTEGER, closed_by INTEGER,
    photo TEXT                         -- file_id фото задания (если есть)
);
CREATE UNIQUE INDEX IF NOT EXISTS tasks_msg ON tasks(chat_id, msg_id);
CREATE TABLE IF NOT EXISTS materials(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,                -- text / photo / file / link
    title TEXT NOT NULL, text TEXT, file_id TEXT, url TEXT,
    aud_type TEXT NOT NULL DEFAULT 'all',   -- all / pos / users
    aud_value TEXT NOT NULL DEFAULT '',
    pinned INTEGER NOT NULL DEFAULT 0,
    created_by INTEGER, created_at INTEGER
);
CREATE TABLE IF NOT EXISTS announcements(
    id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, created_by INTEGER, created_at INTEGER,
    photo TEXT
);
CREATE TABLE IF NOT EXISTS reminders(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    kind TEXT NOT NULL,                -- once / weekly / dates
    weekly TEXT NOT NULL DEFAULT '[]',
    dates TEXT NOT NULL DEFAULT '[]',
    fired TEXT NOT NULL DEFAULT '[]',
    chat_id INTEGER,                   -- NULL = место публикации из настроек
    thread INTEGER,
    active INTEGER NOT NULL DEFAULT 1,
    created_by INTEGER,
    dm_users TEXT NOT NULL DEFAULT '', -- ID через запятую (отправка в личку)
    created_at INTEGER,
    photo TEXT
);
CREATE TABLE IF NOT EXISTS forms(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL, questions TEXT NOT NULL,
    owner_id INTEGER,                  -- NULL = общая форма; иначе личная
    created_at INTEGER
);
CREATE TABLE IF NOT EXISTS works(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER, user_id INTEGER,
    kind TEXT NOT NULL,                -- free / form
    text TEXT, files TEXT NOT NULL DEFAULT '[]',
    form_id INTEGER, answers TEXT NOT NULL DEFAULT '[]',
    status TEXT NOT NULL DEFAULT 'pending',   -- pending / reviewed
    grade INTEGER, result TEXT, comment TEXT, comment_photo TEXT,
    points INTEGER NOT NULL DEFAULT 0,
    reviewer_id INTEGER,
    best INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER, reviewed_at INTEGER
);
CREATE TABLE IF NOT EXISTS curators(pos TEXT PRIMARY KEY, user_id INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS phrases(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS groups(chat_id INTEGER PRIMARY KEY, title TEXT);
CREATE TABLE IF NOT EXISTS polls(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER, chat_id INTEGER, thread INTEGER, message_id INTEGER,
    work_ids TEXT NOT NULL DEFAULT '[]',
    closed INTEGER NOT NULL DEFAULT 0, created_at INTEGER
);
CREATE TABLE IF NOT EXISTS templates(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL, text TEXT NOT NULL,
    pos TEXT,                          -- должность; NULL = для всех
    photo TEXT, created_at INTEGER
);
"""

# Столбцы, добавленные позже: нужны, чтобы старая база (из прошлой версии) обновлялась сама
MIGRATIONS = [("tasks", "photo", "TEXT"), ("announcements", "photo", "TEXT"),
              ("reminders", "photo", "TEXT"), ("works", "comment_photo", "TEXT")]

_DEFAULTS = getattr(config, "DEFAULT_SETTINGS", {})
_PHRASES = getattr(config, "DEFAULT_PHRASES", [])


def now() -> int:
    return int(time.time())


def _dict_factory(cursor, row):
    return {col[0]: row[i] for i, col in enumerate(cursor.description)}


def conn() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        _conn = sqlite3.connect(config.DB_PATH, check_same_thread=False, isolation_level=None)
        _conn.row_factory = _dict_factory
        _conn.execute("PRAGMA journal_mode=WAL")
    return _conn


def q(sql: str, args=()) -> list:
    return conn().execute(sql, args).fetchall()


def one(sql: str, args=()) -> Optional[dict]:
    return conn().execute(sql, args).fetchone()


def ex(sql: str, args=()) -> int:
    return conn().execute(sql, args).lastrowid


def update(table: str, row_id, **fields) -> None:
    """UPDATE по первичному ключу (id; для curators/groups не используется)."""
    if not fields:
        return
    cols = ", ".join(f"{k}=?" for k in fields)
    ex(f"UPDATE {table} SET {cols} WHERE id=?", (*fields.values(), row_id))


def jl(raw, default=None):
    try:
        return json.loads(raw) if raw else (default if default is not None else [])
    except (TypeError, ValueError):
        return default if default is not None else []


def _migrate() -> None:
    for table, col, decl in MIGRATIONS:
        cols = {r["name"] for r in q(f"PRAGMA table_info({table})")}
        if col not in cols:
            ex(f"ALTER TABLE {table} ADD COLUMN {col} {decl}")


def init() -> None:
    conn().executescript(SCHEMA)
    _migrate()
    if not one("SELECT 1 AS x FROM phrases LIMIT 1"):
        for p in _PHRASES:
            ex("INSERT INTO phrases(text) VALUES(?)", (p,))


# --- Настройки ---------------------------------------------------------------
def get_setting(key: str, default=None):
    r = one("SELECT value FROM settings WHERE key=?", (key,))
    if r is not None:
        return r["value"]
    return _DEFAULTS.get(key, default)


def set_setting(key: str, value) -> None:
    ex("INSERT INTO settings(key, value) VALUES(?, ?) "
       "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))


def del_setting(key: str) -> None:
    ex("DELETE FROM settings WHERE key=?", (key,))


def grace_hours() -> float:
    try:
        return float(get_setting("grace_hours", "24"))
    except ValueError:
        return 24.0


def place() -> tuple:
    """Место публикации: (chat_id, thread_id). Если не задано в настройках — из .env."""
    chat = get_setting("dest_chat")
    if chat in (None, ""):
        return getattr(config, "SOURCE_GROUP_ID", None), getattr(config, "SOURCE_TOPIC_ID", None)
    thread = get_setting("dest_thread")
    return int(chat), (int(thread) if thread not in (None, "") else None)


def score_cfg() -> dict:
    keys = ["score_right", "score_partial", "score_wrong", "score_bad", "score_per_grade", "best_bonus"]
    return {k: get_setting(k) for k in keys}


def get_password(role: str) -> str:
    """Пароль роли: сначала заданный владельцем в боте, иначе из config (.env / значения по умолчанию)."""
    saved = get_setting(f"pw_{role}")
    if saved:
        return saved
    return {"user": config.USER_PASSWORD, "admin": config.ADMIN_PASSWORD, "owner": config.OWNER_PASSWORD}[role]


def set_password(role: str, value: str) -> None:
    set_setting(f"pw_{role}", value)


def reset_password(role: str) -> None:
    del_setting(f"pw_{role}")


def ladder() -> dict:
    out = {}
    for status, key, default in LADDER:
        try:
            out[status] = int(get_setting(key, default))
        except ValueError:
            out[status] = default
    return out


# --- Пользователи ------------------------------------------------------------
def get_user(uid: int) -> Optional[dict]:
    return one("SELECT * FROM users WHERE id=?", (uid,))


def touch_user(uid: int, username: Optional[str], name: str) -> dict:
    if get_user(uid) is None:
        ex("INSERT INTO users(id, username, name, created_at, last_seen) VALUES(?,?,?,?,?)",
           (uid, username, name, now(), now()))
    else:
        ex("UPDATE users SET username=?, name=?, last_seen=? WHERE id=?", (username, name, now(), uid))
    return get_user(uid)


def set_user(uid: int, **fields) -> None:
    update("users", uid, **fields)


def perms_of(user: Optional[dict]) -> list:
    return jl(user["perms"], []) if user else []


def set_perms(uid: int, perms_list) -> None:
    set_user(uid, perms=json.dumps(sorted(set(perms_list))))


def find_user(text: str) -> Optional[dict]:
    t = (text or "").strip()
    if t.lstrip("-").isdigit():
        return get_user(int(t))
    return one("SELECT * FROM users WHERE lower(username)=?", (t.lstrip("@").lower(),))


def authorized_users() -> list:
    return q("SELECT * FROM users WHERE role IS NOT NULL AND banned=0 ORDER BY points DESC, name")


def users_page(page: int, size: int = 10) -> tuple:
    total = one("SELECT COUNT(*) AS c FROM users WHERE role IS NOT NULL AND banned=0")["c"]
    rows = q("SELECT * FROM users WHERE role IS NOT NULL AND banned=0 "
             "ORDER BY points DESC, name LIMIT ? OFFSET ?", (size, page * size))
    return rows, total


def admins() -> list:
    return q("SELECT * FROM users WHERE role='admin' AND banned=0 ORDER BY name")


def banned_users() -> list:
    return q("SELECT * FROM users WHERE banned=1 ORDER BY name")


def owner_ids() -> list:
    ids = set()
    if getattr(config, "OWNER_ID", None):
        ids.add(config.OWNER_ID)
    ids.update(r["id"] for r in q("SELECT id FROM users WHERE role='owner' AND banned=0"))
    return sorted(ids)


def audience(aud_type: str, aud_value: str = "") -> list:
    """ID получателей: все / должность / отдельные участники (без забаненных)."""
    rows = q("SELECT id, pos FROM users WHERE role IS NOT NULL AND banned=0")
    if aud_type == "pos":
        rows = [r for r in rows if r["pos"] == aud_value]
    elif aud_type == "users":
        ids = {int(x) for x in aud_value.split(",") if x.strip().lstrip("-").isdigit()}
        rows = [r for r in rows if r["id"] in ids]
    return [r["id"] for r in rows]


# --- Задания -------------------------------------------------------------------
def add_task(text, aid, pos, chat_id, thread_id, msg_id, src, photo=None) -> int:
    return ex("INSERT INTO tasks(text, aid, pos, chat_id, thread_id, msg_id, src, created_at, photo) "
              "VALUES(?,?,?,?,?,?,?,?,?)", (text, aid, pos, chat_id, thread_id, msg_id, src, now(), photo))


def get_task(task_id: int) -> Optional[dict]:
    return one("SELECT * FROM tasks WHERE id=?", (task_id,))


def task_by_msg(chat_id: int, msg_id: int) -> Optional[dict]:
    return one("SELECT * FROM tasks WHERE chat_id=? AND msg_id=?", (chat_id, msg_id))


def set_task(task_id: int, **fields) -> None:
    update("tasks", task_id, **fields)


def open_tasks() -> list:
    """Активные и выполненные (идёт приём работ) задания, ещё не убранные из группы."""
    return q("SELECT * FROM tasks WHERE status IN ('active','done') AND final=0 ORDER BY id DESC")


def due_tasks() -> list:
    return q("SELECT * FROM tasks WHERE status='done' AND final=0 AND done_at IS NOT NULL")


def next_aid() -> int:
    r = one("SELECT MAX(aid) AS m FROM tasks")
    return (r["m"] or 0) + 1


# --- Материалы и объявления ----------------------------------------------------
def add_material(**f) -> int:
    return ex("INSERT INTO materials(kind, title, text, file_id, url, aud_type, aud_value, pinned, "
              "created_by, created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
              (f["kind"], f["title"], f.get("text"), f.get("file_id"), f.get("url"),
               f.get("aud_type", "all"), f.get("aud_value", ""), int(f.get("pinned", 0)),
               f.get("created_by"), now()))


def get_material(mid: int) -> Optional[dict]:
    return one("SELECT * FROM materials WHERE id=?", (mid,))


def list_materials() -> list:
    return q("SELECT * FROM materials ORDER BY pinned DESC, id DESC")


def pinned_materials() -> list:
    return q("SELECT * FROM materials WHERE pinned=1 ORDER BY id")


def del_material(mid: int) -> None:
    ex("DELETE FROM materials WHERE id=?", (mid,))


def material_visible(mat: dict, user: dict) -> bool:
    if mat["aud_type"] == "all":
        return True
    if mat["aud_type"] == "pos":
        return user.get("pos") == mat["aud_value"]
    return str(user["id"]) in [x.strip() for x in mat["aud_value"].split(",")]


def add_announcement(text: str, by: int, photo=None) -> int:
    return ex("INSERT INTO announcements(text, created_by, created_at, photo) VALUES(?,?,?,?)",
              (text, by, now(), photo))


def get_announcement(aid: int) -> Optional[dict]:
    return one("SELECT * FROM announcements WHERE id=?", (aid,))


def set_announcement(aid: int, **fields) -> None:
    update("announcements", aid, **fields)


def list_announcements(limit: int = 15) -> list:
    return q("SELECT * FROM announcements ORDER BY id DESC LIMIT ?", (limit,))


def del_announcement(aid: int) -> None:
    ex("DELETE FROM announcements WHERE id=?", (aid,))


# --- Напоминания ------------------------------------------------------------------
def add_reminder(text, kind, weekly, dates, chat_id, thread, created_by, dm_users, photo=None) -> int:
    return ex("INSERT INTO reminders(text, kind, weekly, dates, chat_id, thread, created_by, dm_users, "
              "created_at, photo) VALUES(?,?,?,?,?,?,?,?,?,?)",
              (text, kind, json.dumps(weekly), json.dumps(dates), chat_id, thread, created_by,
               dm_users, now(), photo))


def get_reminder(rid: int) -> Optional[dict]:
    return one("SELECT * FROM reminders WHERE id=?", (rid,))


def list_reminders() -> list:
    return q("SELECT * FROM reminders ORDER BY id DESC")


def active_reminders() -> list:
    return q("SELECT * FROM reminders WHERE active=1")


def set_reminder(rid: int, **fields) -> None:
    update("reminders", rid, **fields)


def del_reminder(rid: int) -> None:
    ex("DELETE FROM reminders WHERE id=?", (rid,))


# --- Формы ----------------------------------------------------------------------------
def add_form(title: str, questions: list, owner_id: Optional[int]) -> int:
    return ex("INSERT INTO forms(title, questions, owner_id, created_at) VALUES(?,?,?,?)",
              (title, json.dumps(questions, ensure_ascii=False), owner_id, now()))


def get_form(fid: int) -> Optional[dict]:
    return one("SELECT * FROM forms WHERE id=?", (fid,))


def list_forms(owner_id: Optional[int] = None, common: bool = True) -> list:
    """Общие формы (owner_id IS NULL) и/или личные формы пользователя."""
    if common and owner_id is not None:
        return q("SELECT * FROM forms WHERE owner_id IS NULL OR owner_id=? ORDER BY owner_id IS NOT NULL, id",
                 (owner_id,))
    if common:
        return q("SELECT * FROM forms WHERE owner_id IS NULL ORDER BY id")
    return q("SELECT * FROM forms WHERE owner_id=? ORDER BY id", (owner_id,))


def del_form(fid: int) -> None:
    ex("DELETE FROM forms WHERE id=?", (fid,))


# --- Работы ------------------------------------------------------------------------------
def add_work(task_id, user_id, kind, text, files, form_id=None, answers=None) -> int:
    return ex("INSERT INTO works(task_id, user_id, kind, text, files, form_id, answers, created_at) "
              "VALUES(?,?,?,?,?,?,?,?)",
              (task_id, user_id, kind, text, json.dumps(files), form_id,
               json.dumps(answers or [], ensure_ascii=False), now()))


def get_work(wid: int) -> Optional[dict]:
    return one("SELECT * FROM works WHERE id=?", (wid,))


def set_work(wid: int, **fields) -> None:
    update("works", wid, **fields)


def pending_works(limit: int = 20) -> list:
    return q("SELECT * FROM works WHERE status='pending' ORDER BY id LIMIT ?", (limit,))


def works_of_task(task_id: int) -> list:
    return q("SELECT * FROM works WHERE task_id=? ORDER BY id", (task_id,))


def works_of_user(uid: int, limit: int = 15) -> list:
    return q("SELECT * FROM works WHERE user_id=? ORDER BY id DESC LIMIT ?", (uid, limit))


def tasks_with_works(limit: int = 15) -> list:
    return q("SELECT t.*, COUNT(w.id) AS wcount FROM tasks t JOIN works w ON w.task_id=t.id "
             "GROUP BY t.id ORDER BY MAX(w.id) DESC LIMIT ?", (limit,))


# --- Кураторы ---------------------------------------------------------------------------------
def get_curator(pos: Optional[str]) -> Optional[int]:
    if not pos:
        return None
    r = one("SELECT user_id FROM curators WHERE pos=?", (pos,))
    return r["user_id"] if r else None


def set_curator(pos: str, uid: int) -> None:
    ex("INSERT INTO curators(pos, user_id) VALUES(?, ?) "
       "ON CONFLICT(pos) DO UPDATE SET user_id=excluded.user_id", (pos, uid))


def del_curator(pos: str) -> None:
    ex("DELETE FROM curators WHERE pos=?", (pos,))


def clear_curator_user(uid: int) -> None:
    ex("DELETE FROM curators WHERE user_id=?", (uid,))


def curators() -> dict:
    return {r["pos"]: r["user_id"] for r in q("SELECT * FROM curators")}


# --- Фразы поддержки --------------------------------------------------------------------------
def list_phrases() -> list:
    return q("SELECT * FROM phrases ORDER BY id")


def add_phrase(text: str) -> int:
    return ex("INSERT INTO phrases(text) VALUES(?)", (text,))


def set_phrase(pid: int, text: str) -> None:
    update("phrases", pid, text=text)


def del_phrase(pid: int) -> None:
    ex("DELETE FROM phrases WHERE id=?", (pid,))


def random_phrase() -> str:
    rows = list_phrases()
    return random.choice(rows)["text"] if rows else ""


# --- Группы и опросы ------------------------------------------------------------------------------
def save_group(chat_id: int, title: Optional[str]) -> None:
    ex("INSERT INTO groups(chat_id, title) VALUES(?, ?) "
       "ON CONFLICT(chat_id) DO UPDATE SET title=excluded.title", (chat_id, title or str(chat_id)))


def del_group(chat_id: int) -> None:
    ex("DELETE FROM groups WHERE chat_id=?", (chat_id,))


def list_groups() -> list:
    return q("SELECT * FROM groups ORDER BY title")


def group_title(chat_id) -> str:
    r = one("SELECT title FROM groups WHERE chat_id=?", (chat_id,))
    return r["title"] if r else str(chat_id)


def add_poll(task_id, chat_id, thread, message_id, work_ids) -> int:
    return ex("INSERT INTO polls(task_id, chat_id, thread, message_id, work_ids, created_at) "
              "VALUES(?,?,?,?,?,?)", (task_id, chat_id, thread, message_id, json.dumps(work_ids), now()))


def get_poll(pid: int) -> Optional[dict]:
    return one("SELECT * FROM polls WHERE id=?", (pid,))


def open_polls() -> list:
    return q("SELECT * FROM polls WHERE closed=0 ORDER BY id DESC")


def set_poll(pid: int, **fields) -> None:
    update("polls", pid, **fields)


# --- Шаблоны заданий -----------------------------------------------------------------------------------
def add_template(title: str, text: str, pos, photo=None) -> int:
    return ex("INSERT INTO templates(title, text, pos, photo, created_at) VALUES(?,?,?,?,?)",
              (title, text, pos, photo, now()))


def get_template(tid: int) -> Optional[dict]:
    return one("SELECT * FROM templates WHERE id=?", (tid,))


def set_template(tid: int, **fields) -> None:
    update("templates", tid, **fields)


def list_templates() -> list:
    return q("SELECT * FROM templates ORDER BY id")


def del_template(tid: int) -> None:
    ex("DELETE FROM templates WHERE id=?", (tid,))


# --- Статистика -----------------------------------------------------------------------------------------
def stats() -> dict:
    def c(sql):
        return one(sql)["c"]
    chat, thread = place()
    return {
        "users": c("SELECT COUNT(*) AS c FROM users WHERE role IS NOT NULL AND banned=0"),
        "banned": c("SELECT COUNT(*) AS c FROM users WHERE banned=1"),
        "materials": c("SELECT COUNT(*) AS c FROM materials"),
        "announcements": c("SELECT COUNT(*) AS c FROM announcements"),
        "tasks_active": c("SELECT COUNT(*) AS c FROM tasks WHERE status='active'"),
        "tasks_waiting": c("SELECT COUNT(*) AS c FROM tasks WHERE status='done' AND final=0"),
        "works": c("SELECT COUNT(*) AS c FROM works"),
        "works_pending": c("SELECT COUNT(*) AS c FROM works WHERE status='pending'"),
        "reminders": c("SELECT COUNT(*) AS c FROM reminders"),
        "reminders_active": c("SELECT COUNT(*) AS c FROM reminders WHERE active=1"),
        "chat": chat, "thread": thread,
    }


def week_stats(since: int) -> dict:
    """Сводка за период (для недельного отчёта владельцу)."""
    def c(sql, args=()):
        return one(sql, args)["c"]
    avg = one("SELECT AVG(grade) AS a FROM works WHERE reviewed_at>=? AND grade IS NOT NULL", (since,))["a"]
    return {
        "new_tasks": c("SELECT COUNT(*) AS c FROM tasks WHERE created_at>=?", (since,)),
        "works": c("SELECT COUNT(*) AS c FROM works WHERE created_at>=?", (since,)),
        "reviewed": c("SELECT COUNT(*) AS c FROM works WHERE reviewed_at>=?", (since,)),
        "avg_grade": avg,
        "pending": c("SELECT COUNT(*) AS c FROM works WHERE status='pending'"),
        "tasks_active": c("SELECT COUNT(*) AS c FROM tasks WHERE status='active'"),
    }
