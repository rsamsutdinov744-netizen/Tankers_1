"""Чистая логика без Telegram и БД: время, расписания, баллы, grace_seconds."""
import re
from datetime import date, datetime, timedelta, timezone
from typing import Optional

from perms import STATUS_ORDER

MSK = timezone(timedelta(hours=3))      # московское время (UTC+3), без перехода на летнее
LATE_WINDOW = 1800                       # напоминание отправится, если опоздали не более чем на 30 минут
WEEKDAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]
MONTHS = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
          "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"]

RESULT_NAMES = {
    "right": "✅ Правильно",
    "partial": "🟡 Частично",
    "wrong": "❌ Неправильно",
    "bad": "🚫 Совсем неверно",
}


# --- Время ---------------------------------------------------------------
def now_msk() -> datetime:
    return datetime.now(MSK)


def fmt_ts(ts: int) -> str:
    return datetime.fromtimestamp(ts, MSK).strftime("%d.%m.%Y %H:%M")


def grace_seconds(hours) -> int:
    """Часы приёма работ → секунды."""
    try:
        return max(0, int(float(hours) * 3600))
    except (TypeError, ValueError):
        return 24 * 3600


def hours_word(n: int) -> str:
    n = abs(int(n))
    if 11 <= n % 100 <= 14:
        return "часов"
    return {1: "час", 2: "часа", 3: "часа", 4: "часа"}.get(n % 10, "часов")


def points_word(n: int) -> str:
    n = abs(int(n))
    if 11 <= n % 100 <= 14:
        return "баллов"
    return {1: "балл", 2: "балла", 3: "балла", 4: "балла"}.get(n % 10, "баллов")


def fmt_hours(hours) -> str:
    h = float(hours)
    if h.is_integer():
        return f"{int(h)} {hours_word(int(h))}"
    return f"{h:g} ч."


def parse_hhmm(text: str) -> Optional[str]:
    m = re.fullmatch(r"\s*(\d{1,2})\s*[:.\-]\s*(\d{2})\s*", text or "")
    if not m:
        return None
    h, mi = int(m.group(1)), int(m.group(2))
    if h > 23 or mi > 59:
        return None
    return f"{h:02d}:{mi:02d}"


def parse_date(text: str) -> Optional[date]:
    """ДД.ММ.ГГГГ или ДД.ММ (текущий год)."""
    m = re.fullmatch(r"\s*(\d{1,2})\.(\d{1,2})(?:\.(\d{2,4}))?\s*", text or "")
    if not m:
        return None
    d, mo = int(m.group(1)), int(m.group(2))
    y = m.group(3)
    year = now_msk().year if not y else (int(y) + 2000 if len(y) == 2 else int(y))
    try:
        return date(year, mo, d)
    except ValueError:
        return None


def parse_datetime_msk(text: str) -> Optional[datetime]:
    parts = (text or "").split()
    if len(parts) != 2:
        return None
    d, t = parse_date(parts[0]), parse_hhmm(parts[1])
    if not d or not t:
        return None
    h, mi = map(int, t.split(":"))
    return datetime(d.year, d.month, d.day, h, mi, tzinfo=MSK)


# --- Расписания напоминаний ---------------------------------------------
# weekly: [{"d": 0..6, "t": "HH:MM"}]   dates / once: [{"d": "YYYY-MM-DD", "t": "HH:MM"}]
def _entry_dt(entry: dict) -> datetime:
    return datetime.strptime(f"{entry['d']} {entry['t']}", "%Y-%m-%d %H:%M").replace(tzinfo=MSK)


def due_keys(kind: str, weekly: list, dates: list, fired: list, now: datetime,
             window: int = LATE_WINDOW) -> list:
    """Ключи записей расписания, которые пора отправить (и ещё не отправлялись)."""
    keys = []
    if kind == "weekly":
        for e in weekly:
            if e["d"] != now.weekday():
                continue
            h, mi = map(int, e["t"].split(":"))
            dt = now.replace(hour=h, minute=mi, second=0, microsecond=0)
            key = dt.strftime("%Y-%m-%d %H:%M")
            if dt <= now < dt + timedelta(seconds=window) and key not in fired:
                keys.append(key)
    else:
        for e in dates:
            dt = _entry_dt(e)
            key = f"{e['d']} {e['t']}"
            if dt <= now < dt + timedelta(seconds=window) and key not in fired:
                keys.append(key)
    return keys


def entries_done(dates: list, fired: list, now: datetime, window: int = LATE_WINDOW) -> bool:
    """Для разовых/календарных: все записи отправлены или просрочены."""
    for e in dates:
        key = f"{e['d']} {e['t']}"
        if key not in fired and _entry_dt(e) + timedelta(seconds=window) > now:
            return False
    return True


def describe_schedule(kind: str, weekly: list, dates: list) -> str:
    if kind == "weekly":
        return "Каждую неделю: " + ", ".join(f"{WEEKDAYS[e['d']]} {e['t']}" for e in weekly)
    items = []
    for e in dates:
        y, m, d = e["d"].split("-")
        items.append(f"{d}.{m}.{y} {e['t']}")
    return ("Разово: " if kind == "once" else "По датам: ") + ", ".join(items)


# --- Баллы и статусы -------------------------------------------------------
def status_for_points(points: int, ladder: dict) -> str:
    """Статус по баллам. ladder: {'member': 10, 'best': 30, 'lead': 60}."""
    result = "newbie"
    for st in STATUS_ORDER[1:]:
        if points >= ladder.get(st, 10 ** 9):
            result = st
    return result


def status_rank(status: str) -> int:
    return STATUS_ORDER.index(status) if status in STATUS_ORDER else len(STATUS_ORDER)


def work_points(result: str, grade: int, cfg: dict) -> int:
    """Баллы за работу = баллы за итог + баллы за оценку."""
    base = int(cfg.get(f"score_{result}", 0))
    per_grade = float(cfg.get("score_per_grade", 0.5))
    return base + int(grade * per_grade + 0.5)


def progress_bar(points: int, need: int, width: int = 10) -> str:
    filled = 0 if need <= 0 else min(width, int(points * width / need))
    return "▓" * filled + "░" * (width - filled)
