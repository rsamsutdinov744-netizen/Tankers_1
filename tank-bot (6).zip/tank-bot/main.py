"""tank-bot — Telegram-бот команды разработки 2D-танков (aiogram 3).

Основной код: авторизация, меню, задания из группы, админ-панель, участники и права, запуск.
Остальное — в модулях: materials, works, reminders, scoring (см. README.md).
"""
import asyncio
import hmac
import json
import logging
import re
import time

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.exceptions import (TelegramAPIError, TelegramBadRequest, TelegramForbiddenError,
                                TelegramUnauthorizedError)
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand, CallbackQuery, ChatMemberUpdated, ErrorEvent, Message

import config
import db
import logic
import materials
import perms
import reminders
import scoring
import tasks_filter as tf
import works
from common import (Auth, Guard, ban_user, can_manage, check_bot_rights, check_deleted_once, clip,
                    err_text, finalize_due, finish_task, fmt_user, get_bot, has_perm, kb, need, notify,
                    notify_owner, pager_row, parse_topic, participant_menu, pos_label, prepare_task,
                    preview, progress_line, publish_task, section_screen, send_rich, set_bot, show,
                    show_menu, status_label, task_kb, unban_user)

log = logging.getLogger("tank-bot")
router = Router()
fallback = Router()
GROUPS = {"group", "supergroup"}


class AddTask(StatesGroup):
    text = State()


class Grace(StatesGroup):
    hours = State()


class PlaceTopic(StatesGroup):
    thread = State()


class AdmAdd(StatesGroup):
    ident = State()


class EditTask(StatesGroup):
    text = State()


class PwChange(StatesGroup):
    value = State()


class RepTime(StatesGroup):
    value = State()


# ============================== Авторизация ==============================
_fails: dict = {}


def _locked(uid: int) -> int:
    """Секунд до конца блокировки после 5 неверных паролей за 10 минут (0 — не заблокирован)."""
    now = time.time()
    recent = [t for t in _fails.get(uid, []) if now - t < 600]
    _fails[uid] = recent
    return int(600 - (now - recent[0])) if len(recent) >= 5 else 0


def detect_role(text: str):
    for role in ("owner", "admin", "user"):
        if hmac.compare_digest(text.encode(), db.get_password(role).encode()):
            return role
    return None


def apply_role(uid: int, new_role: str) -> str:
    """Выдаёт роль по паролю. Пароль только повышает роль, понижать не умеет."""
    u = db.get_user(uid)
    order = {None: -1, "user": 0, "admin": 1, "owner": 2}
    if order[new_role] <= order[u["role"]]:
        return f"ℹ️ У вас уже роль «{perms.ROLE_NAMES[u['role']]}» — пароль её не меняет."
    if new_role == "admin":
        db.set_user(uid, role="admin", admin_level="junior", perms=json.dumps(perms.DEFAULT_ADMIN_PERMS))
        return ("✅ Пароль принят. Ваша роль: Админ (младший уровень). Стандартные права выданы — "
                "владелец может их изменить.")
    if new_role == "owner":
        db.set_user(uid, role="owner", status="owner", admin_level=None)
        return "✅ Пароль принят. Ваша роль: Владелец."
    db.set_user(uid, role="user")
    return "✅ Пароль принят. Ваша роль: Пользователь."


async def _try_delete(m: Message) -> None:
    try:
        await m.delete()
    except TelegramAPIError:
        pass


@router.message(CommandStart(), F.chat.type == "private")
async def cmd_start(m: Message, state: FSMContext):
    await state.clear()
    if db.get_user(m.from_user.id)["role"]:
        await show_menu(m, m.from_user.id, "👋 С возвращением!")
        return
    await state.set_state(Auth.password)
    await m.answer("🔐 Добро пожаловать в tank-bot — бот команды разработки 2D-танков!\n\n"
                   "Введите пароль доступа (сообщение с паролем бот сразу удалит):")


@router.message(Command("login"), F.chat.type == "private")
async def cmd_login(m: Message, state: FSMContext):
    await state.set_state(Auth.password)
    await m.answer("🔑 Введите пароль, чтобы получить другую роль (например, админа). "
                   "Сообщение с паролем будет удалено.")


@router.message(Auth.password, F.text, F.chat.type == "private")
async def auth_password(m: Message, state: FSMContext):
    uid = m.from_user.id
    await _try_delete(m)
    wait = _locked(uid)
    if wait:
        await m.answer(f"⏳ Слишком много неверных попыток. Подождите {wait // 60 + 1} мин. и попробуйте снова.")
        return
    role = detect_role(m.text.strip())
    if role is None:
        _fails.setdefault(uid, []).append(time.time())
        await m.answer("❌ Неверный пароль. Попробуйте ещё раз.")
        return
    _fails.pop(uid, None)
    note = apply_role(uid, role)
    await state.clear()
    await show_menu(m, uid, note)


@router.message(Auth.password, F.chat.type == "private")
async def auth_bad(m: Message):
    await m.answer("⚠️ Пароль нужно ввести текстом.")


# ============================== Меню и общие команды ==============================
@router.message(Command("menu"), F.chat.type == "private")
async def cmd_menu(m: Message, state: FSMContext):
    await state.clear()
    await show_menu(m, m.from_user.id)


@router.message(Command("help"), F.chat.type == "private")
async def cmd_help(m: Message):
    text = ("ℹ️ Команды:\n/menu — главное меню\n/cancel — отменить текущее действие\n"
            "/login — ввести другой пароль (повысить роль)\n")
    if db.get_user(m.from_user.id)["role"] in ("admin", "owner"):
        text += ("\nДля админов:\n/here — в группе, в нужной теме: сделать её местом публикации\n"
                 "/done, /cancel, /close, /delete — в группе ответом на сообщение задания "
                 "(или с номером: /done 12, работает и в личке):\n"
                 "  /done — выполнено (начинается приём работ)\n  /cancel — не действительно\n"
                 "  /close — закрыть приём работ и убрать из группы сейчас\n  /delete — удалить задание")
    await m.answer(text)


HOW = {"done": "done", "cancel": "cancel", "close": "close", "delete": "delete"}
USAGE = ("Использование (12 — номер задания):\n/done 12 — выполнено\n/cancel 12 — не действительно\n"
         "/close 12 — закрыть приём работ и убрать из группы\n/delete 12 — удалить задание")


@router.message(Command("cancel", "done", "close", "delete"), F.chat.type == "private")
async def cmd_cancel_private(m: Message, command: CommandObject, state: FSMContext):
    arg = (command.args or "").strip()
    if arg.isdigit():
        if not await need(m, "tasks_close"):
            return
        ok, msg = await finish_task(int(arg), HOW[command.command], m.from_user.id)
        await m.answer(msg)
        return
    if command.command == "cancel":
        await state.clear()
        await show_menu(m, m.from_user.id, "↩️ Действие отменено.")
        return
    await m.answer(USAGE)


@router.callback_query(F.data.in_({"menu", "adm"}))
async def cb_menu(cb: CallbackQuery, state: FSMContext):
    """Главное меню: своё для участника, админа и владельца."""
    await state.clear()
    await show_menu(cb, cb.from_user.id)


@router.callback_query(F.data == "pmenu")
async def cb_pmenu(cb: CallbackQuery, state: FSMContext):
    """Меню участника для админа/владельца (они тоже выполняют задания и сдают работы)."""
    await state.clear()
    text, markup = participant_menu(cb.from_user.id, staff=True)
    await show(cb, text, markup)


@router.callback_query(F.data.startswith("sec:"))
async def cb_section(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    res = section_screen(cb.from_user.id, cb.data.split(":")[1])
    if not res:
        await cb.answer("⛔ В этом разделе для вас нет доступных функций.", show_alert=True)
        return
    title, markup = res
    await show(cb, f"{title}\n\nВыберите действие:", markup)


# ============================== Задания (участник) ==============================
STATUS_TEXT = {"active": "🟢 Активно", "done": "✅ Выполнено — идёт приём работ", "cancelled": "❌ Не действительно",
               "closed": "🗂 Закрыто", "gone": "🗑 Сообщение удалено", "deleted": "🗑 Удалено"}


def task_text(t: dict) -> str:
    lines = [f"📋 Задание #{t['id']}" + (f" · aid{t['aid']}" if t["aid"] else ""),
             f"Для: {perms.POS_NAMES.get(t['pos'], '👥 Для всех')}",
             f"Статус: {STATUS_TEXT.get(t['status'], t['status'])}"]
    if t["status"] == "done" and t["done_at"]:
        until = t["done_at"] + logic.grace_seconds(db.grace_hours())
        lines.append(f"Работы принимаются до: {logic.fmt_ts(until)} (МСК)")
    lines += ["", t["text"]]
    return "\n".join(lines)


async def show_task(cb: CallbackQuery, t: dict, markup) -> None:
    """Показать задание: с фото — фото уходит С ПОДПИСЬЮ (текст задания), без фото — обычный экран."""
    if t.get("photo"):
        await send_rich(cb.from_user.id, task_text(t), photo=t["photo"], markup=markup)
    else:
        await show(cb, clip(task_text(t)), markup)


@router.callback_query(F.data == "tasks")
async def tasks_list(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    u = db.get_user(cb.from_user.id)
    items = [t for t in db.open_tasks() if tf.visible_for(t["pos"], u["pos"])]
    head = "📋 Задания"
    rows = []
    if not u["pos"]:
        head += "\n⚠️ Должность не выбрана — показаны только общие задания."
        rows.append([("💼 Выбрать должность", "pos")])
    if not items:
        rows.append([("🏠 Меню", "menu")])
        await show(cb, head + "\n\nСейчас заданий нет.", kb(*rows))
        return
    for t in items[:30]:
        mark = ("✅" if t["status"] == "done" else "🔹") + ("🖼" if t["photo"] else "")
        rows.append([(f"{mark} #{t['id']} {preview(t['text'], 38)}", f"tv:{t['id']}")])
    rows.append([("🏠 Меню", "menu")])
    await show(cb, head + f"\n\nДоступно: {len(items)}. Выберите задание:", kb(*rows))


@router.callback_query(F.data.startswith("tv:"))
async def task_view(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    t = db.get_task(int(cb.data.split(":")[1]))
    u = db.get_user(cb.from_user.id)
    if not t or t["final"] or t["status"] not in ("active", "done"):
        await cb.answer("Это задание уже закрыто.", show_alert=True)
        return
    if not tf.visible_for(t["pos"], u["pos"]):
        await cb.answer("⛔ Это задание для другой должности.", show_alert=True)
        return
    await show_task(cb, t, kb([("📤 Сдать работу", f"wsub:{t['id']}")], [("🔙 К заданиям", "tasks")]))


# ============================== Должность и профиль ==============================
@router.callback_query(F.data == "pos")
async def pos_menu(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    u = db.get_user(cb.from_user.id)
    rows = [[(("✅ " if u["pos"] == p else "") + perms.POS_NAMES[p], f"setpos:{p}")] for p in perms.POS_ORDER]
    rows.append([("🏠 Меню", "menu")])
    await show(cb, f"💼 Ваша должность: {pos_label(u['pos'])}\n\nОт неё зависят задания, которые вы видите. Выберите:", kb(*rows))


@router.callback_query(F.data.startswith("setpos:"))
async def set_pos(cb: CallbackQuery):
    pos = cb.data.split(":")[1]
    if pos not in perms.POS_NAMES:
        await cb.answer("Неизвестная должность.", show_alert=True)
        return
    db.set_user(cb.from_user.id, pos=pos)
    await show(cb, f"✅ Должность сохранена: {perms.POS_NAMES[pos]}", kb([("📋 К заданиям", "tasks"), ("🏠 Меню", "menu")]))


@router.callback_query(F.data == "prof")
async def profile(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    u = db.get_user(cb.from_user.id)
    role = perms.ROLE_NAMES[u["role"]]
    if u["role"] == "admin":
        role += f" ({perms.ADMIN_LEVELS.get(u['admin_level'], '—')})"
    text = (f"👤 Профиль\n\nИмя: {fmt_user(u)}\nID: {u['id']}\nРоль: {role}\n"
            f"Должность: {pos_label(u['pos'])}\nСтатус: {status_label(u['status'])}\nБаллов: {u['points']}")
    prog = progress_line(u)
    if prog:
        text += "\n\n" + prog
    await show(cb, text, kb([("📤 Мои работы", "mywk"), ("📝 Мои формы", "myforms")], [("💼 Должность", "pos")], [("🏠 Меню", "menu")]))


# ============================== Задания (админ) ==============================
@router.callback_query(F.data == "tadd")
async def tadd(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_add"):
        return
    await state.clear()
    if not db.place()[0]:
        await cb.answer("Место публикации не задано. Раздел «Задания» → «Место публикации».", show_alert=True)
        return
    if db.list_templates():
        await show(cb, "➕ Новое задание. Как создаём?", kb(
            [("✏️ Написать новое", "tnew")], [("📑 Из шаблона", "tplpick")], [("🔙 Назад", "sec:tasks")]))
        return
    await _ask_task_text(cb, state)


@router.callback_query(F.data == "tnew")
async def tnew(cb: CallbackQuery, state: FSMContext):
    if await need(cb, "tasks_add"):
        await _ask_task_text(cb, state)


async def _ask_task_text(cb: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AddTask.text)
    await show(cb, "✏️ Отправьте текст задания.\n\n🖼 Хотите приложить фото — отправьте фото, а текст задания "
                   "напишите в подписи: оно дойдёт до участников с подписью.\n\nБот опубликует задание в группе с "
                   "кнопками «✅ Выполнено» / «❌ Не действительно». Если в тексте уже есть метка "
                   "aid<номер>_<код>, она будет использована как есть.", kb([("↩️ Отмена", "sec:tasks")]))


@router.message(AddTask.text, F.text | F.photo)
async def tadd_text(m: Message, state: FSMContext):
    if not await need(m, "tasks_add"):
        await state.clear()
        return
    text = (m.text or m.caption or "").strip()
    photo = m.photo[-1].file_id if m.photo else None
    if not text:
        await m.answer("⚠️ У фото нет подписи. Отправьте фото ещё раз и напишите текст задания в подписи.")
        return
    aid, pos, labeled = tf.classify(text)
    if labeled:
        await _publish(m, state, text, aid, pos, photo)
        return
    await state.update_data(text=text, photo=photo)
    rows = [[(perms.POS_NAMES[p], f"tpos:{perms.CODE_BY_POS[p]}")] for p in perms.POS_ORDER]
    rows.append([("👥 Для всех", "tpos:0")])
    rows.append([("↩️ Отмена", "sec:tasks")])
    await m.answer("💼 Для какой должности задание?", reply_markup=kb(*rows))


@router.message(AddTask.text)
async def tadd_bad(m: Message):
    await m.answer("⚠️ Задание — это текст или фото с подписью. Отправьте текст задания:")


@router.callback_query(F.data.startswith("tpos:"))
async def tadd_pos(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_add"):
        return
    d = await state.get_data()
    if not d.get("text"):
        await cb.answer("Сессия создания устарела. Начните заново.", show_alert=True)
        return
    pos = perms.POS_BY_CODE[cb.data.split(":")[1]]
    aid, text = prepare_task(d["text"], pos)
    await _publish(cb, state, text, aid, pos, d.get("photo"))


async def _publish(target, state: FSMContext, text: str, aid, pos, photo) -> None:
    tid, err = await publish_task(text, aid, pos, photo)
    if err:
        await show(target, "❌ " + err, kb([("🔙 Назад", "sec:tasks")]))
        return
    await state.clear()
    await show(target, f"✅ Задание #{tid} опубликовано в группе ({perms.POS_NAMES.get(pos, 'для всех')}).",
               kb([("➕ Ещё задание", "tadd"), ("📌 Активные", "tact")], [("🔙 К разделу", "sec:tasks")]))


# --- Активные задания: закрыть / удалить в любой момент ---
async def _tact_screen(cb: CallbackQuery) -> None:
    items = db.open_tasks()
    rows = [[(f"{'✅' if t['status'] == 'done' else '🟢'}{'🖼' if t['photo'] else ''} #{t['id']} {preview(t['text'], 33)}",
              f"ta:{t['id']}")] for t in items[:30]]
    rows.append([("🔙 Назад", "sec:tasks")])
    await show(cb, "📌 Активные задания (🟢 активно, ✅ идёт приём работ)\nНажмите на задание, чтобы закрыть, удалить "
                   "или изменить его." if items else "📌 Активных заданий нет.", kb(*rows))


@router.callback_query(F.data == "tact")
async def tact(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_close"):
        return
    await state.clear()
    await _tact_screen(cb)


async def _task_card(cb: CallbackQuery, tid: int) -> None:
    t = db.get_task(tid)
    if not t:
        await cb.answer("Задание не найдено.", show_alert=True)
        return
    text = task_text(t) + f"\n\n📤 Работ сдано: {len(db.works_of_task(tid))}"
    is_open = t["status"] in ("active", "done") and not t["final"]
    rows = []
    if t["status"] == "active":
        rows.append([("✅ Выполнено", f"tdone:{tid}"), ("❌ Не действительно", f"tcancel:{tid}")])
    elif is_open:
        rows.append([("❌ Не действительно", f"tcancel:{tid}")])
    if is_open:
        rows.append([("🔒 Закрыть и убрать из группы сейчас", f"tclose:{tid}")])
        rows.append([("🗑 Удалить задание", f"tdel:{tid}")])
        edit = [("💼 Сменить должность", f"tchp:{tid}")]
        if t["src"] == "bot" and t["status"] == "active":
            edit.append(("✏️ Изменить текст", f"tedt:{tid}"))
        rows.append(edit)
    rows.append([("🔙 К заданиям", "tact")])
    await show_task_card(cb, t, text, kb(*rows))


async def show_task_card(cb: CallbackQuery, t: dict, text: str, markup) -> None:
    if t.get("photo"):
        await send_rich(cb.from_user.id, text, photo=t["photo"], markup=markup)
    else:
        await show(cb, clip(text), markup)


@router.callback_query(F.data.startswith("ta:"))
async def task_admin_card(cb: CallbackQuery):
    if await need(cb, "tasks_close"):
        await _task_card(cb, int(cb.data.split(":")[1]))


@router.callback_query(F.data.regexp(r"^t(done|cancel|close):\d+$"))
async def cb_close(cb: CallbackQuery):
    """✅ / ❌ — под сообщением бота в группе; 🔒 — в карточке. Работает и во время приёма работ."""
    how, tid = cb.data.split(":")
    if not has_perm(cb.from_user.id, "tasks_close"):
        await cb.answer("⛔ Нет разрешения: «Закрывать задания».", show_alert=True)
        return
    ok, msg = await finish_task(int(tid), how[1:], cb.from_user.id)
    await cb.answer(msg[:190], show_alert=True)
    if cb.message and cb.message.chat.type == "private":
        t = db.get_task(int(tid))
        if t and t["status"] in ("active", "done") and not t["final"]:
            await _task_card(cb, int(tid))
        else:
            await _tact_screen(cb)


@router.callback_query(F.data.startswith("tdel:"))
async def tdel(cb: CallbackQuery):
    if not await need(cb, "tasks_close"):
        return
    tid = int(cb.data.split(":")[1])
    await show(cb, f"🗑 Удалить задание #{tid}? Сообщение в группе будет удалено, задание пропадёт из списков "
                   f"(сданные работы останутся в базе).",
               kb([("✅ Да, удалить", f"tdely:{tid}")], [("↩️ Нет", f"ta:{tid}")]))


@router.callback_query(F.data.startswith("tdely:"))
async def tdely(cb: CallbackQuery):
    if not await need(cb, "tasks_close"):
        return
    ok, msg = await finish_task(int(cb.data.split(":")[1]), "delete", cb.from_user.id)
    await cb.answer(msg[:190], show_alert=True)
    await _tact_screen(cb)


# --- Смена должности и текста задания ---
@router.callback_query(F.data.startswith("tchp:"))
async def tchp(cb: CallbackQuery):
    if not await need(cb, "tasks_close"):
        return
    tid = int(cb.data.split(":")[1])
    rows = [[(perms.POS_NAMES[p], f"tchs:{tid}:{perms.CODE_BY_POS[p]}")] for p in perms.POS_ORDER]
    rows.append([("👥 Для всех", f"tchs:{tid}:0")])
    rows.append([("🔙 Назад", f"ta:{tid}")])
    await show(cb, "💼 Для какой должности теперь это задание?", kb(*rows))


async def _edit_task_message(t: dict, text: str) -> str:
    """Правка сообщения бота в группе (с фото — подписи). Возвращает текст ошибки или ''."""
    bot = get_bot()
    try:
        if t["photo"]:
            await bot.edit_message_caption(chat_id=t["chat_id"], message_id=t["msg_id"], caption=text,
                                           reply_markup=task_kb(t["id"]))
        else:
            await bot.edit_message_text(text, chat_id=t["chat_id"], message_id=t["msg_id"],
                                        reply_markup=task_kb(t["id"]))
    except TelegramBadRequest as e:
        return "" if "not modified" in str(e).lower() else err_text(e)
    except TelegramForbiddenError as e:
        return err_text(e)
    return ""


@router.callback_query(F.data.startswith("tchs:"))
async def tchs(cb: CallbackQuery):
    if not await need(cb, "tasks_close"):
        return
    _, tid, code = cb.data.split(":")
    t = db.get_task(int(tid))
    if not t or code not in perms.POS_BY_CODE:
        await cb.answer("Задание не найдено.", show_alert=True)
        return
    pos = perms.POS_BY_CODE[code]
    text = t["text"]
    if t["src"] == "bot" and t["status"] == "active" and not t["final"] and t["aid"] is not None \
            and tf.LABEL_RE.search(text):
        text = tf.LABEL_RE.sub(tf.make_label(t["aid"], pos), text, count=1)
        err = await _edit_task_message(t, text)
        if err:
            await cb.answer(f"Не удалось изменить сообщение в группе: {err}"[:190], show_alert=True)
            return
    db.set_task(t["id"], pos=pos, text=text)
    await cb.answer("Должность изменена.")
    await _task_card(cb, t["id"])


@router.callback_query(F.data.startswith("tedt:"))
async def tedt(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_close"):
        return
    t = db.get_task(int(cb.data.split(":")[1]))
    if not t or t["src"] != "bot" or t["status"] != "active" or t["final"]:
        await cb.answer("Текст можно менять только у активных заданий, опубликованных ботом.", show_alert=True)
        return
    await state.set_data({"tid": t["id"]})
    await state.set_state(EditTask.text)
    await show(cb, f"✏️ Текущий текст:\n\n{t['text']}\n\nОтправьте новый текст задания (метка aid останется):",
               kb([("↩️ Отмена", f"ta:{t['id']}")]))


@router.message(EditTask.text, F.text)
async def tedt_text(m: Message, state: FSMContext):
    if not await need(m, "tasks_close"):
        await state.clear()
        return
    t = db.get_task((await state.get_data()).get("tid", 0))
    if not t or t["src"] != "bot" or t["status"] != "active" or t["final"]:
        await state.clear()
        await m.answer("⚠️ Задание уже закрыто или изменилось — текст изменить нельзя.")
        return
    text = m.text.strip()
    if t["aid"] is not None and not tf.parse_label(text):
        text = f"{tf.make_label(t['aid'], t['pos'])}\n{text}"
    if t["photo"] and len(text) > 1024:
        await m.answer(f"⚠️ С фото текст не может быть длиннее 1024 символов (сейчас {len(text)}). Сократите:")
        return
    err = await _edit_task_message(t, text)
    if err:
        await m.answer(f"❌ Не удалось изменить сообщение в группе: {err}")
        return
    db.set_task(t["id"], text=text)
    await state.clear()
    await m.answer("✅ Текст задания изменён и обновлён в группе.", reply_markup=kb([("📌 К заданию", f"ta:{t['id']}")]))


@router.message(EditTask.text)
async def tedt_bad(m: Message):
    await m.answer("⚠️ Нужен текст. Отправьте новый текст задания:")


# --- Время приёма работ ---
GRACE_CHOICES = [1, 3, 6, 12, 24, 48, 72]


@router.callback_query(F.data == "grace")
async def grace(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_close"):
        return
    await state.clear()
    cur = db.grace_hours()
    row1 = [((f"✅ {h} ч" if cur == h else f"{h} ч"), f"gr:{h}") for h in GRACE_CHOICES[:4]]
    row2 = [((f"✅ {h} ч" if cur == h else f"{h} ч"), f"gr:{h}") for h in GRACE_CHOICES[4:]]
    await show(cb, f"⏱ Время приёма работ\n\nПосле «✅ Выполнено» работы принимаются {logic.fmt_hours(cur)}, "
                   f"затем сообщение задания удаляется из группы. Выберите срок или введите свой:",
               kb(row1, row2, [("✏️ Своё количество часов", "grc")], [("🔙 Назад", "sec:tasks")]))


@router.callback_query(F.data.startswith("gr:"))
async def grace_pick(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_close"):
        return
    db.set_setting("grace_hours", cb.data.split(":")[1])
    await cb.answer("Сохранено.")
    await grace(cb, state)


@router.callback_query(F.data == "grc")
async def grace_custom(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_close"):
        return
    await state.set_state(Grace.hours)
    await show(cb, "✏️ Введите количество часов (от 0.1 до 720), например 24 или 1.5:", kb([("↩️ Отмена", "grace")]))


@router.message(Grace.hours, F.text)
async def grace_set(m: Message, state: FSMContext):
    if not await need(m, "tasks_close"):
        await state.clear()
        return
    try:
        hours = float(m.text.strip().replace(",", "."))
    except ValueError:
        await m.answer("⚠️ Это не число. Введите количество часов, например 24 или 1.5:")
        return
    if not 0.1 <= hours <= 720:
        await m.answer("⚠️ Допустимо от 0.1 до 720 часов. Введите ещё раз:")
        return
    db.set_setting("grace_hours", f"{hours:g}")
    await state.clear()
    await m.answer(f"✅ Готово. Теперь после «Выполнено» работы принимаются {logic.fmt_hours(hours)}, "
                   f"затем сообщение задания удаляется.", reply_markup=kb([("⏱ К настройке", "grace")]))


@router.message(Grace.hours)
async def grace_bad(m: Message):
    await m.answer("⚠️ Нужно число часов. Введите, например, 24:")


# --- Место публикации ---
def _place_text() -> str:
    chat, thread = db.place()
    if not chat:
        return ("📍 Место публикации не задано.\n\nДобавьте бота в группу (админом с правом «Удалять сообщения»), "
                "затем выберите её ниже. Тему можно задать командой /here, отправленной в нужной теме.")
    return (f"📍 Место публикации\nГруппа: {db.group_title(chat)} ({chat})\n"
            f"Тема: {thread if thread else 'без темы (вся группа)'}\n\n"
            f"Отсюда бот читает задания, сюда публикует задания и напоминания.\n"
            f"Тему можно сменить, отправив /here в нужной теме группы.")


async def _place_screen(cb: CallbackQuery, extra: str = "") -> None:
    chat, _ = db.place()
    rows = [[(("✅ " if g["chat_id"] == chat else "") + preview(g["title"], 40), f"pl:{g['chat_id']}")]
            for g in db.list_groups()[:30]]
    if chat:
        rows.append([("🧵 Ввести тему (ссылка/ID)", "plt:in"), ("Без темы", "plt:none")])
    rows.append([("🔙 Назад", "sec:tasks")])
    await show(cb, _place_text() + (f"\n\n{extra}" if extra else ""), kb(*rows))


@router.callback_query(F.data == "place")
async def place(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "place_set"):
        return
    await state.clear()
    await _place_screen(cb)


@router.callback_query(F.data.startswith("pl:"))
async def place_pick(cb: CallbackQuery):
    if not await need(cb, "place_set"):
        return
    chat_id = int(cb.data.split(":")[1])
    db.set_setting("dest_chat", chat_id)
    db.del_setting("dest_thread")
    warn = await check_bot_rights(chat_id)
    await _place_screen(cb, ("⚠️ " + warn) if warn else "✅ Группа выбрана. Бот — админ с правом удаления сообщений.")


@router.callback_query(F.data == "plt:none")
async def place_nothread(cb: CallbackQuery):
    if not await need(cb, "place_set"):
        return
    db.del_setting("dest_thread")
    await _place_screen(cb, "✅ Тема сброшена.")


@router.callback_query(F.data == "plt:in")
async def place_thread_in(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "place_set"):
        return
    await state.set_state(PlaceTopic.thread)
    await show(cb, "🧵 Пришлите ссылку на тему (https://t.me/c/1234567890/123) или числовой ID темы.\n"
                   "Проще всего — отправить /here прямо в нужной теме группы.", kb([("↩️ Отмена", "place")]))


@router.message(PlaceTopic.thread, F.text)
async def place_thread_set(m: Message, state: FSMContext):
    if not await need(m, "place_set"):
        await state.clear()
        return
    chat, thread, err = parse_topic(m.text, db.place()[0])
    if err:
        await m.answer("⚠️ " + err)
        return
    if not chat:
        await m.answer("⚠️ Сначала выберите группу, а потом задайте тему.")
        return
    db.set_setting("dest_chat", chat)
    db.set_setting("dest_thread", thread)
    await state.clear()
    await m.answer(f"✅ Тема сохранена: {thread}.", reply_markup=kb([("📍 Место публикации", "place")]))


@router.message(PlaceTopic.thread)
async def place_thread_bad(m: Message):
    await m.answer("⚠️ Пришлите ссылку или ID темы текстом.")


@router.message(Command("here"), F.chat.type == "private")
async def here_private(m: Message):
    await m.answer("⚠️ Команду /here нужно отправить в группе — в той теме, которую хотите сделать местом публикации.")


@router.message(Command("here"), F.chat.type.in_(GROUPS))
async def here_group(m: Message):
    if not m.from_user or not has_perm(m.from_user.id, "place_set"):
        await m.reply("⛔ Нет разрешения: «Задавать место публикации».")
        return
    thread = m.message_thread_id if m.is_topic_message else None
    db.set_setting("dest_chat", m.chat.id)
    if thread:
        db.set_setting("dest_thread", thread)
    else:
        db.del_setting("dest_thread")
    db.save_group(m.chat.id, m.chat.title)
    warn = await check_bot_rights(m.chat.id)
    text = f"✅ Место публикации: «{m.chat.title}», {'тема ' + str(thread) if thread else 'без темы'}."
    await m.reply(text + (f"\n⚠️ {warn}" if warn else "\nБот — админ с правом удаления сообщений, всё готово."))


# --- Статистика ---
@router.callback_query(F.data == "stat")
async def stat(cb: CallbackQuery):
    if not await need(cb, "stats_view"):
        return
    s = db.stats()
    place_txt = f"{db.group_title(s['chat'])}, тема {s['thread'] or '—'}" if s["chat"] else "не задано"
    await show(cb, (f"📊 Статистика\n\n👥 Участников: {s['users']}\n🚫 Забаненных: {s['banned']}\n"
                    f"📚 Материалов: {s['materials']}\n📢 Объявлений: {s['announcements']}\n"
                    f"📌 Активных заданий: {s['tasks_active']} (приём работ: {s['tasks_waiting']})\n"
                    f"📤 Работ: {s['works']} (на проверке: {s['works_pending']})\n"
                    f"⏰ Напоминаний: {s['reminders']} (включено: {s['reminders_active']})\n"
                    f"📍 Место публикации: {place_txt}\n⏱ Приём работ после «Выполнено»: "
                    f"{logic.fmt_hours(db.grace_hours())}"), kb([("🔙 Назад", "sec:settings")]))


# ============================== Участники, права, баны ==============================
@router.callback_query(F.data.startswith("usr:"))
async def users_list(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "users_view"):
        return
    await state.clear()
    page = int(cb.data.split(":")[1])
    rows_db, total = db.users_page(page)
    rows = [[(f"{preview(fmt_user(u), 26)} · {u['points']}", f"u:{u['id']}")] for u in rows_db]
    pg = pager_row("usr", page, total, 10)
    if pg:
        rows.append(pg)
    rows.append([("🔙 Назад", "sec:people")])
    await show(cb, f"👥 Участники: {total} (по баллам)", kb(*rows))


def user_card(actor_id: int, tid: int):
    t = db.get_user(tid)
    role = perms.ROLE_NAMES.get(t["role"], "не вошёл в бота")
    if t["role"] == "admin":
        role += f" ({perms.ADMIN_LEVELS.get(t['admin_level'], '—')})"
    lines = [f"👤 {fmt_user(t)}", f"ID: {t['id']}", f"Роль: {role}", f"Должность: {pos_label(t['pos'])}",
             f"Статус: {status_label(t['status'])}", f"Баллов: {t['points']}"]
    if t["banned"]:
        lines.append(f"🚫 Забанен ({'из-за бана в группе' if t['ban_src'] == 'group' else 'вручную'})")
    if t["role"] == "admin":
        pl = db.perms_of(t)
        lines.append("Права: " + (", ".join(perms.PERMS[p] for p in pl if p in perms.PERMS) or "нет"))
    manage = can_manage(actor_id, tid)
    is_owner = has_perm(actor_id, "owner")
    rows = []
    if has_perm(actor_id, "points_edit") and t["role"]:
        rows.append([("⭐ Баллы", f"padju:{tid}")])
    if manage and has_perm(actor_id, "users_status") and t["role"] and t["role"] != "owner":
        rows.append([("🏅 Сменить статус", f"ustat:{tid}")])
    if manage and has_perm(actor_id, "users_ban"):
        rows.append([("✅ Разбанить" if t["banned"] else "🚫 Забанить", f"{'uunban' if t['banned'] else 'uban'}:{tid}")])
    if manage and has_perm(actor_id, "perms_edit") and t["role"] == "admin":
        rows.append([("🔑 Права", f"uperm:{tid}")])
    if is_owner and manage:
        if t["role"] == "admin":
            rows.append([("🎚 Уровень админа", f"ulvl:{tid}"), ("➖ Снять админа", f"uadmrm:{tid}")])
        elif t["role"] == "user" and not t["banned"]:
            rows.append([("➕ Назначить админом", f"uadm:{tid}")])
    rows.append([("🔙 К списку", "usr:0")])
    return "\n".join(lines), kb(*rows)


async def _show_card(cb: CallbackQuery, tid: int) -> None:
    if not db.get_user(tid):
        await cb.answer("Пользователь не найден.", show_alert=True)
        return
    text, markup = user_card(cb.from_user.id, tid)
    await show(cb, text, markup)


@router.callback_query(F.data.startswith("u:"))
async def user_open(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "users_view"):
        return
    await state.clear()
    await _show_card(cb, int(cb.data.split(":")[1]))


async def _guard_target(cb: CallbackQuery, perm: str, tid: int) -> bool:
    """Проверка: есть разрешение и цель ниже по уровню."""
    if not await need(cb, perm):
        return False
    if not db.get_user(tid):
        await cb.answer("Пользователь не найден.", show_alert=True)
        return False
    if not can_manage(cb.from_user.id, tid):
        await cb.answer("⛔ Менять и банить можно только тех, кто ниже вас по уровню "
                        "(и нельзя действовать над самим собой).", show_alert=True)
        return False
    return True


@router.callback_query(F.data.startswith("ustat:"))
async def ustat(cb: CallbackQuery):
    tid = int(cb.data.split(":")[1])
    if not await _guard_target(cb, "users_status", tid):
        return
    rows = [[(status_label(s), f"us:{tid}:{s}")] for s in perms.STATUS_ORDER]
    rows.append([("🔙 Назад", f"u:{tid}")])
    await show(cb, "🏅 Выберите новый статус:", kb(*rows))


@router.callback_query(F.data.startswith("us:"))
async def us_set(cb: CallbackQuery):
    _, tid, status = cb.data.split(":")
    tid = int(tid)
    if status not in perms.STATUS_ORDER or not await _guard_target(cb, "users_status", tid):
        return
    db.set_user(tid, status=status)
    await notify(tid, f"🏅 Ваш статус изменён: {status_label(status)}")
    await _show_card(cb, tid)


@router.callback_query(F.data.startswith("uban:"))
async def uban(cb: CallbackQuery):
    tid = int(cb.data.split(":")[1])
    if not await _guard_target(cb, "users_ban", tid):
        return
    ban_user(tid, "manual")
    await notify(tid, "⛔ Вас заблокировали в боте. Доступ закрыт.")
    await _show_card(cb, tid)


@router.callback_query(F.data.startswith("uunban:"))
async def uunban(cb: CallbackQuery):
    tid = int(cb.data.split(":")[1])
    if not await _guard_target(cb, "users_ban", tid):
        return
    unban_user(tid)
    await notify(tid, "✅ Доступ к боту восстановлен. Все права сброшены — вы снова обычный участник.")
    await _show_card(cb, tid)


@router.callback_query(F.data == "banl")
async def banned_list(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "users_ban"):
        return
    await state.clear()
    users = db.banned_users()
    rows = [[(f"🚫 {preview(fmt_user(u), 28)} · {'группа' if u['ban_src'] == 'group' else 'вручную'}", f"u:{u['id']}")]
            for u in users[:40]]
    rows.append([("🔙 Назад", "sec:people")])
    await show(cb, f"🚫 Забаненные: {len(users)}" if users else "🚫 Забаненных нет.", kb(*rows))


# --- Права админов ---
def _perms_screen(tid: int):
    t = db.get_user(tid)
    have = db.perms_of(t)
    rows = [[(("✅ " if p in have else "⬜ ") + label, f"pt:{tid}:{p}")] for p, label in perms.PERMS.items()]
    rows.append([("🔙 Назад", f"u:{tid}")])
    return f"🔑 Права: {fmt_user(t)}\nНажмите на право, чтобы включить или выключить:", kb(*rows)


@router.callback_query(F.data.startswith("uperm:"))
async def uperm(cb: CallbackQuery):
    tid = int(cb.data.split(":")[1])
    if not await _guard_target(cb, "perms_edit", tid):
        return
    if db.get_user(tid)["role"] != "admin":
        await cb.answer("Права настраиваются только у админов.", show_alert=True)
        return
    text, markup = _perms_screen(tid)
    await show(cb, text, markup)


@router.callback_query(F.data.startswith("pt:"))
async def perm_toggle(cb: CallbackQuery):
    _, tid, perm = cb.data.split(":")
    tid = int(tid)
    if perm not in perms.PERMS or not await _guard_target(cb, "perms_edit", tid):
        return
    t = db.get_user(tid)
    if t["role"] != "admin":
        await cb.answer("Права настраиваются только у админов.", show_alert=True)
        return
    have = db.perms_of(t)
    if perm in have:
        have.remove(perm)
    else:
        if not has_perm(cb.from_user.id, perm):
            await cb.answer("⛔ Нельзя выдать право, которого нет у вас самих.", show_alert=True)
            return
        have.append(perm)
    db.set_perms(tid, have)
    text, markup = _perms_screen(tid)
    await show(cb, text, markup)


# --- Управление админами (только владелец) ---
@router.callback_query(F.data == "adms")
async def admins_list(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "owner"):
        return
    await state.clear()
    rows = [[("➕ Назначить админа", "admp:0")]]
    for u in db.admins():
        rows.append([(f"{preview(fmt_user(u), 28)} · {perms.ADMIN_LEVELS.get(u['admin_level'], '—')}", f"u:{u['id']}")])
    rows.append([("🔙 Назад", "sec:owner")])
    await show(cb, "👑 Админы\n\nУровни: младший → средний → старший. Менять и банить можно только тех, "
                   "кто ниже по уровню. Нажмите на админа, чтобы изменить права, уровень или снять его.", kb(*rows))


@router.callback_query(F.data.startswith("admp:"))
async def adm_pick(cb: CallbackQuery, state: FSMContext):
    """Выбор будущего админа из списка участников — без ручного ввода ID."""
    if not await need(cb, "owner"):
        return
    await state.clear()
    page, size = int(cb.data.split(":")[1]), 8
    total = db.one("SELECT COUNT(*) AS c FROM users WHERE role='user' AND banned=0")["c"]
    users = db.q("SELECT * FROM users WHERE role='user' AND banned=0 ORDER BY points DESC, name LIMIT ? OFFSET ?",
                 (size, page * size))
    rows = [[(preview(fmt_user(u), 32) + f" · {u['points']}", f"uadm:{u['id']}")] for u in users]
    pg = pager_row("admp", page, total, size)
    if pg:
        rows.append(pg)
    rows.append([("🔎 Ввести ID или @username", "admadd")])
    rows.append([("🔙 Назад", "adms")])
    await show(cb, "👑 Кого назначить админом? Выберите участника (младший уровень, стандартные права — "
                   "потом их можно изменить):" if users else
               "👑 Обычных участников нет. Человек должен сначала войти в бота (/start и пароль).", kb(*rows))


@router.callback_query(F.data == "admadd")
async def adm_add(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "owner"):
        return
    await state.set_state(AdmAdd.ident)
    await show(cb, "👑 Введите ID или @username человека, которого назначить админом.\n"
                   "Он должен хотя бы раз войти в бота.", kb([("↩️ Отмена", "adms")]))


def _assign_admin(uid: int) -> None:
    db.set_user(uid, role="admin", admin_level="junior", perms=json.dumps(perms.DEFAULT_ADMIN_PERMS))


@router.message(AdmAdd.ident, F.text)
async def adm_add_ident(m: Message, state: FSMContext):
    if not await need(m, "owner"):
        await state.clear()
        return
    u = db.find_user(m.text)
    if not u or not u["role"]:
        await m.answer("⚠️ Человек не найден или ещё не входил в бота. Введите ID/@username ещё раз:")
        return
    if u["banned"]:
        await m.answer("⚠️ Этот человек забанен. Сначала разбаньте его в разделе «Забаненные».")
        return
    if u["role"] != "user":
        await m.answer(f"ℹ️ {fmt_user(u)} уже {perms.ROLE_NAMES[u['role']].lower()}.")
        return
    _assign_admin(u["id"])
    await state.clear()
    await notify(u["id"], "👑 Вас назначили админом (младший уровень). Откройте /menu — там появилось меню админа.")
    text, markup = user_card(m.from_user.id, u["id"])
    await m.answer("✅ Админ назначен.\n\n" + text, reply_markup=markup)


@router.message(AdmAdd.ident)
async def adm_add_bad(m: Message):
    await m.answer("⚠️ Нужен текст: ID или @username.")


@router.callback_query(F.data.startswith("uadm:"))
async def uadm(cb: CallbackQuery):
    tid = int(cb.data.split(":")[1])
    if not await _guard_target(cb, "owner", tid):
        return
    t = db.get_user(tid)
    if t["role"] != "user" or t["banned"]:
        await cb.answer("Назначить можно только обычного пользователя без бана.", show_alert=True)
        return
    _assign_admin(tid)
    await notify(tid, "👑 Вас назначили админом (младший уровень). Откройте /menu.")
    await _show_card(cb, tid)


@router.callback_query(F.data.startswith("uadmrm:"))
async def uadmrm(cb: CallbackQuery):
    tid = int(cb.data.split(":")[1])
    if not await _guard_target(cb, "owner", tid):
        return
    if db.get_user(tid)["role"] != "admin":
        await cb.answer("Этот человек не админ.", show_alert=True)
        return
    db.set_user(tid, role="user", admin_level=None, perms="[]")
    db.clear_curator_user(tid)
    await notify(tid, "ℹ️ Вас сняли с роли админа. Вам доступны функции обычного участника.")
    await _show_card(cb, tid)


@router.callback_query(F.data.startswith("ulvl:"))
async def ulvl(cb: CallbackQuery):
    tid = int(cb.data.split(":")[1])
    if not await _guard_target(cb, "owner", tid):
        return
    rows = [[(perms.ADMIN_LEVELS[k] + (" ✅" if db.get_user(tid)["admin_level"] == k else ""), f"ul:{tid}:{k}")]
            for k in ("junior", "middle", "senior")]
    rows.append([("🔙 Назад", f"u:{tid}")])
    await show(cb, "🎚 Уровень админа определяет иерархию: старший может менять и банить среднего и младшего и т. д.",
               kb(*rows))


@router.callback_query(F.data.startswith("ul:"))
async def ul_set(cb: CallbackQuery):
    _, tid, level = cb.data.split(":")
    tid = int(tid)
    if level not in perms.ADMIN_LEVELS or not await _guard_target(cb, "owner", tid):
        return
    if db.get_user(tid)["role"] != "admin":
        await cb.answer("Уровень есть только у админов.", show_alert=True)
        return
    db.set_user(tid, admin_level=level)
    await notify(tid, f"🎚 Ваш уровень админа: {perms.ADMIN_LEVELS[level]}")
    await _show_card(cb, tid)


# ============================== Владелец: пароли и недельный отчёт ==============================
PW_ROLES = [("user", "Участник"), ("admin", "Админ"), ("owner", "Владелец")]


def _mask(pw: str) -> str:
    return pw[:2] + "•" * max(0, len(pw) - 2) + f" ({len(pw)} симв.)"


def _pw_screen(reveal: bool = False):
    lines = ["🔐 Пароли доступа\n",
             "Пароль нужен при /start и команде /login (чтобы получить роль). Уже вошедшие остаются в боте — "
             "смена пароля их не выкидывает.\n"]
    for role, label in PW_ROLES:
        pw = db.get_password(role)
        lines.append(f"{label}: {pw if reveal else _mask(pw)}")
    rows = [[(f"✏️ Сменить: {label}", f"pwc:{role}")] for role, label in PW_ROLES]
    rows.append([("🙈 Скрыть" if reveal else "👁 Показать пароли", "pws:hide" if reveal else "pws:show")])
    rows.append([("↩️ Вернуть значения по умолчанию", "pwr")])
    rows.append([("🔙 Назад", "sec:owner")])
    return "\n".join(lines), kb(*rows)


@router.callback_query(F.data.in_({"pws", "pws:show", "pws:hide"}))
async def pws(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "owner"):
        return
    await state.clear()
    text, markup = _pw_screen(cb.data == "pws:show")
    await show(cb, text, markup)


@router.callback_query(F.data.startswith("pwc:"))
async def pwc(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "owner"):
        return
    role = cb.data.split(":")[1]
    label = dict(PW_ROLES).get(role)
    if not label:
        await cb.answer("Неизвестная роль.", show_alert=True)
        return
    await state.set_data({"role": role})
    await state.set_state(PwChange.value)
    await show(cb, f"✏️ Введите новый пароль для роли «{label}».\nНе короче 6 символов, не должен совпадать с паролями "
                   f"других ролей. Сообщение с паролем бот сразу удалит.", kb([("↩️ Отмена", "pws")]))


@router.message(PwChange.value, F.text)
async def pw_set(m: Message, state: FSMContext):
    if not await need(m, "owner"):
        await state.clear()
        return
    role = (await state.get_data()).get("role")
    pw = m.text.strip()
    await _try_delete(m)
    if role not in dict(PW_ROLES):
        await state.clear()
        await m.answer("⚠️ Сессия устарела. Откройте «🔐 Пароли доступа» заново.")
        return
    if len(pw) < 6:
        await m.answer("⚠️ Пароль слишком короткий — нужно минимум 6 символов. Введите другой:")
        return
    if pw in [db.get_password(r) for r, _ in PW_ROLES if r != role]:
        await m.answer("⚠️ Такой пароль уже у другой роли. Введите другой:")
        return
    db.set_password(role, pw)
    await state.clear()
    text, markup = _pw_screen(False)
    await m.answer(f"✅ Пароль роли «{dict(PW_ROLES)[role]}» изменён.\n\n{text}", reply_markup=markup)


@router.message(PwChange.value)
async def pw_bad(m: Message):
    await m.answer("⚠️ Пароль нужно ввести текстом.")


@router.callback_query(F.data == "pwr")
async def pw_reset(cb: CallbackQuery):
    if not await need(cb, "owner"):
        return
    await show(cb, "↩️ Вернуть все три пароля к значениям по умолчанию (из настроек запуска)?",
               kb([("✅ Да, вернуть", "pwry")], [("↩️ Нет", "pws")]))


@router.callback_query(F.data == "pwry")
async def pw_reset_yes(cb: CallbackQuery):
    if not await need(cb, "owner"):
        return
    for role, _ in PW_ROLES:
        db.reset_password(role)
    text, markup = _pw_screen(False)
    await show(cb, "✅ Пароли возвращены к значениям по умолчанию.\n\n" + text, markup)


DAYS_ACC = ["понедельник", "вторник", "среду", "четверг", "пятницу", "субботу", "воскресенье"]
REPORT_TIMES = ["09:00", "12:00", "13:00", "15:00", "18:00"]


def _rep_screen():
    on = db.get_setting("report_on") == "1"
    day = int(db.get_setting("report_day", "4"))
    t = db.get_setting("report_time", "13:00")
    text = (f"📆 Недельный отчёт владельцу\n\nСтатус: {'🟢 включён' if on else '⏸ выключен'}\n"
            f"Присылается: каждую неделю, в {DAYS_ACC[day]} в {t} по Москве\n\n"
            f"В отчёте: новые задания за неделю, сколько сдано работ, средняя оценка.")
    rows = [[("⏸ Выключить" if on else "▶️ Включить", "repon")],
            [(("✅" if i == day else "") + logic.WEEKDAYS[i], f"repd:{i}") for i in range(4)],
            [(("✅" if i == day else "") + logic.WEEKDAYS[i], f"repd:{i}") for i in range(4, 7)],
            [(("✅ " if x == t else "") + x, f"rpt:{x.replace(':', '')}") for x in REPORT_TIMES[:3]],
            [(("✅ " if x == t else "") + x, f"rpt:{x.replace(':', '')}") for x in REPORT_TIMES[3:]],
            [("✏️ Своё время", "rptc"), ("📨 Прислать сейчас", "repnow")],
            [("🔙 Назад", "sec:owner")]]
    return text, kb(*rows)


async def _rep_show(cb: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    text, markup = _rep_screen()
    await show(cb, text, markup)


@router.callback_query(F.data == "rep")
async def rep(cb: CallbackQuery, state: FSMContext):
    if await need(cb, "owner"):
        await _rep_show(cb, state)


@router.callback_query(F.data == "repon")
async def rep_toggle(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "owner"):
        return
    db.set_setting("report_on", "0" if db.get_setting("report_on") == "1" else "1")
    await _rep_show(cb, state)


@router.callback_query(F.data.startswith("repd:"))
async def rep_day(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "owner"):
        return
    day = int(cb.data.split(":")[1])
    if 0 <= day <= 6:
        db.set_setting("report_day", day)
    await _rep_show(cb, state)


@router.callback_query(F.data.startswith("rpt:"))
async def rep_time_pick(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "owner"):
        return
    raw = cb.data.split(":")[1]
    t = logic.parse_hhmm(f"{raw[:2]}:{raw[2:]}")
    if t:
        db.set_setting("report_time", t)
    await _rep_show(cb, state)


@router.callback_query(F.data == "rptc")
async def rep_time_custom(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "owner"):
        return
    await state.set_state(RepTime.value)
    await show(cb, "✏️ Введите время отчёта в формате ЧЧ:ММ (по Москве), например 13:00:", kb([("↩️ Отмена", "rep")]))


@router.message(RepTime.value, F.text)
async def rep_time_set(m: Message, state: FSMContext):
    if not await need(m, "owner"):
        await state.clear()
        return
    t = logic.parse_hhmm(m.text)
    if not t:
        await m.answer("⚠️ Не понял время. Формат ЧЧ:ММ, например 13:00")
        return
    db.set_setting("report_time", t)
    await state.clear()
    text, markup = _rep_screen()
    await m.answer("✅ Время сохранено.\n\n" + text, reply_markup=markup)


@router.message(RepTime.value)
async def rep_time_bad(m: Message):
    await m.answer("⚠️ Нужно время текстом, например 13:00.")


@router.callback_query(F.data == "repnow")
async def rep_now(cb: CallbackQuery):
    if not await need(cb, "owner"):
        return
    sent = await reminders.send_report([cb.from_user.id])
    await cb.answer("📨 Отчёт отправлен вам в личные сообщения." if sent else "Не удалось отправить отчёт.", show_alert=not sent)


# ============================== Группа: задания, команды, баны ==============================
_known_groups: set = set()


def _remember_group(chat) -> None:
    if chat.id not in _known_groups:
        _known_groups.add(chat.id)
        db.save_group(chat.id, chat.title)


def _collect(m: Message, text: str, photo=None) -> None:
    """Сохраняет сообщение места публикации как задание."""
    _remember_group(m.chat)
    if m.from_user is None or (m.from_user.is_bot and not m.sender_chat):
        return
    chat, dest_thread = db.place()
    if chat is None or m.chat.id != chat:
        return
    thread = m.message_thread_id if m.is_topic_message else None
    aid, pos, labeled = tf.classify(text)
    # С меткой — берём из любой темы; без метки — только из выбранной темы
    if not labeled and dest_thread is not None and thread != dest_thread:
        return
    if db.task_by_msg(m.chat.id, m.message_id):
        return
    db.add_task(text, aid, pos, m.chat.id, thread, m.message_id, "group", photo)


@router.message(F.chat.type.in_(GROUPS), F.text, ~F.text.startswith("/"))
async def on_group_text(m: Message):
    """Собирает текстовые сообщения из места публикации как задания."""
    _collect(m, m.text)


@router.message(F.chat.type.in_(GROUPS), F.photo, F.caption)
async def on_group_photo(m: Message):
    """Фото с подписью — тоже задание (подпись = текст, фото сохраняется)."""
    _collect(m, m.caption, m.photo[-1].file_id)


@router.edited_message(F.chat.type.in_(GROUPS), F.text | F.caption)
async def on_group_edit(m: Message):
    t = db.task_by_msg(m.chat.id, m.message_id)
    if t and t["src"] == "group" and t["status"] == "active":
        text = m.text or m.caption or ""
        aid, pos, _ = tf.classify(text)
        db.set_task(t["id"], text=text, aid=aid, pos=pos)


@router.message(Command("done", "cancel", "close", "delete"), F.chat.type.in_(GROUPS))
async def group_close(m: Message, command: CommandObject):
    """/done, /cancel, /close, /delete ответом на сообщение с заданием (или с номером: /done 12)."""
    if not m.from_user or not has_perm(m.from_user.id, "tasks_close"):
        await m.reply("⛔ Нет разрешения: «Закрывать задания».")
        return
    t = None
    arg = (command.args or "").strip()
    if arg.isdigit():
        t = db.get_task(int(arg))
    elif m.reply_to_message:
        rid = m.reply_to_message.message_id
        t = db.task_by_msg(m.chat.id, rid) or db.one("SELECT * FROM tasks WHERE chat_id=? AND note_msg=?", (m.chat.id, rid))
    if not t:
        await m.reply("⚠️ Не нашёл задание. Отправьте команду ответом на сообщение задания или с номером: /done 12.")
        return
    ok, msg = await finish_task(t["id"], HOW[command.command], m.from_user.id)
    await m.reply(msg)
    try:
        await m.delete()
    except TelegramAPIError:
        pass


@router.my_chat_member()
async def on_my_member(ev: ChatMemberUpdated):
    if ev.chat.type not in GROUPS:
        return
    if ev.new_chat_member.status in ("member", "administrator"):
        db.save_group(ev.chat.id, ev.chat.title)
        _known_groups.add(ev.chat.id)
    elif ev.new_chat_member.status in ("left", "kicked"):
        db.del_group(ev.chat.id)
        _known_groups.discard(ev.chat.id)


@router.chat_member()
async def on_chat_member(ev: ChatMemberUpdated):
    """Синхронизация банов: бан в группе → бан в боте; разбан в группе → разбан (если бан был из-за группы)."""
    sync = {c for c in (db.place()[0], getattr(config, "SOURCE_GROUP_ID", None)) if c}
    if ev.chat.id not in sync:
        return
    tg = ev.new_chat_member.user
    if tg.is_bot:
        return
    old, new = ev.old_chat_member.status, ev.new_chat_member.status
    row = db.get_user(tg.id)
    if new == "kicked":
        if row and row["role"] == "owner":
            return
        if row is None:
            db.touch_user(tg.id, tg.username, tg.full_name)
        if not (row and row["banned"]):
            ban_user(tg.id, "group")
            await notify(tg.id, "⛔ Вас забанили в группе — доступ к боту закрыт.")
    elif old == "kicked" and row and row["banned"] and row["ban_src"] == "group":
        unban_user(tg.id)
        await notify(tg.id, "✅ Вас разбанили в группе — доступ к боту восстановлен. Права сброшены.")


# ============================== Запасные обработчики ==============================
@fallback.message(F.chat.type == "private")
async def unknown_message(m: Message):
    await m.answer("🤔 Не понял сообщение. Откройте меню: /menu")


@fallback.callback_query()
async def unknown_callback(cb: CallbackQuery):
    await cb.answer("Эта кнопка устарела. Откройте меню: /menu", show_alert=True)


async def on_error(event: ErrorEvent) -> bool:
    exc = event.exception
    log.error("Необработанная ошибка: %s", exc, exc_info=exc)
    upd = event.update
    uid = None
    if upd.message and upd.message.chat.type == "private":
        uid = upd.message.from_user.id
    elif upd.callback_query:
        uid = upd.callback_query.from_user.id
    if uid:
        await notify(uid, f"⚠️ Не удалось выполнить действие: {type(exc).__name__}: {str(exc)[:200]}\n"
                          f"Попробуйте ещё раз или откройте /menu. Владельцу отправлено уведомление об ошибке.")
    await notify_owner(f"⚠️ Ошибка в боте: {type(exc).__name__}: {str(exc)[:300]}")
    return True


# ============================== Запуск ==============================
async def watch() -> None:
    """Раз в CHECK_INTERVAL секунд: ищет удалённые вручную задания и удаляет выполненные через grace_hours."""
    while True:
        try:
            await check_deleted_once()
            await finalize_due()
        except Exception:
            log.exception("Ошибка фоновой проверки заданий")
        await asyncio.sleep(getattr(config, "CHECK_INTERVAL", 120))


async def start_web(port: int) -> None:
    """Мини-сервер для хостингов, которым нужен открытый порт (переменная PORT)."""
    from aiohttp import web

    async def ok(_request):
        return web.Response(text="tank-bot ok")

    app = web.Application()
    app.router.add_get("/", ok)
    app.router.add_get("/health", ok)
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", port).start()
    log.info("Веб-сервер здоровья запущен на порту %s", port)


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    db.init()
    bot = Bot(token=config.BOT_TOKEN, default=DefaultBotProperties(link_preview_is_disabled=True))
    set_bot(bot)
    dp = Dispatcher(storage=MemoryStorage())
    dp.message.outer_middleware(Guard())
    dp.callback_query.outer_middleware(Guard())
    dp.include_routers(router, materials.router, works.router, reminders.router, scoring.router, fallback)
    dp.errors.register(on_error)
    try:
        me = await bot.get_me()
    except TelegramUnauthorizedError:
        raise SystemExit("❌ Неверный BOT_TOKEN: Telegram его не принял. Проверьте файл .env.")
    log.info("Бот запущен: @%s", me.username)
    await bot.delete_webhook(drop_pending_updates=False)
    await bot.set_my_commands([BotCommand(command="menu", description="Главное меню"),
                               BotCommand(command="cancel", description="Отменить действие"),
                               BotCommand(command="login", description="Ввести другой пароль"),
                               BotCommand(command="help", description="Помощь")])
    background = [asyncio.create_task(watch()), asyncio.create_task(reminders.run_scheduler())]
    port = getattr(config, "PORT", None)
    if port:
        await start_web(port)
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        for task in background:
            task.cancel()
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit) as exc:
        if isinstance(exc, SystemExit) and exc.code:
            print(exc.code)
