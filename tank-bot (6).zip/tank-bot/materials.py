"""Материалы (текст, фото, файл, ссылка) и объявления."""
import asyncio
import re

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

import db
import logic
import perms
from common import (HOME, clip, fmt_user, get_bot, is_staff, kb, need, pos_label, prepare_task, preview,
                    publish_task, resolve_users, send_rich, send_to_all, show)

router = Router()

KIND_ICON = {"text": "📝", "photo": "🖼", "file": "📎", "link": "🔗"}
KIND_NAME = {"text": "Текст", "photo": "Фото", "file": "Файл", "link": "Ссылка"}


class AddMat(StatesGroup):
    title = State()
    content = State()
    users = State()


class AddAnn(StatesGroup):
    text = State()


class AnnEdit(StatesGroup):
    text = State()


class MatEdit(StatesGroup):
    title = State()
    content = State()
    users = State()


class TplNew(StatesGroup):
    title = State()
    text = State()


class TplEdit(StatesGroup):
    title = State()
    text = State()
    photo = State()


def aud_text(m: dict) -> str:
    if m["aud_type"] == "all":
        return "👥 Все"
    if m["aud_type"] == "pos":
        return perms.POS_NAMES.get(m["aud_value"], m["aud_value"])
    names = [fmt_user(db.get_user(int(x))) for x in m["aud_value"].split(",") if x.strip().isdigit()]
    return "👤 " + (", ".join(names) or "—")


# ============================== Для участников ==============================
@router.callback_query(F.data == "mat")
async def mat_list(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    u = db.get_user(cb.from_user.id)
    items = [m for m in db.list_materials() if db.material_visible(m, u)]
    if not items:
        await show(cb, "📚 Материалов пока нет.", kb([HOME]))
        return
    rows = [[(f"{'📌' if m['pinned'] else KIND_ICON[m['kind']]} {preview(m['title'], 45)}", f"matv:{m['id']}")]
            for m in items[:40]]
    rows.append([HOME])
    await show(cb, "📚 Материалы — выберите:", kb(*rows))


@router.callback_query(F.data.startswith("matv:"))
async def mat_view(cb: CallbackQuery):
    mat = db.get_material(int(cb.data.split(":")[1]))
    u = db.get_user(cb.from_user.id)
    if not mat:
        await cb.answer("Материал не найден — возможно, его удалили.", show_alert=True)
        return
    if not (db.material_visible(mat, u) or is_staff(cb.from_user.id)):
        await cb.answer("⛔ Этот материал вам недоступен.", show_alert=True)
        return
    back = kb([("🔙 К материалам", "mat"), HOME])
    kind = mat["kind"]
    if kind == "text":
        await show(cb, f"📝 {mat['title']}\n\n{mat['text']}", back)
    elif kind == "link":
        rows = [[("🌐 Открыть ссылку", mat["url"])]] if mat["url"].startswith(("http://", "https://")) else []
        rows.append([("🔙 К материалам", "mat"), HOME])
        await show(cb, f"🔗 {mat['title']}\n\n{mat['url']}", kb(*rows))
    else:
        caption = clip(f"{KIND_ICON[kind]} {mat['title']}" + (f"\n\n{mat['text']}" if mat["text"] else ""), 1000)
        bot = get_bot()
        if kind == "photo":
            await bot.send_photo(cb.from_user.id, mat["file_id"], caption=caption, reply_markup=back)
        else:
            await bot.send_document(cb.from_user.id, mat["file_id"], caption=caption, reply_markup=back)


@router.callback_query(F.data == "ann")
async def ann_list(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    rows = db.list_announcements(10)
    if not rows:
        await show(cb, "📢 Объявлений пока нет.", kb([HOME]))
        return
    text = "📢 Объявления\n\n" + "\n\n".join(
        f"🗓 {logic.fmt_ts(r['created_at'])}{' · 🖼 есть фото' if r['photo'] else ''}\n{r['text']}" for r in rows)
    buttons = [[(f"🖼 Фото: {preview(r['text'], 30)}", f"annp:{r['id']}")] for r in rows if r["photo"]]
    await show(cb, text, kb(*buttons, [HOME]))


@router.callback_query(F.data.startswith("annp:"))
async def ann_photo(cb: CallbackQuery):
    a = db.get_announcement(int(cb.data.split(":")[1]))
    if not a or not a["photo"]:
        await cb.answer("Фото не найдено.", show_alert=True)
        return
    await send_rich(cb.from_user.id, f"📢 {a['text']}", photo=a["photo"], markup=kb([("🔙 К объявлениям", "ann")]))


# ============================== Управление материалами ==============================
@router.callback_query(F.data == "mman")
async def mman(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "materials_edit"):
        return
    await state.clear()
    rows = [[("➕ Добавить материал", "madd")]]
    for m in db.list_materials()[:40]:
        rows.append([(f"{'📌' if m['pinned'] else KIND_ICON[m['kind']]} {preview(m['title'], 40)}", f"mmv:{m['id']}")])
    rows.append([("🔙 Назад", "sec:content")])
    await show(cb, "📚 Управление материалами", kb(*rows))


async def _mat_card(cb: CallbackQuery, mid: int):
    mat = db.get_material(mid)
    if not mat:
        await cb.answer("Материал не найден.", show_alert=True)
        return
    text = (f"{KIND_ICON[mat['kind']]} {mat['title']}\n"
            f"Тип: {KIND_NAME[mat['kind']]}\nАудитория: {aud_text(mat)}\n"
            f"Закреплён в меню: {'да' if mat['pinned'] else 'нет'}")
    await show(cb, text, kb(
        [("👁 Открыть", f"matv:{mat['id']}")],
        [("✏️ Название", f"met:{mat['id']}"), ("✏️ Содержимое", f"mec:{mat['id']}")],
        [("👥 Аудитория", f"mea:{mat['id']}"),
         ("📌 Открепить" if mat["pinned"] else "📌 Закрепить", f"mpin:{mat['id']}")],
        [("🗑 Удалить", f"mdel:{mat['id']}")],
        [("🔙 К списку", "mman")]))


@router.callback_query(F.data.startswith("mmv:"))
async def mmv(cb: CallbackQuery):
    if not await need(cb, "materials_edit"):
        return
    await _mat_card(cb, int(cb.data.split(":")[1]))


@router.callback_query(F.data.startswith("mpin:"))
async def mpin(cb: CallbackQuery):
    if not await need(cb, "materials_edit"):
        return
    mat = db.get_material(int(cb.data.split(":")[1]))
    if not mat:
        await cb.answer("Материал не найден.", show_alert=True)
        return
    db.update("materials", mat["id"], pinned=0 if mat["pinned"] else 1)
    await _mat_card(cb, mat["id"])


@router.callback_query(F.data.startswith("mdel:"))
async def mdel(cb: CallbackQuery):
    if not await need(cb, "materials_edit"):
        return
    mid = int(cb.data.split(":")[1])
    await show(cb, "🗑 Удалить материал без возможности восстановления?",
               kb([("✅ Да, удалить", f"mdely:{mid}"), ("↩️ Отмена", f"mmv:{mid}")]))


@router.callback_query(F.data.startswith("mdely:"))
async def mdely(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "materials_edit"):
        return
    db.del_material(int(cb.data.split(":")[1]))
    await cb.answer("Материал удалён.")
    await mman(cb, state)


# ------------------------------ Добавление материала ------------------------------
@router.callback_query(F.data == "madd")
async def madd(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "materials_edit"):
        return
    await state.clear()
    await show(cb, "Что за материал добавляем?", kb(
        [("📝 Текст", "mk:text"), ("🖼 Фото", "mk:photo")],
        [("📎 Файл", "mk:file"), ("🔗 Ссылка", "mk:link")],
        [("🔙 Назад", "mman")]))


@router.callback_query(F.data.startswith("mk:"))
async def mk(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "materials_edit"):
        return
    kind = cb.data.split(":")[1]
    await state.set_data({"kind": kind})
    await state.set_state(AddMat.title)
    await show(cb, "✏️ Введите название материала (оно будет на кнопке):", kb([("↩️ Отмена", "mman")]))


@router.message(AddMat.title, F.text)
async def add_title(m: Message, state: FSMContext):
    if not await need(m, "materials_edit"):
        await state.clear()
        return
    await state.update_data(title=m.text.strip()[:100])
    kind = (await state.get_data())["kind"]
    prompt = {"text": "Отправьте текст материала:", "photo": "Отправьте фото (можно с подписью):",
              "file": "Отправьте файл как документ:", "link": "Отправьте ссылку (https://...):"}[kind]
    await state.set_state(AddMat.content)
    await m.answer(prompt, reply_markup=kb([("↩️ Отмена", "mman")]))


@router.message(AddMat.title)
async def add_title_bad(m: Message):
    await m.answer("⚠️ Название должно быть текстом. Введите название материала:")


def _aud_kb():
    return kb([("👥 Всем", "ma:all")], [("💼 Должности", "ma:pos")],
              [("👤 Отдельным участникам", "ma:users")], [("↩️ Отмена", "mman")])


def _parse_content(kind: str, m: Message):
    """Содержимое материала из сообщения: (поля для БД, ошибка). Фото и файлы сохраняются с подписью."""
    if kind == "text":
        if not m.text:
            return None, "Нужен именно текст. Отправьте текст материала:"
        return {"text": m.text}, None
    if kind == "link":
        url = (m.text or "").strip()
        if not re.match(r"https?://\S+$", url):
            return None, "Это не ссылка. Она должна начинаться с http:// или https://"
        return {"url": url}, None
    if kind == "photo":
        if not m.photo:
            return None, "Нужно фото (не файлом). Отправьте изображение:"
        return {"file_id": m.photo[-1].file_id, "text": m.caption}, None
    if not m.document:
        return None, "Нужен файл как документ. Отправьте файл:"
    return {"file_id": m.document.file_id, "text": m.caption}, None


@router.message(AddMat.content)
async def add_content(m: Message, state: FSMContext):
    if not await need(m, "materials_edit"):
        await state.clear()
        return
    fields, err = _parse_content((await state.get_data())["kind"], m)
    if err:
        await m.answer("⚠️ " + err)
        return
    await state.update_data(**fields)
    await m.answer("👥 Кому показывать материал?", reply_markup=_aud_kb())


async def _ask_pin(target, state: FSMContext):
    await state.set_state(None)
    await show(target, "📌 Закрепить материал в главном меню?",
               kb([("📌 Да, закрепить", "mpn:1"), ("Нет", "mpn:0")]))


@router.callback_query(F.data.startswith("ma:"))
async def ma(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "materials_edit"):
        return
    d = await state.get_data()
    if not d.get("kind"):
        await cb.answer("Сессия добавления устарела. Начните заново.", show_alert=True)
        return
    choice = cb.data.split(":")[1]
    if choice == "all":
        await state.update_data(aud_type="all", aud_value="")
        await _ask_pin(cb, state)
    elif choice == "pos":
        rows = [[(perms.POS_NAMES[p], f"map:{p}")] for p in perms.POS_ORDER]
        rows.append([("↩️ Отмена", "mman")])
        await show(cb, "💼 Для какой должности?", kb(*rows))
    else:
        await state.set_state(AddMat.users)
        await show(cb, "👤 Введите ID или @username участников через запятую:", kb([("↩️ Отмена", "mman")]))


@router.callback_query(F.data.startswith("map:"))
async def map_(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "materials_edit"):
        return
    if not (await state.get_data()).get("kind"):
        await cb.answer("Сессия добавления устарела. Начните заново.", show_alert=True)
        return
    await state.update_data(aud_type="pos", aud_value=cb.data.split(":")[1])
    await _ask_pin(cb, state)


@router.message(AddMat.users, F.text)
async def add_users(m: Message, state: FSMContext):
    if not await need(m, "materials_edit"):
        await state.clear()
        return
    found, missing = resolve_users(m.text)
    if missing or not found:
        await m.answer("⚠️ Не найдены участники: " + (", ".join(missing) or "список пуст") +
                       "\nУчастник должен хотя бы раз войти в бота. Введите ещё раз:")
        return
    await state.update_data(aud_type="users", aud_value=",".join(str(u["id"]) for u in found))
    await _ask_pin(m, state)


@router.callback_query(F.data.startswith("mpn:"))
async def mpn(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "materials_edit"):
        return
    d = await state.get_data()
    if not d.get("kind") or not d.get("aud_type"):
        await cb.answer("Сессия добавления устарела. Начните заново.", show_alert=True)
        return
    mid = db.add_material(kind=d["kind"], title=d["title"], text=d.get("text"), file_id=d.get("file_id"),
                          url=d.get("url"), aud_type=d["aud_type"], aud_value=d["aud_value"],
                          pinned=int(cb.data.split(":")[1]), created_by=cb.from_user.id)
    await state.clear()
    ids = [i for i in db.audience(d["aud_type"], d["aud_value"]) if i != cb.from_user.id]
    sent = await send_to_all(ids, f"📚 Новый материал: {d['title']}", kb([("📚 Открыть", f"matv:{mid}")]))
    await show(cb, f"✅ Материал «{d['title']}» добавлен. Уведомлений отправлено: {sent}.",
               kb([("📚 К материалам", "mman")]))


# ============================== Объявления (админ) ==============================
@router.callback_query(F.data == "aman")
async def aman(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "announce_add"):
        return
    await state.clear()
    rows = [[("➕ Новое объявление", "aadd")]]
    for a in db.list_announcements(15):
        rows.append([(f"{'🖼 ' if a['photo'] else ''}{preview(a['text'], 42)}", f"anv:{a['id']}")])
    rows.append([("🔙 Назад", "sec:content")])
    await show(cb, "📢 Объявления\nНажмите на объявление, чтобы изменить или удалить его.", kb(*rows))


@router.callback_query(F.data.startswith("anv:"))
async def anv(cb: CallbackQuery):
    if not await need(cb, "announce_add"):
        return
    a = db.get_announcement(int(cb.data.split(":")[1]))
    if not a:
        await cb.answer("Объявление не найдено.", show_alert=True)
        return
    markup = kb([("✏️ Изменить текст", f"ane:{a['id']}"), ("🗑 Удалить", f"adel:{a['id']}")],
                [("🔙 К объявлениям", "aman")])
    text = f"📢 Объявление от {logic.fmt_ts(a['created_at'])}\n\n{a['text']}"
    if a["photo"]:
        await send_rich(cb.from_user.id, text, photo=a["photo"], markup=markup)
    else:
        await show(cb, text, markup)


@router.callback_query(F.data.startswith("adel:"))
async def adel(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "announce_add"):
        return
    db.del_announcement(int(cb.data.split(":")[1]))
    await cb.answer("Объявление удалено.")
    await aman(cb, state)


@router.callback_query(F.data.startswith("ane:"))
async def ane(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "announce_add"):
        return
    a = db.get_announcement(int(cb.data.split(":")[1]))
    if not a:
        await cb.answer("Объявление не найдено.", show_alert=True)
        return
    await state.set_data({"aid": a["id"]})
    await state.set_state(AnnEdit.text)
    await show(cb, f"✏️ Сейчас:\n{a['text']}\n\nОтправьте новый текст объявления "
                   f"(у людей, уже получивших объявление, оно не изменится):", kb([("↩️ Отмена", f"anv:{a['id']}")]))


@router.message(AnnEdit.text, F.text)
async def ane_text(m: Message, state: FSMContext):
    if not await need(m, "announce_add"):
        await state.clear()
        return
    aid = (await state.get_data()).get("aid")
    if not aid or not db.get_announcement(aid):
        await state.clear()
        await m.answer("⚠️ Объявление уже удалено.")
        return
    db.set_announcement(aid, text=m.text.strip())
    await state.clear()
    await m.answer("✅ Текст объявления изменён.", reply_markup=kb([("📢 К объявлению", f"anv:{aid}")]))


@router.message(AnnEdit.text)
async def ane_bad(m: Message):
    await m.answer("⚠️ Нужен текст. Отправьте новый текст объявления:")


@router.callback_query(F.data == "aadd")
async def aadd(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "announce_add"):
        return
    await state.set_state(AddAnn.text)
    await show(cb, "✏️ Отправьте текст объявления.\n🖼 Хотите фото — отправьте фото с подписью: подпись станет текстом "
                   "объявления (до 1000 символов).", kb([("↩️ Отмена", "aman")]))


@router.message(AddAnn.text, F.text | F.photo)
async def aadd_text(m: Message, state: FSMContext):
    if not await need(m, "announce_add"):
        await state.clear()
        return
    text = (m.text or m.caption or "").strip()
    photo = m.photo[-1].file_id if m.photo else None
    if not text:
        await m.answer("⚠️ У фото нет подписи. Отправьте фото ещё раз и напишите текст объявления в подписи.")
        return
    if photo and len(text) > 1000:
        await m.answer(f"⚠️ С фото текст не может быть длиннее 1000 символов (сейчас {len(text)}). Сократите:")
        return
    db.add_announcement(text, m.from_user.id, photo)
    await state.clear()
    ids = [u["id"] for u in db.authorized_users() if u["id"] != m.from_user.id]
    sent = 0
    for uid in ids:
        if await send_rich(uid, f"📢 Новое объявление\n\n{text}", photo=photo):
            sent += 1
        await asyncio.sleep(0.05)
    await m.answer(f"✅ Объявление опубликовано. Получили: {sent} из {len(ids)}.",
                   reply_markup=kb([("📢 К объявлениям", "aman")]))


@router.message(AddAnn.text)
async def aadd_bad(m: Message):
    await m.answer("⚠️ Объявление — это текст или фото с подписью. Отправьте текст:")


# ============================== Изменение материала ==============================
KIND_PROMPT = {"text": "Отправьте новый текст материала:", "photo": "Отправьте новое фото (можно с подписью):",
               "file": "Отправьте новый файл как документ:", "link": "Отправьте новую ссылку (https://...):"}


@router.callback_query(F.data.startswith("met:"))
async def met(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "materials_edit"):
        return
    mat = db.get_material(int(cb.data.split(":")[1]))
    if not mat:
        await cb.answer("Материал не найден.", show_alert=True)
        return
    await state.set_data({"mid": mat["id"]})
    await state.set_state(MatEdit.title)
    await show(cb, f"✏️ Сейчас: «{mat['title']}»\n\nВведите новое название:", kb([("↩️ Отмена", f"mmv:{mat['id']}")]))


@router.message(MatEdit.title, F.text)
async def met_text(m: Message, state: FSMContext):
    if not await need(m, "materials_edit"):
        await state.clear()
        return
    mid = (await state.get_data()).get("mid")
    if not mid or not db.get_material(mid):
        await state.clear()
        await m.answer("⚠️ Материал уже удалён.")
        return
    db.update("materials", mid, title=m.text.strip()[:100])
    await state.clear()
    await m.answer("✅ Название изменено.", reply_markup=kb([("📚 К материалу", f"mmv:{mid}")]))


@router.callback_query(F.data.startswith("mec:"))
async def mec(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "materials_edit"):
        return
    mat = db.get_material(int(cb.data.split(":")[1]))
    if not mat:
        await cb.answer("Материал не найден.", show_alert=True)
        return
    await state.set_data({"mid": mat["id"]})
    await state.set_state(MatEdit.content)
    await show(cb, "✏️ " + KIND_PROMPT[mat["kind"]], kb([("↩️ Отмена", f"mmv:{mat['id']}")]))


@router.message(MatEdit.content)
async def mec_content(m: Message, state: FSMContext):
    if not await need(m, "materials_edit"):
        await state.clear()
        return
    mat = db.get_material((await state.get_data()).get("mid", 0))
    if not mat:
        await state.clear()
        await m.answer("⚠️ Материал уже удалён.")
        return
    fields, err = _parse_content(mat["kind"], m)
    if err:
        await m.answer("⚠️ " + err)
        return
    if mat["kind"] in ("photo", "file") and not fields.get("text"):
        fields["text"] = mat["text"]
    db.update("materials", mat["id"], **fields)
    await state.clear()
    await m.answer("✅ Содержимое обновлено.", reply_markup=kb([("📚 К материалу", f"mmv:{mat['id']}")]))


@router.callback_query(F.data.startswith("mea:"))
async def mea(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "materials_edit"):
        return
    await state.clear()
    mat = db.get_material(int(cb.data.split(":")[1]))
    if not mat:
        await cb.answer("Материал не найден.", show_alert=True)
        return
    mid = mat["id"]
    await show(cb, f"👥 Аудитория сейчас: {aud_text(mat)}\n\nКому показывать материал?", kb(
        [("👥 Всем", f"meaa:{mid}")], [("💼 Должности", f"meap:{mid}")],
        [("👤 Отдельным участникам", f"meau:{mid}")], [("🔙 Назад", f"mmv:{mid}")]))


@router.callback_query(F.data.startswith("meaa:"))
async def meaa(cb: CallbackQuery):
    if not await need(cb, "materials_edit"):
        return
    mid = int(cb.data.split(":")[1])
    db.update("materials", mid, aud_type="all", aud_value="")
    await _mat_card(cb, mid)


@router.callback_query(F.data.startswith("meap:"))
async def meap(cb: CallbackQuery):
    if not await need(cb, "materials_edit"):
        return
    mid = int(cb.data.split(":")[1])
    rows = [[(perms.POS_NAMES[p], f"meapp:{mid}:{p}")] for p in perms.POS_ORDER]
    rows.append([("🔙 Назад", f"mea:{mid}")])
    await show(cb, "💼 Для какой должности?", kb(*rows))


@router.callback_query(F.data.startswith("meapp:"))
async def meapp(cb: CallbackQuery):
    if not await need(cb, "materials_edit"):
        return
    _, mid, pos = cb.data.split(":")
    if pos not in perms.POS_NAMES:
        await cb.answer("Неизвестная должность.", show_alert=True)
        return
    db.update("materials", int(mid), aud_type="pos", aud_value=pos)
    await _mat_card(cb, int(mid))


@router.callback_query(F.data.startswith("meau:"))
async def meau(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "materials_edit"):
        return
    mid = int(cb.data.split(":")[1])
    await state.set_data({"mid": mid})
    await state.set_state(MatEdit.users)
    await show(cb, "👤 Введите ID или @username участников через запятую:", kb([("↩️ Отмена", f"mea:{mid}")]))


@router.message(MatEdit.users, F.text)
async def meau_text(m: Message, state: FSMContext):
    if not await need(m, "materials_edit"):
        await state.clear()
        return
    mid = (await state.get_data()).get("mid")
    found, missing = resolve_users(m.text)
    if missing or not found:
        await m.answer("⚠️ Не найдены: " + (", ".join(missing) or "список пуст") +
                       ". Участник должен хотя бы раз войти в бота. Введите ещё раз:")
        return
    db.update("materials", mid, aud_type="users", aud_value=",".join(str(u["id"]) for u in found))
    await state.clear()
    await m.answer("✅ Аудитория изменена.", reply_markup=kb([("📚 К материалу", f"mmv:{mid}")]))


@router.message(MatEdit.title)
@router.message(MatEdit.users)
async def mat_edit_bad(m: Message):
    await m.answer("⚠️ Нужен текст. Попробуйте ещё раз или отправьте /cancel.")


# ============================== Шаблоны заданий ==============================
def _pos_short(pos) -> str:
    return perms.POS_NAMES.get(pos, "👥 все")


@router.callback_query(F.data == "tpl")
async def tpl_list(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_add"):
        return
    await state.clear()
    rows = [[("➕ Новый шаблон", "tpladd")]]
    for t in db.list_templates()[:40]:
        rows.append([(f"{'🖼 ' if t['photo'] else ''}{preview(t['title'], 28)} · {_pos_short(t['pos'])}", f"tplv:{t['id']}")])
    rows.append([("🔙 Назад", "sec:tasks")])
    await show(cb, "📑 Шаблоны заданий\n\nЗаготовки: задание из шаблона публикуется в группу одной кнопкой, "
                   "без ввода текста.", kb(*rows))


@router.callback_query(F.data == "tplpick")
async def tpl_pick(cb: CallbackQuery):
    if not await need(cb, "tasks_add"):
        return
    items = db.list_templates()
    rows = [[(f"{'🖼 ' if t['photo'] else ''}{preview(t['title'], 28)} · {_pos_short(t['pos'])}", f"tplp:{t['id']}")]
            for t in items[:40]]
    rows.append([("🔙 Назад", "tadd")])
    await show(cb, "📑 Выберите шаблон:" if items else "📑 Шаблонов пока нет. Создайте первый в разделе «Задания».",
               kb(*rows))


async def _tpl_show(cb: CallbackQuery, text: str, tpl: dict, markup) -> None:
    if tpl["photo"]:
        await send_rich(cb.from_user.id, text, photo=tpl["photo"], markup=markup)
    else:
        await show(cb, text, markup)


@router.callback_query(F.data.startswith("tplp:"))
async def tplp(cb: CallbackQuery):
    if not await need(cb, "tasks_add"):
        return
    t = db.get_template(int(cb.data.split(":")[1]))
    if not t:
        await cb.answer("Шаблон не найден.", show_alert=True)
        return
    await _tpl_show(cb, f"🚀 Опубликовать задание из шаблона «{t['title']}»?\nДля: {_pos_short(t['pos'])}\n\n{t['text']}", t,
                    kb([("🚀 Опубликовать в группу", f"tplgo:{t['id']}")], [("🔙 Назад", "tplpick")]))


@router.callback_query(F.data.startswith("tplgo:"))
async def tplgo(cb: CallbackQuery):
    if not await need(cb, "tasks_add"):
        return
    t = db.get_template(int(cb.data.split(":")[1]))
    if not t:
        await cb.answer("Шаблон не найден.", show_alert=True)
        return
    aid, text = prepare_task(t["text"], t["pos"])
    tid, err = await publish_task(text, aid, t["pos"], t["photo"])
    if err:
        await show(cb, "❌ " + err, kb([("🔙 К шаблонам", "tplpick")]))
        return
    await show(cb, f"✅ Задание #{tid} опубликовано в группе ({_pos_short(t['pos'])}).",
               kb([("➕ Ещё задание", "tadd"), ("📌 Активные", "tact")], [("🔙 К разделу", "sec:tasks")]))


async def _tpl_card(cb: CallbackQuery, tid: int) -> None:
    t = db.get_template(tid)
    if not t:
        await cb.answer("Шаблон не найден.", show_alert=True)
        return
    rows = [[("🚀 Опубликовать задание", f"tplp:{tid}")],
            [("✏️ Название", f"tple:{tid}:title"), ("✏️ Текст", f"tple:{tid}:text")],
            [("💼 Должность", f"tplpos:{tid}"), ("🖼 Фото", f"tplph:{tid}")]]
    if t["photo"]:
        rows.append([("🗑 Убрать фото", f"tplphx:{tid}")])
    rows.append([("🗑 Удалить шаблон", f"tpld:{tid}")])
    rows.append([("🔙 К шаблонам", "tpl")])
    await _tpl_show(cb, f"📑 Шаблон «{t['title']}»\nДля: {_pos_short(t['pos'])}{' · 🖼 с фото' if t['photo'] else ''}\n\n{t['text']}",
                    t, kb(*rows))


@router.callback_query(F.data.startswith("tplv:"))
async def tplv(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_add"):
        return
    await state.clear()
    await _tpl_card(cb, int(cb.data.split(":")[1]))


@router.callback_query(F.data.startswith("tple:"))
async def tple(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_add"):
        return
    _, tid, field = cb.data.split(":")
    t = db.get_template(int(tid))
    if not t or field not in ("title", "text"):
        await cb.answer("Шаблон не найден.", show_alert=True)
        return
    await state.set_data({"tid": t["id"]})
    await state.set_state(TplEdit.title if field == "title" else TplEdit.text)
    now_val = t["title"] if field == "title" else t["text"]
    await show(cb, f"✏️ Сейчас:\n{now_val}\n\nОтправьте новое значение:", kb([("↩️ Отмена", f"tplv:{t['id']}")]))


@router.message(TplEdit.title, F.text)
async def tpl_edit_title(m: Message, state: FSMContext):
    if not await need(m, "tasks_add"):
        await state.clear()
        return
    tid = (await state.get_data()).get("tid")
    if not tid or not db.get_template(tid):
        await state.clear()
        await m.answer("⚠️ Шаблон уже удалён.")
        return
    db.set_template(tid, title=m.text.strip()[:100])
    await state.clear()
    await m.answer("✅ Название изменено.", reply_markup=kb([("📑 К шаблону", f"tplv:{tid}")]))


@router.message(TplEdit.text, F.text | F.photo)
async def tpl_edit_text(m: Message, state: FSMContext):
    if not await need(m, "tasks_add"):
        await state.clear()
        return
    tid = (await state.get_data()).get("tid")
    t = db.get_template(tid) if tid else None
    if not t:
        await state.clear()
        await m.answer("⚠️ Шаблон уже удалён.")
        return
    text = (m.text or m.caption or "").strip()
    photo = m.photo[-1].file_id if m.photo else t["photo"]
    if not text:
        await m.answer("⚠️ Нужен текст (у фото — подпись). Отправьте ещё раз:")
        return
    if photo and len(text) > 1000:
        await m.answer(f"⚠️ С фото текст не может быть длиннее 1000 символов (сейчас {len(text)}). Сократите:")
        return
    db.set_template(tid, text=text, photo=photo)
    await state.clear()
    await m.answer("✅ Текст шаблона изменён.", reply_markup=kb([("📑 К шаблону", f"tplv:{tid}")]))


@router.callback_query(F.data.startswith("tplph:"))
async def tplph(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_add"):
        return
    t = db.get_template(int(cb.data.split(":")[1]))
    if not t:
        await cb.answer("Шаблон не найден.", show_alert=True)
        return
    if len(t["text"]) > 1000:
        await cb.answer("Текст шаблона длиннее 1000 символов — с фото он не поместится. Сначала сократите текст.",
                        show_alert=True)
        return
    await state.set_data({"tid": t["id"]})
    await state.set_state(TplEdit.photo)
    await show(cb, "🖼 Отправьте фото для шаблона. Оно уйдёт в группу с подписью — текстом задания.",
               kb([("↩️ Отмена", f"tplv:{t['id']}")]))


@router.message(TplEdit.photo, F.photo)
async def tpl_edit_photo(m: Message, state: FSMContext):
    if not await need(m, "tasks_add"):
        await state.clear()
        return
    tid = (await state.get_data()).get("tid")
    if not tid or not db.get_template(tid):
        await state.clear()
        await m.answer("⚠️ Шаблон уже удалён.")
        return
    db.set_template(tid, photo=m.photo[-1].file_id)
    await state.clear()
    await m.answer("✅ Фото добавлено к шаблону.", reply_markup=kb([("📑 К шаблону", f"tplv:{tid}")]))


@router.message(TplEdit.title)
@router.message(TplEdit.text)
@router.message(TplEdit.photo)
async def tpl_edit_bad(m: Message):
    await m.answer("⚠️ Этот тип сообщения не подходит. Отправьте нужное значение или /cancel.")


@router.callback_query(F.data.startswith("tplphx:"))
async def tplphx(cb: CallbackQuery):
    if not await need(cb, "tasks_add"):
        return
    tid = int(cb.data.split(":")[1])
    db.set_template(tid, photo=None)
    await cb.answer("Фото убрано.")
    await _tpl_card(cb, tid)


@router.callback_query(F.data.startswith("tplpos:"))
async def tplpos(cb: CallbackQuery):
    if not await need(cb, "tasks_add"):
        return
    tid = int(cb.data.split(":")[1])
    rows = [[(perms.POS_NAMES[p], f"tplps:{tid}:{perms.CODE_BY_POS[p]}")] for p in perms.POS_ORDER]
    rows.append([("👥 Для всех", f"tplps:{tid}:0")])
    rows.append([("🔙 Назад", f"tplv:{tid}")])
    await show(cb, "💼 Для какой должности шаблон?", kb(*rows))


@router.callback_query(F.data.startswith("tplps:"))
async def tplps(cb: CallbackQuery):
    if not await need(cb, "tasks_add"):
        return
    _, tid, code = cb.data.split(":")
    if code not in perms.POS_BY_CODE or not db.get_template(int(tid)):
        await cb.answer("Шаблон не найден.", show_alert=True)
        return
    db.set_template(int(tid), pos=perms.POS_BY_CODE[code])
    await _tpl_card(cb, int(tid))


@router.callback_query(F.data.startswith("tpld:"))
async def tpld(cb: CallbackQuery):
    if not await need(cb, "tasks_add"):
        return
    tid = int(cb.data.split(":")[1])
    await show(cb, "🗑 Удалить шаблон? Уже опубликованные задания не изменятся.",
               kb([("✅ Да, удалить", f"tpldy:{tid}")], [("↩️ Нет", f"tplv:{tid}")]))


@router.callback_query(F.data.startswith("tpldy:"))
async def tpldy(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_add"):
        return
    db.del_template(int(cb.data.split(":")[1]))
    await cb.answer("Шаблон удалён.")
    await tpl_list(cb, state)


@router.callback_query(F.data == "tpladd")
async def tpladd(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_add"):
        return
    await state.set_data({})
    await state.set_state(TplNew.title)
    await show(cb, "✏️ Введите название шаблона (для списка), например «Эскиз танка»:", kb([("↩️ Отмена", "tpl")]))


@router.message(TplNew.title, F.text)
async def tpl_new_title(m: Message, state: FSMContext):
    await state.update_data(title=m.text.strip()[:100])
    await state.set_state(TplNew.text)
    await m.answer("✏️ Теперь текст задания (метку aid бот добавит сам).\n🖼 Хотите фото — отправьте фото с подписью: "
                   "подпись станет текстом.", reply_markup=kb([("↩️ Отмена", "tpl")]))


@router.message(TplNew.text, F.text | F.photo)
async def tpl_new_text(m: Message, state: FSMContext):
    if not await need(m, "tasks_add"):
        await state.clear()
        return
    text = (m.text or m.caption or "").strip()
    photo = m.photo[-1].file_id if m.photo else None
    if not text:
        await m.answer("⚠️ У фото нет подписи. Отправьте фото ещё раз и напишите текст задания в подписи.")
        return
    if photo and len(text) > 1000:
        await m.answer(f"⚠️ С фото текст не может быть длиннее 1000 символов (сейчас {len(text)}). Сократите:")
        return
    await state.update_data(text=text, photo=photo)
    rows = [[(perms.POS_NAMES[p], f"tplnp:{perms.CODE_BY_POS[p]}")] for p in perms.POS_ORDER]
    rows.append([("👥 Для всех", "tplnp:0")])
    rows.append([("↩️ Отмена", "tpl")])
    await m.answer("💼 Для какой должности шаблон?", reply_markup=kb(*rows))


@router.message(TplNew.title)
@router.message(TplNew.text)
async def tpl_new_bad(m: Message):
    await m.answer("⚠️ Нужен текст (или фото с подписью). Попробуйте ещё раз или отправьте /cancel.")


@router.callback_query(F.data.startswith("tplnp:"))
async def tpl_new_pos(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "tasks_add"):
        return
    d = await state.get_data()
    code = cb.data.split(":")[1]
    if not d.get("title") or not d.get("text") or code not in perms.POS_BY_CODE:
        await cb.answer("Сессия создания устарела. Начните заново.", show_alert=True)
        return
    tid = db.add_template(d["title"], d["text"], perms.POS_BY_CODE[code], d.get("photo"))
    await state.clear()
    await _tpl_card(cb, tid)
