"""Роли, разрешения, статусы, должности, уровни админов."""

# --- Разрешения админов -----------------------------------------------------
PERMS = {
    "tasks_add": "Добавлять задания",
    "tasks_close": "Закрывать задания",
    "materials_edit": "Управлять материалами",
    "announce_add": "Публиковать объявления",
    "place_set": "Задавать место публикации",
    "stats_view": "Смотреть статистику",
    "users_view": "Смотреть участников",
    "users_status": "Менять статусы участников",
    "users_ban": "Банить и разбанивать",
    "perms_edit": "Менять права и кураторов",
    "reminders_manage": "Управлять напоминаниями",
    "works_review": "Проверять работы",
    "polls_create": "Создавать опросы",
    "points_edit": "Начислять баллы вручную",
    "scoring_edit": "Настраивать баллы и фразы",
    "forms_edit": "Управлять общими формами",
    "ranks_edit": "Настраивать шкалу статусов",
}

# Права, которые получает админ при первом входе
DEFAULT_ADMIN_PERMS = [
    "tasks_add", "tasks_close", "materials_edit", "announce_add",
    "place_set", "stats_view", "users_view", "works_review",
]

# --- Роли и уровни ----------------------------------------------------------
ROLE_NAMES = {"user": "Пользователь", "admin": "Админ", "owner": "Владелец"}
ADMIN_LEVELS = {"junior": "Младший", "middle": "Средний", "senior": "Старший"}
LEVEL_RANK = {"junior": 1, "middle": 2, "senior": 3}
OWNER_RANK = 4          # owner > senior > middle > junior > user


def rank(role, level=None) -> int:
    """Ранг для иерархии: owner(4) > senior(3) > middle(2) > junior(1) > user(0)."""
    if role == "owner":
        return OWNER_RANK
    if role == "admin":
        return LEVEL_RANK.get(level or "junior", 1)
    return 0


# --- Статусы и шкала повышения ---------------------------------------------
STATUSES = {
    "newbie": "🔵 Новичок",
    "member": "🟢 Участник",
    "best": "🟡 Лучший участник",
    "lead": "🟣 Ведущий",
    "owner": "🔴 Владелец",
}
STATUS_ORDER = ["newbie", "member", "best", "lead"]      # owner вне шкалы
# (статус, ключ настройки с порогом, порог по умолчанию)
LADDER = [("member", "ladder_member", 10), ("best", "ladder_best", 30), ("lead", "ladder_lead", 60)]

# --- Должности ---------------------------------------------------------------
POS_NAMES = {
    "artist": "🎨 Художник",
    "writer": "✍️ Сценарист",
    "animator": "🎬 Аниматор",
    "helper": "🧰 Помощник",
}
POS_ORDER = ["artist", "writer", "animator", "helper"]
# Код в метке задания aid<номер>_<код>: 1 художники, 2 сценаристы, 3 помощники, 4 аниматоры, 0 все
POS_BY_CODE = {"1": "artist", "2": "writer", "3": "helper", "4": "animator", "0": None}
CODE_BY_POS = {"artist": 1, "writer": 2, "helper": 3, "animator": 4, None: 0}
POS_PLURAL = {"artist": "художников", "writer": "сценаристов", "helper": "помощников", "animator": "аниматоров"}

# --- Разделы меню админа/владельца: (ключ, название, [(кнопка, callback, нужное право)]) ---------
# Право "owner" — только владелец.
SECTIONS = [
    ("tasks", "📌 Задания", [
        ("➕ Добавить задание", "tadd", "tasks_add"),
        ("📑 Шаблоны заданий", "tpl", "tasks_add"),
        ("📌 Активные задания", "tact", "tasks_close"),
        ("⏱ Время приёма работ", "grace", "tasks_close"),
        ("📍 Место публикации", "place", "place_set"),
    ]),
    ("works", "📥 Работы", [
        ("📥 На проверку", "wlist", "works_review"),
        ("🏆 Лучшая работа и опросы", "wbest", "works_review"),
        ("🧑‍🏫 Кураторы", "cur", "perms_edit"),
        ("📝 Общие формы", "fman", "forms_edit"),
    ]),
    ("people", "👥 Участники", [
        ("👥 Список участников", "usr:0", "users_view"),
        ("⭐ Начислить баллы", "padj", "points_edit"),
        ("🚫 Забаненные", "banl", "users_ban"),
    ]),
    ("content", "📣 Публикации", [
        ("📚 Материалы", "mman", "materials_edit"),
        ("📢 Объявления", "aman", "announce_add"),
        ("⏰ Напоминания", "rem", "reminders_manage"),
    ]),
    ("settings", "⚙️ Настройки", [
        ("⚙️ Баллы за работы", "scs", "scoring_edit"),
        ("📈 Шкала статусов", "rks", "ranks_edit"),
        ("💬 Фразы поддержки", "phr", "scoring_edit"),
        ("📊 Статистика", "stat", "stats_view"),
    ]),
    ("owner", "👑 Владелец", [
        ("👑 Админы и уровни", "adms", "owner"),
        ("🔐 Пароли доступа", "pws", "owner"),
        ("📆 Недельный отчёт", "rep", "owner"),
    ]),
]
