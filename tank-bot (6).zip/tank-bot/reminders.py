"""Напоминания: разово / каждую неделю / по датам из календаря. Время московское (UTC+3)."""
import asyncio
import calendar
import json
import logging
from datetime import timedelta

from aiogram import F, Router
from aiogram.exceptions import TelegramAPIError
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

import config
import db
import logic
from common import (err_text, get_bot, kb, need, notify_owner, parse_topic, preview,
                    resolve_users, safe_send, send_rich, show)

log = logging.getLogger("tank-bot")
router = Router()


class RemEdit(StatesGroup):
    text = State()


class Rem(StatesGroup):
    text = State()
    once = State()
    days = State()          # выбор дней недели кнопками
    calendar = State()      # выбор дат в календаре
    time = State()          # одно общее время
    times = State()         # своё время для каждого
    topic = State()
    dm = State()


# ============================== Планировщик ==============================
async def deliver(r: dict) -> bool:
    """Отправить напоминание (с фото — фото с подписью). Об ошибках уведомляет владельца."""
    text = f"⏰ {r['text']}"
    photo = r.get("photo")
    dm = [int(x) for x in r["dm_users"].split(",") if x.strip().lstrip("-").isdigit()]
    if dm:
        failed = []
        for uid in dm:
            if not await send_rich(uid, text, photo=photo):
                failed.append(str(uid))
            await asyncio.sleep(0.05)
        if failed:
            await notify_owner(f"⚠️ Напоминание #{r['id']} не доставлено в личку: {', '.join(failed)}. "
                               f"Возможно, эти люди не запускали бота или заблокировали его.")
        return len(failed) < len(dm)
    chat, thread = (r["chat_id"], r["thread"]) if r["chat_id"] else db.place()
    if not chat:
        await notify_owner(f"⚠️ Напоминание #{r['id']} не отправлено: место публикации не задано "
                           f"(раздел «Задания» → «Место публикации»).")
        return False
    try:
        if photo:
            await get_bot().send_photo(chat, photo, caption=text[:1024], message_thread_id=thread)
        else:
            await get_bot().send_message(chat, text, message_thread_id=thread)
        return True
    except TelegramAPIError as e:
        await notify_owner(f"⚠️ Напоминание #{r['id']} не отправлено в группу: {err_text(e)}. "
                           f"Проверьте, что бот в группе и может писать в нужную тему.")
        return False


# --- Недельный отчёт владельцу ---
def build_report(now=None) -> str:
    now = now or logic.now_msk()
    since = int(now.timestamp()) - 7 * 86400
    st = db.week_stats(since)
    start = (now - timedelta(days=7)).strftime("%d.%m")
    avg = f"{st['avg_grade']:.1f} / 10" if st["avg_grade"] is not None else "— (оценок не было)"
    return (f"📆 Недельный отчёт: {start} — {now:%d.%m}\n\n"
            f"📌 Новых заданий: {st['new_tasks']}\n"
            f"📤 Сдано работ: {st['works']}\n"
            f"✅ Проверено работ: {st['reviewed']}\n"
            f"⭐ Средняя оценка за неделю: {avg}\n\n"
            f"Сейчас: активных заданий — {st['tasks_active']}, ждут проверки — {st['pending']}.")


async def send_report(to=None) -> int:
    """Отправить отчёт владельцу(ам) или указанным людям. Возвращает число доставленных."""
    text = build_report()
    sent = 0
    for uid in (to or db.owner_ids()):
        if await safe_send(uid, text):
            sent += 1
    return sent


async def report_tick(now) -> None:
    """Раз в неделю (по умолчанию пятница 13:00 МСК) присылает владельцу сводку."""
    if db.get_setting("report_on", "1") != "1":
        return
    try:
        day = int(db.get_setting("report_day", "4"))
        h, mi = map(int, (db.get_setting("report_time", "13:00") or "13:00").split(":"))
    except ValueError:
        return
    if now.weekday() != day:
        return
    at = now.replace(hour=h, minute=mi, second=0, microsecond=0)
    if not (at <= now < at + timedelta(seconds=logic.LATE_WINDOW)):
        return
    key = at.strftime("%Y-%m-%d")
    if db.get_setting("report_last") == key:
        return
    db.set_setting("report_last", key)          # сначала отметка — чтобы не слать дважды
    await send_report()


async def tick() -> None:
    now = logic.now_msk()
    for r in db.active_reminders():
        fired = db.jl(r["fired"])
        keys = logic.due_keys(r["kind"], db.jl(r["weekly"]), db.jl(r["dates"]), fired, now)
        if not keys:
            continue
        fired = (fired + keys)[-60:]
        db.set_reminder(r["id"], fired=json.dumps(fired))        # сначала отметка — чтобы не слать дважды
        await deliver(r)
        if r["kind"] != "weekly" and logic.entries_done(db.jl(r["dates"]), fired, now):
            db.set_reminder(r["id"], active=0)
    await report_tick(now)


async def run_scheduler() -> None:
    """Фоновая задача: раз в REMINDER_TICK (20) секунд проверяет, не пора ли слать напоминания."""
    while True:
        try:
            await tick()
        except Exception:
            log.exception("Ошибка планировщика напоминаний")
        await asyncio.sleep(getattr(config, "REMINDER_TICK", 20))


# ============================== Экраны ==============================
def dest_text(r: dict) -> str:
    if r["dm_users"]:
        names = []
        for x in r["dm_users"].split(","):
            u = db.get_user(int(x)) if x.strip().lstrip("-").isdigit() else None
            names.append(u["name"] if u and u.get("name") else x)
        return "👤 В личку: " + ", ".join(names)
    if r["chat_id"]:
        return f"🧵 Группа «{db.group_title(r['chat_id'])}», тема {r['thread'] or 'без темы'}"
    return "📍 Место публикации"


def card_text(r: dict) -> str:
    sched = logic.describe_schedule(r["kind"], db.jl(r["weekly"]), db.jl(r["dates"]))
    return (f"⏰ Напоминание #{r['id']} · {'🟢 включено' if r['active'] else '⏸ приостановлено'}"
            f"{' · 🖼 с фото' if r.get('photo') else ''}\n\n"
            f"{r['text']}\n\n🗓 {sched} (МСК)\n{dest_text(r)}")


@router.callback_query(F.data == "rem")
async def rem_list(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "reminders_manage"):
        return
    await state.clear()
    rows = [[("➕ Создать напоминание", "radd")]]
    for r in db.list_reminders()[:40]:
        rows.append([(f"{'🟢' if r['active'] else '⏸'} #{r['id']} {preview(r['text'], 35)}", f"rv:{r['id']}")])
    rows.append([("🔙 Назад", "sec:content")])
    await show(cb, f"⏰ Напоминания (время московское, сейчас {logic.now_msk():%d.%m %H:%M})", kb(*rows))


async def _card(cb: CallbackQuery, rid: int) -> None:
    r = db.get_reminder(rid)
    if not r:
        await cb.answer("Напоминание не найдено — возможно, его удалили.", show_alert=True)
        return
    await show(cb, card_text(r), kb(
        [("⏸ Приостановить" if r["active"] else "▶️ Включить", f"rt:{rid}")],
        [("📨 Отправить сейчас", f"rn:{rid}"), ("🗑 Удалить", f"rd:{rid}")],
        [("✏️ Изменить текст/фото", f"ret:{rid}"), ("🕒 Расписание и адрес", f"res:{rid}")],
        [("🔙 К списку", "rem")]))


@router.callback_query(F.data.startswith("rv:"))
async def rv(cb: CallbackQuery):
    if await need(cb, "reminders_manage"):
        await _card(cb, int(cb.data.split(":")[1]))


@router.callback_query(F.data.startswith("rt:"))
async def rt(cb: CallbackQuery):
    if not await need(cb, "reminders_manage"):
        return
    r = db.get_reminder(int(cb.data.split(":")[1]))
    if not r:
        await cb.answer("Напоминание не найдено.", show_alert=True)
        return
    db.set_reminder(r["id"], active=0 if r["active"] else 1)
    await _card(cb, r["id"])


@router.callback_query(F.data.startswith("rn:"))
async def rn(cb: CallbackQuery):
    if not await need(cb, "reminders_manage"):
        return
    r = db.get_reminder(int(cb.data.split(":")[1]))
    if not r:
        await cb.answer("Напоминание не найдено.", show_alert=True)
        return
    ok = await deliver(r)
    await cb.answer("📨 Отправлено." if ok else "❌ Не удалось отправить — подробности пришли владельцу.",
                    show_alert=not ok)


@router.callback_query(F.data.startswith("rd:"))
async def rd(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "reminders_manage"):
        return
    db.del_reminder(int(cb.data.split(":")[1]))
    await cb.answer("Напоминание удалено.")
    await rem_list(cb, state)


# ============================== Создание ==============================
@router.callback_query(F.data == "radd")
async def radd(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "reminders_manage"):
        return
    await state.set_data({})
    await state.set_state(Rem.text)
    await show(cb, "✏️ Введите текст напоминания.\n🖼 Нужно фото — отправьте фото с подписью: подпись станет "
                   "текстом напоминания (до 1000 символов).", kb([("↩️ Отмена", "rem")]))


def _kind_kb():
    return kb([("1️⃣ Разово (дата и время)", "rk:once")],
              [("🔁 Каждую неделю (дни недели)", "rk:weekly")],
              [("📅 По датам из календаря", "rk:dates")],
              [("↩️ Отмена", "rem")])


def _read_text_photo(m: Message):
    """Текст напоминания и фото из сообщения. Возвращает (текст, фото, ошибка)."""
    text = (m.text or m.caption or "").strip()
    photo = m.photo[-1].file_id if m.photo else None
    if not text:
        return None, None, "У фото нет подписи. Отправьте фото ещё раз и напишите текст напоминания в подписи."
    if photo and len(text) > 1000:
        return None, None, f"С фото текст не может быть длиннее 1000 символов (сейчас {len(text)}). Сократите."
    return text, photo, None


@router.message(Rem.text, F.text | F.photo)
async def rem_text(m: Message, state: FSMContext):
    if not await need(m, "reminders_manage"):
        await state.clear()
        return
    text, photo, err = _read_text_photo(m)
    if err:
        await m.answer("⚠️ " + err)
        return
    await state.update_data(text=text, photo=photo)
    await state.set_state(None)
    await m.answer("🗓 Когда напоминать?", reply_markup=_kind_kb())


@router.callback_query(F.data.startswith("rk:"))
async def rk(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "reminders_manage"):
        return
    d = await state.get_data()
    if not d.get("text"):
        await cb.answer("Сессия создания устарела. Начните заново.", show_alert=True)
        return
    kind = cb.data.split(":")[1]
    await state.update_data(kind=kind, days=[], dates=[])
    if kind == "once":
        await state.set_state(Rem.once)
        await show(cb, "Введите дату и время по Москве в формате ДД.ММ.ГГГГ ЧЧ:ММ\nнапример: 25.12.2026 18:30",
                   kb([("↩️ Отмена", "rem")]))
    elif kind == "weekly":
        await state.set_state(Rem.days)
        await show(cb, "🔁 Выберите дни недели (можно несколько):", _days_kb([]))
    else:
        today = logic.now_msk()
        await state.set_state(Rem.calendar)
        await show(cb, "📅 Отметьте даты в календаре (нажмите на число ещё раз, чтобы снять):",
                   _cal_kb(today.year, today.month, []))


@router.message(Rem.once, F.text)
async def rem_once(m: Message, state: FSMContext):
    dt = logic.parse_datetime_msk(m.text)
    if not dt:
        await m.answer("⚠️ Не понял дату. Формат: ДД.ММ.ГГГГ ЧЧ:ММ, например 25.12.2026 18:30")
        return
    if dt <= logic.now_msk():
        await m.answer("⚠️ Это время уже прошло. Введите дату и время в будущем (по Москве):")
        return
    await state.update_data(dates=[{"d": dt.strftime("%Y-%m-%d"), "t": dt.strftime("%H:%M")}])
    await state.set_state(None)
    await _ask_dest(m)


# --- дни недели ---
def _days_kb(selected: list):
    row1 = [(f"{'✅' if i in selected else ''}{logic.WEEKDAYS[i]}", f"rwd:{i}") for i in range(4)]
    row2 = [(f"{'✅' if i in selected else ''}{logic.WEEKDAYS[i]}", f"rwd:{i}") for i in range(4, 7)]
    return kb(row1, row2, [("✔️ Готово", "rwok")], [("↩️ Отмена", "rem")])


@router.callback_query(F.data.startswith("rwd:"))
async def rwd(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "reminders_manage"):
        return
    d = await state.get_data()
    if "days" not in d:
        await cb.answer("Сессия создания устарела. Начните заново.", show_alert=True)
        return
    day = int(cb.data.split(":")[1])
    days = [x for x in d["days"] if x != day] if day in d["days"] else d["days"] + [day]
    await state.update_data(days=days)
    await show(cb, "🔁 Выберите дни недели (можно несколько):", _days_kb(days))


@router.callback_query(F.data == "rwok")
async def rwok(cb: CallbackQuery, state: FSMContext):
    d = await state.get_data()
    if not d.get("days"):
        await cb.answer("Выберите хотя бы один день.", show_alert=True)
        return
    await _ask_time_mode(cb, state)


# --- календарь ---
def _cal_kb(year: int, month: int, selected: list):
    prev_y, prev_m = (year - 1, 12) if month == 1 else (year, month - 1)
    next_y, next_m = (year + 1, 1) if month == 12 else (year, month + 1)
    rows = [[("◀️", f"rcal:nav:{prev_y}-{prev_m:02d}"), (f"{logic.MONTHS[month - 1]} {year}", "rcal:noop"),
             ("▶️", f"rcal:nav:{next_y}-{next_m:02d}")],
            [(d, "rcal:noop") for d in logic.WEEKDAYS]]
    for week in calendar.monthcalendar(year, month):
        row = []
        for day in week:
            if day == 0:
                row.append((" ", "rcal:noop"))
            else:
                key = f"{year}-{month:02d}-{day:02d}"
                row.append((f"✅{day}" if key in selected else str(day), f"rcal:d:{key}"))
        rows.append(row)
    rows.append([(f"✔️ Готово ({len(selected)})", "rcal:ok")])
    rows.append([("↩️ Отмена", "rem")])
    return kb(*rows)


@router.callback_query(F.data.startswith("rcal:"))
async def rcal(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "reminders_manage"):
        return
    d = await state.get_data()
    if "dates" not in d or d.get("kind") != "dates":
        await cb.answer("Сессия создания устарела. Начните заново.", show_alert=True)
        return
    parts = cb.data.split(":", 2)
    action = parts[1]
    selected = [e if isinstance(e, str) else e["d"] for e in d["dates"]]
    if action == "noop":
        return
    if action == "nav":
        y, mo = map(int, parts[2].split("-"))
        await show(cb, "📅 Отметьте даты в календаре (нажмите на число ещё раз, чтобы снять):", _cal_kb(y, mo, selected))
    elif action == "d":
        key = parts[2]
        y, mo, day = map(int, key.split("-"))
        if key < logic.now_msk().strftime("%Y-%m-%d"):
            await cb.answer("Эта дата уже прошла.", show_alert=True)
            return
        selected = [x for x in selected if x != key] if key in selected else sorted(selected + [key])
        await state.update_data(dates=selected)
        await show(cb, "📅 Отметьте даты в календаре (нажмите на число ещё раз, чтобы снять):", _cal_kb(y, mo, selected))
    elif action == "ok":
        if not selected:
            await cb.answer("Отметьте хотя бы одну дату.", show_alert=True)
            return
        await _ask_time_mode(cb, state)


# --- время ---
async def _ask_time_mode(cb: CallbackQuery, state: FSMContext):
    await state.set_state(None)
    await show(cb, "🕒 Как задать время (московское)?", kb(
        [("Одно общее время для всех", "rtm:same")],
        [("Своё время для каждого дня/даты", "rtm:each")],
        [("↩️ Отмена", "rem")]))


def _labels(d: dict) -> list:
    """Подписи дней/дат для запроса времени."""
    if d["kind"] == "weekly":
        return [logic.WEEKDAYS[x] for x in sorted(d["days"])]
    out = []
    for key in d["dates"]:
        y, mo, day = key.split("-")
        out.append(f"{day}.{mo}.{y}")
    return out


QUICK_TIMES = ["09:00", "12:00", "15:00", "18:00", "21:00"]


def _time_kb():
    return kb([(t, f"rqt:{t.replace(':', '')}") for t in QUICK_TIMES], [("↩️ Отмена", "rem")])


@router.callback_query(F.data.startswith("rtm:"))
async def rtm(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "reminders_manage"):
        return
    d = await state.get_data()
    if d.get("kind") not in ("weekly", "dates"):
        await cb.answer("Сессия создания устарела. Начните заново.", show_alert=True)
        return
    if cb.data.endswith("same"):
        await state.set_state(Rem.time)
        await show(cb, "Выберите время (по Москве) или введите своё в формате ЧЧ:ММ, например 18:30:", _time_kb())
    else:
        await state.update_data(idx=0, times=[])
        await state.set_state(Rem.times)
        await show(cb, f"Время для «{_labels(d)[0]}»: выберите (по Москве) или введите ЧЧ:ММ:", _time_kb())


def _build_entries(d: dict, times: list) -> dict:
    if d["kind"] == "weekly":
        return {"weekly": [{"d": day, "t": t} for day, t in zip(sorted(d["days"]), times)]}
    return {"dates": [{"d": key, "t": t} for key, t in zip(d["dates"], times)]}


async def _apply_time(target, state: FSMContext, t: str, mode: str) -> None:
    """Применить выбранное время: mode 'time' — одно на все записи, 'times' — по очереди для каждой."""
    d = await state.get_data()
    labels = _labels(d)
    if mode == "time":
        await state.update_data(**_build_entries(d, [t] * len(labels)))
        await state.set_state(None)
        await _ask_dest(target)
        return
    times = d["times"] + [t]
    if len(times) < len(labels):
        await state.update_data(times=times, idx=len(times))
        text = f"Время для «{labels[len(times)]}»: выберите (по Москве) или введите ЧЧ:ММ:"
        if isinstance(target, Message):
            await target.answer(text, reply_markup=_time_kb())
        else:
            await show(target, text, _time_kb())
        return
    await state.update_data(**_build_entries(d, times))
    await state.set_state(None)
    await _ask_dest(target)


@router.message(Rem.time, F.text)
async def rem_time(m: Message, state: FSMContext):
    t = logic.parse_hhmm(m.text)
    if not t:
        await m.answer("⚠️ Не понял время. Формат ЧЧ:ММ, например 09:00 или 18:30")
        return
    await _apply_time(m, state, t, "time")


@router.message(Rem.times, F.text)
async def rem_times(m: Message, state: FSMContext):
    t = logic.parse_hhmm(m.text)
    if not t:
        await m.answer("⚠️ Не понял время. Формат ЧЧ:ММ, например 09:00 или 18:30")
        return
    await _apply_time(m, state, t, "times")


@router.callback_query(F.data.startswith("rqt:"))
async def rem_quick_time(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "reminders_manage"):
        return
    raw = cb.data.split(":")[1]
    t = logic.parse_hhmm(f"{raw[:2]}:{raw[2:]}")
    cur = await state.get_state()
    if not t or cur not in (Rem.time.state, Rem.times.state):
        await cb.answer("Сессия создания устарела. Начните заново.", show_alert=True)
        return
    await _apply_time(cb, state, t, "time" if cur == Rem.time.state else "times")


@router.message(Rem.once)
@router.message(Rem.time)
@router.message(Rem.times)
@router.message(Rem.text)
async def rem_bad(m: Message):
    await m.answer("⚠️ Нужен текст в нужном формате. Попробуйте ещё раз или отправьте /cancel.")


# --- куда отправлять ---
async def _ask_dest(target):
    markup = kb([("📍 В место публикации", "rdst:place")],
                [("🧵 В отдельную тему группы", "rdst:topic")],
                [("👤 В личку людям", "rdst:dm")],
                [("↩️ Отмена", "rem")])
    text = "📮 Куда отправлять напоминание?"
    if isinstance(target, Message):
        await target.answer(text, reply_markup=markup)
    else:
        await show(target, text, markup)


async def _save(target, state: FSMContext, uid: int, chat_id=None, thread=None, dm: str = ""):
    d = await state.get_data()
    kind = d["kind"]
    weekly = d.get("weekly", []) if kind == "weekly" else []
    dates = d.get("dates", []) if kind != "weekly" else []
    edit_id = d.get("edit_id")
    if edit_id and db.get_reminder(edit_id):
        db.set_reminder(edit_id, kind=kind, weekly=json.dumps(weekly), dates=json.dumps(dates), fired="[]",
                        chat_id=chat_id, thread=thread, dm_users=dm, active=1)
        rid, title = edit_id, "✅ Расписание и адрес обновлены."
    else:
        rid = db.add_reminder(d["text"], kind, weekly, dates, chat_id, thread, uid, dm, d.get("photo"))
        title = "✅ Напоминание создано."
    await state.clear()
    r = db.get_reminder(rid)
    markup = kb([("📨 Отправить сейчас", f"rn:{rid}")], [("⏰ К напоминаниям", "rem")])
    if isinstance(target, Message):
        await target.answer(title + "\n\n" + card_text(r), reply_markup=markup)
    else:
        await show(target, title + "\n\n" + card_text(r), markup)


@router.callback_query(F.data.startswith("rdst:"))
async def rdst(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "reminders_manage"):
        return
    d = await state.get_data()
    entries = d.get("weekly") or d.get("dates") or []
    if not d.get("kind") or not entries or not all(isinstance(e, dict) for e in entries):
        await cb.answer("Сессия создания устарела. Начните заново.", show_alert=True)
        return
    choice = cb.data.split(":")[1]
    if choice == "place":
        if not db.place()[0]:
            await cb.answer("Место публикации не задано. Сначала: раздел «Задания» → «Место публикации».", show_alert=True)
            return
        await _save(cb, state, cb.from_user.id)
    elif choice == "topic":
        await state.set_state(Rem.topic)
        await show(cb, "🧵 Пришлите ссылку на тему (https://t.me/c/1234567890/123) или числовой ID темы "
                       "в группе из места публикации:", kb([("↩️ Отмена", "rem")]))
    else:
        await state.set_state(Rem.dm)
        await show(cb, "👤 Введите ID или @username людей через запятую. Они должны были запускать бота:",
                   kb([("↩️ Отмена", "rem")]))


@router.message(Rem.topic, F.text)
async def rem_topic(m: Message, state: FSMContext):
    chat, thread, err = parse_topic(m.text, db.place()[0])
    if err:
        await m.answer("⚠️ " + err)
        return
    if not chat:
        await m.answer("⚠️ Группа неизвестна: сначала задайте место публикации или пришлите полную ссылку на тему.")
        return
    await _save(m, state, m.from_user.id, chat_id=chat, thread=thread)


@router.message(Rem.dm, F.text)
async def rem_dm(m: Message, state: FSMContext):
    found, missing = resolve_users(m.text)
    if missing or not found:
        await m.answer("⚠️ Не найдены: " + (", ".join(missing) or "список пуст") +
                       ". Человек должен хотя бы раз войти в бота. Введите ещё раз:")
        return
    await _save(m, state, m.from_user.id, dm=",".join(str(u["id"]) for u in found))


@router.message(Rem.topic)
@router.message(Rem.dm)
async def rem_dest_bad(m: Message):
    await m.answer("⚠️ Нужен текст. Отправьте ссылку/ID или отправьте /cancel.")


# ============================== Изменение готового напоминания ==============================
@router.callback_query(F.data.startswith("ret:"))
async def ret(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "reminders_manage"):
        return
    r = db.get_reminder(int(cb.data.split(":")[1]))
    if not r:
        await cb.answer("Напоминание не найдено.", show_alert=True)
        return
    rows = []
    if r.get("photo"):
        rows.append([("🗑 Убрать фото", f"ren:{r['id']}")])
    rows.append([("↩️ Отмена", f"rv:{r['id']}")])
    await state.set_data({"rid": r["id"]})
    await state.set_state(RemEdit.text)
    await show(cb, f"✏️ Сейчас:\n{r['text']}\n\nОтправьте новый текст — или фото с подписью (подпись станет текстом):",
               kb(*rows))


@router.message(RemEdit.text, F.text | F.photo)
async def ret_text(m: Message, state: FSMContext):
    if not await need(m, "reminders_manage"):
        await state.clear()
        return
    text, photo, err = _read_text_photo(m)
    if err:
        await m.answer("⚠️ " + err)
        return
    rid = (await state.get_data()).get("rid")
    r = db.get_reminder(rid) if rid else None
    if not r:
        await state.clear()
        await m.answer("⚠️ Напоминание уже удалено.")
        return
    db.set_reminder(rid, text=text, photo=photo or r.get("photo"))
    await state.clear()
    await m.answer("✅ Текст обновлён.\n\n" + card_text(db.get_reminder(rid)),
                   reply_markup=kb([("⏰ К напоминанию", f"rv:{rid}")]))


@router.message(RemEdit.text)
async def ret_bad(m: Message):
    await m.answer("⚠️ Нужен текст или фото с подписью. Попробуйте ещё раз или отправьте /cancel.")


@router.callback_query(F.data.startswith("ren:"))
async def ren(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "reminders_manage"):
        return
    rid = int(cb.data.split(":")[1])
    if not db.get_reminder(rid):
        await cb.answer("Напоминание не найдено.", show_alert=True)
        return
    db.set_reminder(rid, photo=None)
    await state.clear()
    await cb.answer("Фото убрано.")
    await _card(cb, rid)


@router.callback_query(F.data.startswith("res:"))
async def res_edit(cb: CallbackQuery, state: FSMContext):
    """Заново задать расписание и адрес — текст и фото остаются."""
    if not await need(cb, "reminders_manage"):
        return
    r = db.get_reminder(int(cb.data.split(":")[1]))
    if not r:
        await cb.answer("Напоминание не найдено.", show_alert=True)
        return
    await state.set_data({"text": r["text"], "photo": r.get("photo"), "edit_id": r["id"]})
    await state.set_state(None)
    await show(cb, "🗓 Когда напоминать теперь?", _kind_kb())
