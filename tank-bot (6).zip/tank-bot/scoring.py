"""Баллы, шкала статусов, фразы поддержки, ручное начисление."""
import re

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

import db
import logic
import perms
from common import award, fmt_user, kb, need, notify, pager_row, preview, show, status_label

router = Router()

# (ключ настройки, подпись, тип)
SCORE_FIELDS = [
    ("score_right", "✅ Итог «Правильно»", int),
    ("score_partial", "🟡 Итог «Частично»", int),
    ("score_wrong", "❌ Итог «Неправильно»", int),
    ("score_bad", "🚫 Итог «Совсем неверно»", int),
    ("score_per_grade", "⭐ За каждый пункт оценки 1–10", float),
    ("best_bonus", "🏆 Бонус за лучшую работу", int),
]
SCORE_BY_KEY = {k: (label, typ) for k, label, typ in SCORE_FIELDS}


class Pts(StatesGroup):
    ident = State()
    amount = State()
    reason = State()


class SetVal(StatesGroup):
    value = State()


class Phrase(StatesGroup):
    text = State()


# ============================== Ручное начисление ==============================
REASONS = ["Отличная работа", "Помощь команде", "Активность в проекте", "Бонус за скорость",
           "Штраф за срыв срока", "Корректировка баллов"]


def _amount_kb():
    return kb([("+1", "pq:+1"), ("+3", "pq:+3"), ("+5", "pq:+5"), ("+10", "pq:+10")],
              [("−1", "pq:-1"), ("−3", "pq:-3"), ("−5", "pq:-5")],
              [("✏️ Своё число", "pqc")], [("↩️ Отмена", "sec:people")])


def _reason_kb():
    rows = [[(REASONS[i], f"pr:{i}"), (REASONS[i + 1], f"pr:{i + 1}")] for i in range(0, len(REASONS), 2)]
    rows.append([("✏️ Своя причина", "prc")])
    rows.append([("↩️ Отмена", "sec:people")])
    return kb(*rows)


async def _padj_list(cb: CallbackQuery, page: int) -> None:
    size = 8
    users, total = db.users_page(page, size)
    rows = [[(f"{preview(fmt_user(u), 26)} · {u['points']}", f"padju:{u['id']}")] for u in users]
    pg = pager_row("padjl", page, total, size)
    if pg:
        rows.append(pg)
    rows.append([("🔎 Ввести ID или @username", "padjs")])
    rows.append([("🔙 Назад", "sec:people")])
    await show(cb, "⭐ Начисление и снятие баллов\n\nВыберите участника из списка:" if users else
               "⭐ Участников пока нет.", kb(*rows))


@router.callback_query(F.data == "padj")
async def padj(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "points_edit"):
        return
    await state.clear()
    await _padj_list(cb, 0)


@router.callback_query(F.data.startswith("padjl:"))
async def padj_page(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "points_edit"):
        return
    await state.clear()
    await _padj_list(cb, int(cb.data.split(":")[1]))


@router.callback_query(F.data == "padjs")
async def padj_search(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "points_edit"):
        return
    await state.set_state(Pts.ident)
    await show(cb, "🔎 Введите ID или @username участника:", kb([("↩️ Назад к списку", "padj")]))


@router.callback_query(F.data.startswith("padju:"))
async def padju(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "points_edit"):
        return
    u = db.get_user(int(cb.data.split(":")[1]))
    if not u or not u["role"]:
        await cb.answer("Участник не найден.", show_alert=True)
        return
    await state.set_data({"uid": u["id"]})
    await state.set_state(Pts.amount)
    await show(cb, f"⭐ {fmt_user(u)} — сейчас {u['points']} баллов.\n\nСколько начислить или снять? "
                   f"Выберите или введите число (например 7 или -2):", _amount_kb())


@router.message(Pts.ident, F.text)
async def pts_ident(m: Message, state: FSMContext):
    if not await need(m, "points_edit"):
        await state.clear()
        return
    u = db.find_user(m.text)
    if not u or not u["role"]:
        await m.answer("⚠️ Участник не найден. Он должен хотя бы раз войти в бота. "
                       "Введите ID или @username ещё раз:")
        return
    await state.set_data({"uid": u["id"]})
    await state.set_state(Pts.amount)
    await m.answer(f"⭐ {fmt_user(u)} — сейчас {u['points']} баллов.\n\nСколько начислить или снять? "
                   f"Выберите или введите число (например 7 или -2):", reply_markup=_amount_kb())


async def _ask_reason(target, state: FSMContext, amount: int) -> None:
    await state.update_data(amount=amount)
    await state.set_state(Pts.reason)
    text = f"💬 Причина ({amount:+d} баллов) — она придёт участнику. Выберите или напишите свою:"
    if isinstance(target, Message):
        await target.answer(text, reply_markup=_reason_kb())
    else:
        await show(target, text, _reason_kb())


@router.message(Pts.amount, F.text)
async def pts_amount(m: Message, state: FSMContext):
    if not re.fullmatch(r"[+-]?\d{1,4}", m.text.strip()) or int(m.text) == 0:
        await m.answer("⚠️ Нужно целое число, не ноль (например 5 или -3). Попробуйте ещё раз:", reply_markup=_amount_kb())
        return
    await _ask_reason(m, state, int(m.text))


@router.callback_query(F.data.startswith("pq:"))
async def pts_quick_amount(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "points_edit"):
        return
    if await state.get_state() != Pts.amount.state:
        await cb.answer("Сессия устарела. Начните заново: «Начислить баллы».", show_alert=True)
        return
    await _ask_reason(cb, state, int(cb.data.split(":")[1]))


@router.callback_query(F.data == "pqc")
async def pts_custom_amount(cb: CallbackQuery):
    await cb.answer("Напишите число сообщением, например 7 или -2.", show_alert=True)


async def _do_award(target, state: FSMContext, reason: str) -> None:
    d = await state.get_data()
    await state.clear()
    if "uid" not in d or "amount" not in d:
        await show(target, "⚠️ Сессия устарела. Начните заново: «Начислить баллы».", kb([("⭐ Начислить", "padj")]))
        return
    total, promoted = await award(d["uid"], d["amount"], reason[:300])
    u = db.get_user(d["uid"])
    text = f"✅ {fmt_user(u)}: {d['amount']:+d} → теперь {total} баллов.\nПричина: {reason[:300]}"
    if promoted:
        text += f"\n🎉 Присвоен статус: {status_label(promoted)}"
    await show(target, text, kb([("⭐ Ещё начисление", "padj"), ("🔙 К участникам", "sec:people")]))


@router.callback_query(F.data.startswith("pr:"))
async def pts_quick_reason(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "points_edit"):
        return
    idx = int(cb.data.split(":")[1])
    if await state.get_state() != Pts.reason.state or not 0 <= idx < len(REASONS):
        await cb.answer("Сессия устарела. Начните заново: «Начислить баллы».", show_alert=True)
        return
    await _do_award(cb, state, REASONS[idx])


@router.callback_query(F.data == "prc")
async def pts_custom_reason(cb: CallbackQuery):
    await cb.answer("Напишите причину сообщением.", show_alert=True)


@router.message(Pts.reason, F.text)
async def pts_reason(m: Message, state: FSMContext):
    if not await need(m, "points_edit"):
        await state.clear()
        return
    await _do_award(m, state, m.text.strip())


@router.message(Pts.ident)
@router.message(Pts.amount)
@router.message(Pts.reason)
async def pts_bad(m: Message):
    await m.answer("⚠️ Нужен текстовый ответ. Попробуйте ещё раз или отправьте /cancel.")


# ============================== Настройки баллов ==============================
def _score_screen():
    cfg = db.score_cfg()
    lines = ["⚙️ Настройки баллов\n",
             "Баллы за работу = баллы за итог + (оценка × коэффициент).\n"]
    rows = []
    for key, label, _typ in SCORE_FIELDS:
        lines.append(f"{label}: {cfg[key]}")
        rows.append([(f"{label}: {cfg[key]}", f"scs:{key}")])
    rows.append([("🔙 Назад", "sec:settings")])
    return "\n".join(lines) + "\n\nНажмите на параметр, чтобы изменить.", kb(*rows)


@router.callback_query(F.data == "scs")
async def scs(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "scoring_edit"):
        return
    await state.clear()
    text, markup = _score_screen()
    await show(cb, text, markup)


@router.callback_query(F.data.startswith("scs:"))
async def scs_pick(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "scoring_edit"):
        return
    key = cb.data.split(":")[1]
    if key not in SCORE_BY_KEY:
        await cb.answer("Неизвестный параметр.", show_alert=True)
        return
    label, typ = SCORE_BY_KEY[key]
    await state.set_data({"kind": "score", "key": key})
    await state.set_state(SetVal.value)
    hint = "число, можно дробное (например 0.5)" if typ is float else "целое число от 0 до 1000"
    await show(cb, f"{label}\nСейчас: {db.get_setting(key)}\n\nВведите новое значение — {hint}:",
               kb([("↩️ Отмена", "scs")]))


# ============================== Шкала статусов ==============================
def _ladder_screen():
    lad = db.ladder()
    lines = ["📈 Шкала повышения статусов (баллов нужно набрать)\n"]
    rows = []
    for status, key, _default in perms.LADDER:
        lines.append(f"{status_label(status)}: с {lad[status]} баллов")
        rows.append([(f"{status_label(status)}: {lad[status]}", f"rks:{status}")])
    rows.append([("🔙 Назад", "sec:settings")])
    return "\n".join(lines) + "\n\nПовышение автоматическое, понижения нет.", kb(*rows)


@router.callback_query(F.data == "rks")
async def rks(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "ranks_edit"):
        return
    await state.clear()
    text, markup = _ladder_screen()
    await show(cb, text, markup)


@router.callback_query(F.data.startswith("rks:"))
async def rks_pick(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "ranks_edit"):
        return
    status = cb.data.split(":")[1]
    if status not in db.ladder():
        await cb.answer("Неизвестный статус.", show_alert=True)
        return
    await state.set_data({"kind": "ladder", "key": status})
    await state.set_state(SetVal.value)
    await show(cb, f"{status_label(status)}\nСейчас: {db.ladder()[status]} баллов\n\n"
                   f"Введите новый порог (целое число от 1 до 10000):", kb([("↩️ Отмена", "rks")]))


async def _recalc_statuses():
    """После смены шкалы повышаем тех, кто уже набрал нужные баллы."""
    lad = db.ladder()
    for u in db.authorized_users():
        if u["status"] == "owner":
            continue
        target = logic.status_for_points(u["points"], lad)
        if logic.status_rank(target) > logic.status_rank(u["status"]):
            db.set_user(u["id"], status=target)
            await notify(u["id"], f"🎉 Новый статус: {status_label(target)}!")


@router.message(SetVal.value, F.text)
async def setval(m: Message, state: FSMContext):
    d = await state.get_data()
    kind, key = d.get("kind"), d.get("key")
    raw = m.text.strip().replace(",", ".")
    if kind == "score":
        if not await need(m, "scoring_edit"):
            await state.clear()
            return
        typ = SCORE_BY_KEY[key][1]
        try:
            val = typ(raw)
        except ValueError:
            await m.answer("⚠️ Это не число. Введите значение ещё раз:")
            return
        if val < 0 or val > (100 if typ is float else 1000):
            await m.answer("⚠️ Значение вне допустимых пределов. Введите ещё раз:")
            return
        db.set_setting(key, val)
        await state.clear()
        text, markup = _score_screen()
        await m.answer("✅ Сохранено.\n\n" + text, reply_markup=markup)
    elif kind == "ladder":
        if not await need(m, "ranks_edit"):
            await state.clear()
            return
        if not raw.isdigit() or not 1 <= int(raw) <= 10000:
            await m.answer("⚠️ Нужно целое число от 1 до 10000. Введите ещё раз:")
            return
        lad = db.ladder()
        lad[key] = int(raw)
        if not lad["member"] < lad["best"] < lad["lead"]:
            await m.answer("⚠️ Пороги должны расти: Участник < Лучший участник < Ведущий. "
                           "Введите другое значение:")
            return
        db.set_setting(f"ladder_{key}", int(raw))
        await state.clear()
        await _recalc_statuses()
        text, markup = _ladder_screen()
        await m.answer("✅ Сохранено.\n\n" + text, reply_markup=markup)
    else:
        await state.clear()
        await m.answer("Сессия устарела. Откройте меню: /menu")


@router.message(SetVal.value)
async def setval_bad(m: Message):
    await m.answer("⚠️ Нужно число. Попробуйте ещё раз или отправьте /cancel.")


# ============================== Фразы поддержки ==============================
def _phrases_screen():
    items = db.list_phrases()[:40]
    lines = [f"💬 Фразы поддержки ({len(items)}). Их бот добавляет, когда результат работы "
             f"не идеален или баллы сняты.\n"]
    rows = [[("➕ Добавить фразу", "pha")]]
    for i, p in enumerate(items, 1):
        lines.append(f"{i}. {p['text']}")
        rows.append([(f"✏️ {i}", f"phe:{p['id']}"), (f"🗑 {i}", f"phd:{p['id']}")])
    rows.append([("🔙 Назад", "sec:settings")])
    return "\n".join(lines), kb(*rows)


@router.callback_query(F.data == "phr")
async def phr(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "scoring_edit"):
        return
    await state.clear()
    text, markup = _phrases_screen()
    await show(cb, text, markup)


@router.callback_query(F.data == "pha")
async def pha(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "scoring_edit"):
        return
    await state.set_data({"mode": "add"})
    await state.set_state(Phrase.text)
    await show(cb, "✏️ Отправьте текст новой фразы поддержки:", kb([("↩️ Отмена", "phr")]))


@router.callback_query(F.data.startswith("phe:"))
async def phe(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "scoring_edit"):
        return
    pid = int(cb.data.split(":")[1])
    row = db.one("SELECT * FROM phrases WHERE id=?", (pid,))
    if not row:
        await cb.answer("Фраза не найдена.", show_alert=True)
        return
    await state.set_data({"mode": "edit", "pid": pid})
    await state.set_state(Phrase.text)
    await show(cb, f"Сейчас:\n{row['text']}\n\nОтправьте новый текст фразы:", kb([("↩️ Отмена", "phr")]))


@router.callback_query(F.data.startswith("phd:"))
async def phd(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "scoring_edit"):
        return
    db.del_phrase(int(cb.data.split(":")[1]))
    await cb.answer("Фраза удалена.")
    await state.clear()
    text, markup = _phrases_screen()
    await show(cb, text, markup)


@router.message(Phrase.text, F.text)
async def phrase_text(m: Message, state: FSMContext):
    if not await need(m, "scoring_edit"):
        await state.clear()
        return
    d = await state.get_data()
    text = m.text.strip()[:300]
    if d.get("mode") == "edit":
        db.set_phrase(d["pid"], text)
    else:
        db.add_phrase(text)
    await state.clear()
    scr, markup = _phrases_screen()
    await m.answer("✅ Сохранено.\n\n" + scr, reply_markup=markup)


@router.message(Phrase.text)
async def phrase_bad(m: Message):
    await m.answer("⚠️ Фраза должна быть текстом. Отправьте текст или /cancel.")
