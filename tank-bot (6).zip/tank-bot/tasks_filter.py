"""Разбор меток заданий aid<номер>_<код> и фильтрация по должностям."""
import re
from typing import Optional

from perms import CODE_BY_POS, POS_BY_CODE

LABEL_RE = re.compile(r"aid(\d+)_([0-4])", re.IGNORECASE)

# Старые правила: слово в начале сообщения (основа слова → должность)
WORD_STEMS = {
    "художник": "artist",
    "сценарист": "writer",
    "аниматор": "animator",
    "помощник": "helper",
}


def parse_label(text: str) -> Optional[tuple]:
    """Ищет метку aid<номер>_<код>. Возвращает (номер, код) или None."""
    m = LABEL_RE.search(text or "")
    if not m:
        return None
    return int(m.group(1)), m.group(2)


def classify(text: str) -> tuple:
    """Возвращает (aid, должность или None, есть_ли_метка).

    С меткой — должность по коду (0 → для всех).
    Без метки: 🎨/🖌 → художник; 🎬 → аниматор;
    первое или второе слово = название должности; иначе — общее задание.
    """
    text = text or ""
    label = parse_label(text)
    if label:
        aid, code = label
        return aid, POS_BY_CODE.get(code), True
    if "🎨" in text or "🖌" in text:
        return None, "artist", False
    if "🎬" in text:
        return None, "animator", False
    words = re.findall(r"[\w-]+", text.lower())
    for word in words[:2]:
        for stem, pos in WORD_STEMS.items():
            if word.startswith(stem):
                return None, pos, False
    return None, None, False


def visible_for(task_pos: Optional[str], user_pos: Optional[str]) -> bool:
    """Участник видит задания своей должности и общие."""
    return task_pos is None or task_pos == user_pos


def make_label(aid: int, pos: Optional[str]) -> str:
    return f"aid{aid}_{CODE_BY_POS.get(pos, 0)}"
