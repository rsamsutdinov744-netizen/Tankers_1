"""Работы, проверка и оценка, формы выполнения, опросы, лучшая работа, кураторы."""
import json
import logging

from aiogram import F, Router
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

import db
import logic
import perms
import tasks_filter as tf
from common import (award, clip, err_text, finish_task, fmt_user, get_bot, has_perm, is_gone, kb, need,
                    notify, pos_label, preview, progress_line, safe_send, send_rich, show, status_label)
from logic import RESULT_NAMES

log = logging.getLogger("tank-bot")
router = Router()


class Submit(StatesGroup):
    free = State()
    answers = State()


class Review(StatesGroup):
    comment = State()


class FormNew(StatesGroup):
    title = State()
    questions = State()


# ============================== Вспомогательное ==============================
def work_body(w: dict) -> str:
    if w["kind"] == "form":
        parts = [f"❓ {a['q']}\n💬 {a['a']}" for a in db.jl(w["answers"])]
        return f"📝 Форма «{w['text']}»\n\n" + "\n\n".join(parts)
    return w["text"] or "(без текста, только файлы)"


def work_header(w: dict) -> str:
    u = db.get_user(w["user_id"])
    t = db.get_task(w["task_id"])
    task = preview(t["text"], 100) if t else "—"
    return (f"📥 Работа #{w['id']} по заданию #{w['task_id']}\n"
            f"👤 {fmt_user(u)} · {pos_label(u['pos'] if u else None)}\n"
            f"🗓 {logic.fmt_ts(w['created_at'])}\n"
            f"📋 Задание: {task}\n\n{work_body(w)}")


async def send_work(chat_id: int, w: dict, markup=None, thread=None, title=None, attach=None):
    """Отправить работу (текст + вложения). Каждое вложение уходит С ПОДПИСЬЮ («Вложение к работе №…»)."""
    msg = await safe_send(chat_id, title or work_header(w), reply_markup=markup, message_thread_id=thread)
    bot = get_bot()
    files = db.jl(w["files"])
    for i, (kind, fid) in enumerate(files, 1):
        caption = attach or f"📎 Вложение к работе #{w['id']}"
        if len(files) > 1:
            caption += f" ({i}/{len(files)})"
        try:
            if kind == "photo":
                await bot.send_photo(chat_id, fid, caption=caption, message_thread_id=thread)
            elif kind == "video":
                await bot.send_video(chat_id, fid, caption=caption, message_thread_id=thread)
            else:
                await bot.send_document(chat_id, fid, caption=caption, message_thread_id=thread)
        except TelegramAPIError as e:
            log.warning("Не удалось отправить файл работы #%s: %s", w["id"], err_text(e))
    return msg


def grade_kb(wid: int):
    return kb([(str(i), f"wg:{wid}:{i}") for i in range(1, 6)],
              [(str(i), f"wg:{wid}:{i}") for i in range(6, 11)])


def result_kb(wid: int, grade: int):
    return kb([("✅ Правильно", f"wres:{wid}:{grade}:right"), ("🟡 Частично", f"wres:{wid}:{grade}:partial")],
              [("❌ Неправильно", f"wres:{wid}:{grade}:wrong"), ("🚫 Совсем неверно", f"wres:{wid}:{grade}:bad")],
              [("↩️ Другая оценка", f"wb:{wid}")])


async def _set_markup(cb: CallbackQuery, markup) -> None:
    if cb.message is None:
        return
    try:
        await get_bot().edit_message_reply_markup(chat_id=cb.message.chat.id,
                                                  message_id=cb.message.message_id, reply_markup=markup)
    except TelegramBadRequest as e:
        if "not modified" not in str(e).lower():
            log.warning("Не удалось изменить кнопки: %s", err_text(e))


def reviewers_of(w: dict) -> list:
    """Владелец(ы) и куратор должности (без автора работы)."""
    t = db.get_task(w["task_id"])
    author = db.get_user(w["user_id"])
    pos = t["pos"] if t and t["pos"] else (author["pos"] if author else None)
    ids = list(db.owner_ids())
    cur = db.get_curator(pos)
    if cur and cur not in ids:
        ids.append(cur)
    return [i for i in ids if i != w["user_id"]]


def can_review(uid: int, w: dict) -> bool:
    if w["user_id"] == uid:
        return False
    if has_perm(uid, "works_review"):
        return True
    return uid in reviewers_of(w)


# ============================== Сдача работ (участник) ==============================
def _submit_error(user: dict, task) -> str:
    if not task or task["final"] or task["status"] not in ("active", "done"):
        return "Приём работ по этому заданию закрыт."
    if not tf.visible_for(task["pos"], user["pos"]):
        return "Это задание для другой должности. Выберите свою должность в меню."
    return ""


@router.callback_query(F.data.startswith("wsub:"))
async def wsub(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    tid = int(cb.data.split(":")[1])
    err = _submit_error(db.get_user(cb.from_user.id), db.get_task(tid))
    if err:
        await cb.answer("⛔ " + err, show_alert=True)
        return
    await show(cb, f"📤 Сдача работы по заданию #{tid}\n\nКак сдаём?", kb(
        [("✍️ Свободный отчёт", f"wfree:{tid}")],
        [("📝 По форме (вопросы)", f"wform:{tid}")],
        [("🔙 К заданию", f"tv:{tid}")]))


@router.callback_query(F.data.startswith("wfree:"))
async def wfree(cb: CallbackQuery, state: FSMContext):
    tid = int(cb.data.split(":")[1])
    err = _submit_error(db.get_user(cb.from_user.id), db.get_task(tid))
    if err:
        await cb.answer("⛔ " + err, show_alert=True)
        return
    await state.set_data({"tid": tid, "texts": [], "files": []})
    await state.set_state(Submit.free)
    await show(cb, "✍️ Свободный отчёт\n\nОтправьте текст, фото, файлы или видео — можно несколькими "
                   "сообщениями. Когда всё готово, нажмите «✅ Отправить».",
               kb([("↩️ Отмена", f"tv:{tid}")]))


@router.message(Submit.free, F.text | F.photo | F.document | F.video)
async def free_collect(m: Message, state: FSMContext):
    d = await state.get_data()
    texts, files = d["texts"], d["files"]
    if m.text:
        texts.append(m.text)
    else:
        if m.caption:
            texts.append(m.caption)
        if m.photo:
            files.append(["photo", m.photo[-1].file_id])
        elif m.document:
            files.append(["document", m.document.file_id])
        elif m.video:
            files.append(["video", m.video.file_id])
    await state.update_data(texts=texts, files=files)
    await m.answer(f"📥 Принято. Сейчас в отчёте: текстов — {len(texts)}, файлов — {len(files)}.\n"
                   f"Добавьте ещё или нажмите «✅ Отправить».",
                   reply_markup=kb([("✅ Отправить", "wsend")], [("↩️ Отмена", f"tv:{d['tid']}")]))


@router.message(Submit.free)
async def free_bad(m: Message):
    await m.answer("⚠️ Отправьте текст, фото, файл или видео. Другие типы сообщений не принимаются.")


async def _submit_work(uid: int, tid: int, kind: str, text, files, form_id=None, answers=None) -> tuple:
    """Создать работу и разослать проверяющим. Возвращает (id или None, ошибка)."""
    err = _submit_error(db.get_user(uid), db.get_task(tid))
    if err:
        return None, err
    wid = db.add_work(tid, uid, kind, text, files, form_id, answers)
    w = db.get_work(wid)
    sent = 0
    for rid in reviewers_of(w):
        msg = await send_work(rid, w, markup=grade_kb(wid), title=work_header(w) + "\n\n⭐ Выберите оценку 1–10:")
        sent += 1 if msg else 0
    if not sent:
        log.warning("Работа #%s некому проверять", wid)
    return wid, ""


@router.callback_query(F.data == "wsend")
async def wsend(cb: CallbackQuery, state: FSMContext):
    d = await state.get_data()
    if "tid" not in d or (not d.get("texts") and not d.get("files")):
        await cb.answer("Сначала отправьте текст, фото или файл.", show_alert=True)
        return
    wid, err = await _submit_work(cb.from_user.id, d["tid"], "free", "\n\n".join(d["texts"]) or None, d["files"])
    await state.clear()
    if err:
        await show(cb, "⛔ " + err, kb([("🔙 К заданиям", "tasks")]))
        return
    await show(cb, f"✅ Работа #{wid} отправлена на проверку. Вам придёт уведомление с оценкой.",
               kb([("📋 К заданиям", "tasks"), ("🏠 Меню", "menu")]))


@router.callback_query(F.data.startswith("wform:"))
async def wform(cb: CallbackQuery, state: FSMContext):
    tid = int(cb.data.split(":")[1])
    forms = db.list_forms(cb.from_user.id, True)
    if not forms:
        await show(cb, "📝 Форм пока нет. Админ может создать общую форму, а вы — личную "
                       "(Профиль → Мои формы). Или сдайте свободный отчёт.",
                   kb([("✍️ Свободный отчёт", f"wfree:{tid}")], [("🔙 Назад", f"wsub:{tid}")]))
        return
    rows = [[(f"{'👤' if f['owner_id'] else '👥'} {preview(f['title'], 40)}", f"wf:{tid}:{f['id']}")] for f in forms[:40]]
    rows.append([("🔙 Назад", f"wsub:{tid}")])
    await show(cb, "📝 Выберите форму (👥 общие, 👤 личные):", kb(*rows))


@router.callback_query(F.data.startswith("wf:"))
async def wf(cb: CallbackQuery, state: FSMContext):
    _, tid, fid = cb.data.split(":")
    tid, fid = int(tid), int(fid)
    err = _submit_error(db.get_user(cb.from_user.id), db.get_task(tid))
    form = db.get_form(fid)
    if err or not form:
        await cb.answer("⛔ " + (err or "Форма не найдена."), show_alert=True)
        return
    if form["owner_id"] and form["owner_id"] != cb.from_user.id:
        await cb.answer("⛔ Это чужая личная форма.", show_alert=True)
        return
    await state.set_data({"tid": tid, "fid": fid, "idx": 0, "answers": []})
    await state.set_state(Submit.answers)
    qs = db.jl(form["questions"])
    await show(cb, f"📝 Форма «{form['title']}»\n\nВопрос 1 из {len(qs)}:\n{qs[0]}",
               kb([("↩️ Отмена", f"tv:{tid}")]))


@router.message(Submit.answers, F.text)
async def form_answer(m: Message, state: FSMContext):
    d = await state.get_data()
    form = db.get_form(d["fid"])
    if not form:
        await state.clear()
        await m.answer("⚠️ Форму удалили, пока вы отвечали. Начните сдачу заново: /menu")
        return
    qs = db.jl(form["questions"])
    answers = d["answers"] + [{"q": qs[d["idx"]], "a": m.text}]
    idx = d["idx"] + 1
    if idx < len(qs):
        await state.update_data(answers=answers, idx=idx)
        await m.answer(f"Вопрос {idx + 1} из {len(qs)}:\n{qs[idx]}", reply_markup=kb([("↩️ Отмена", f"tv:{d['tid']}")]))
        return
    wid, err = await _submit_work(m.from_user.id, d["tid"], "form", form["title"], [], form["id"], answers)
    await state.clear()
    if err:
        await m.answer("⛔ " + err, reply_markup=kb([("🔙 К заданиям", "tasks")]))
        return
    await m.answer(f"✅ Работа #{wid} отправлена на проверку. Вам придёт уведомление с оценкой.",
                   reply_markup=kb([("📋 К заданиям", "tasks"), ("🏠 Меню", "menu")]))


@router.message(Submit.answers)
async def form_bad(m: Message):
    await m.answer("⚠️ На вопросы формы нужно отвечать текстом. Напишите ответ:")


# ============================== Проверка работ ==============================
@router.callback_query(F.data == "wlist")
async def wlist(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "works_review"):
        return
    await state.clear()
    works = [w for w in db.pending_works(30) if w["user_id"] != cb.from_user.id]
    if not works:
        await show(cb, "📥 Работ на проверку нет. 🎉", kb([("🔙 Назад", "sec:works")]))
        return
    rows = [[(f"#{w['id']} {preview(fmt_user(db.get_user(w['user_id'])), 22)} → задание #{w['task_id']}", f"wo:{w['id']}")]
            for w in works]
    rows.append([("🔙 Назад", "sec:works")])
    await show(cb, "📥 Работы на проверку — выберите:", kb(*rows))


@router.callback_query(F.data.startswith("wo:"))
async def wo(cb: CallbackQuery):
    w = db.get_work(int(cb.data.split(":")[1]))
    if not w:
        await cb.answer("Работа не найдена.", show_alert=True)
        return
    if not can_review(cb.from_user.id, w):
        await cb.answer("⛔ Нет разрешения проверять эту работу (или это ваша собственная работа).", show_alert=True)
        return
    if w["status"] == "reviewed":
        await cb.answer("Эта работа уже проверена.", show_alert=True)
        return
    await send_work(cb.from_user.id, w, markup=grade_kb(w["id"]), title=work_header(w) + "\n\n⭐ Выберите оценку 1–10:")


async def _check_review_access(cb: CallbackQuery, wid: int):
    w = db.get_work(wid)
    if not w:
        await cb.answer("Работа не найдена.", show_alert=True)
        return None
    if not can_review(cb.from_user.id, w):
        await cb.answer("⛔ Нет разрешения проверять эту работу.", show_alert=True)
        return None
    if w["status"] == "reviewed":
        await cb.answer("Эту работу уже проверили.", show_alert=True)
        await _set_markup(cb, None)
        return None
    return w


@router.callback_query(F.data.startswith("wg:"))
async def wg(cb: CallbackQuery):
    _, wid, grade = cb.data.split(":")
    if await _check_review_access(cb, int(wid)):
        await _set_markup(cb, result_kb(int(wid), int(grade)))


@router.callback_query(F.data.startswith("wb:"))
async def wb(cb: CallbackQuery):
    wid = int(cb.data.split(":")[1])
    if await _check_review_access(cb, wid):
        await _set_markup(cb, grade_kb(wid))


@router.callback_query(F.data.startswith("wres:"))
async def wres(cb: CallbackQuery, state: FSMContext):
    _, wid, grade, res = cb.data.split(":")
    if not await _check_review_access(cb, int(wid)):
        return
    await state.set_data({"wid": int(wid), "grade": int(grade), "res": res,
                          "chat": cb.message.chat.id if cb.message else None,
                          "mid": cb.message.message_id if cb.message else None})
    await state.set_state(Review.comment)
    await safe_send(cb.from_user.id,
                    f"💬 Оценка {grade}/10, итог: {RESULT_NAMES[res]}.\n"
                    f"Напишите комментарий для автора работы #{wid} (можно приложить фото с подписью) "
                    f"или нажмите «Без комментария».",
                    reply_markup=kb([("Без комментария", "wnc")]))


async def _finish_review(reviewer_id: int, d: dict, comment: str, photo=None) -> str:
    w = db.get_work(d["wid"])
    if not w:
        return "⚠️ Работа не найдена."
    if w["status"] == "reviewed":
        return "⚠️ Эту работу уже проверил другой проверяющий."
    grade, res = d["grade"], d["res"]
    pts = logic.work_points(res, grade, db.score_cfg())
    db.set_work(w["id"], status="reviewed", grade=grade, result=res, comment=comment or None,
                comment_photo=photo, points=pts, reviewer_id=reviewer_id, reviewed_at=db.now())
    total, promoted = await award(w["user_id"], pts, "", notify_user=False)
    text = (f"📬 Ваша работа #{w['id']} по заданию #{w['task_id']} проверена\n\n"
            f"Оценка: {grade}/10\nИтог: {RESULT_NAMES[res]}\n")
    if comment:
        text += f"Комментарий: {comment}\n"
    text += f"\n➕ Баллов за работу: {pts}. Всего: {total}"
    if promoted:
        text += f"\n🎉 Новый статус: {status_label(promoted)}!"
    prog = progress_line(db.get_user(w["user_id"]))
    if prog:
        text += "\n\n" + prog
    if res != "right":
        text += "\n\n" + db.random_phrase()
    await send_rich(w["user_id"], text, photo=photo)
    if d.get("chat") and d.get("mid"):
        try:
            await get_bot().edit_message_reply_markup(chat_id=d["chat"], message_id=d["mid"], reply_markup=None)
        except TelegramAPIError:
            pass
    extra = ""
    if res == "right":
        t = db.get_task(w["task_id"])
        if t and t["status"] == "active":
            _, msg = await finish_task(t["id"], "done", reviewer_id)
            extra = "\n" + msg
    return f"✅ Работа #{w['id']} проверена: {grade}/10, {RESULT_NAMES[res]}, автору +{pts} баллов.{extra}"


@router.message(Review.comment, F.text | F.photo)
async def review_comment(m: Message, state: FSMContext):
    """Комментарий проверяющего: текст или фото (подпись фото = текст комментария)."""
    d = await state.get_data()
    await state.clear()
    comment = (m.text or m.caption or "").strip()[:900]
    photo = m.photo[-1].file_id if m.photo else None
    await m.answer(await _finish_review(m.from_user.id, d, comment, photo))


@router.callback_query(F.data == "wnc")
async def review_no_comment(cb: CallbackQuery, state: FSMContext):
    d = await state.get_data()
    if "wid" not in d:
        await cb.answer("Сессия проверки устарела. Откройте работу заново.", show_alert=True)
        return
    await state.clear()
    await safe_send(cb.from_user.id, await _finish_review(cb.from_user.id, d, ""))


@router.message(Review.comment)
async def review_bad(m: Message):
    await m.answer("⚠️ Комментарий — это текст или фото с подписью. Напишите его или нажмите «Без комментария».")


# ============================== Мои работы ==============================
def _work_status(w: dict) -> str:
    if w["status"] == "pending":
        return "⏳ на проверке"
    return f"{w['grade']}/10 · {RESULT_NAMES.get(w['result'], '')} · +{w['points']}" + (" · 🏆" if w["best"] else "")


@router.callback_query(F.data == "mywk")
async def mywk(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    works = db.works_of_user(cb.from_user.id)
    if not works:
        await show(cb, "📤 Вы пока не сдавали работы.", kb([("🔙 Профиль", "prof")]))
        return
    rows = [[(f"#{w['id']} · задание #{w['task_id']} · {_work_status(w)}", f"mywv:{w['id']}")] for w in works]
    rows.append([("🔙 Профиль", "prof")])
    await show(cb, "📤 Мои работы:", kb(*rows))


@router.callback_query(F.data.startswith("mywv:"))
async def mywv(cb: CallbackQuery):
    w = db.get_work(int(cb.data.split(":")[1]))
    if not w or w["user_id"] != cb.from_user.id:
        await cb.answer("Работа не найдена.", show_alert=True)
        return
    text = f"📤 Работа #{w['id']} · задание #{w['task_id']}\nСтатус: {_work_status(w)}\n"
    if w["comment"]:
        text += f"Комментарий проверяющего: {w['comment']}\n"
    text += f"\n{work_body(w)}"
    if w.get("comment_photo"):
        await send_rich(cb.from_user.id, text[:3900], photo=w["comment_photo"], markup=kb([("🔙 Мои работы", "mywk")]))
    else:
        await show(cb, text, kb([("🔙 Мои работы", "mywk")]))


# ============================== Лучшая работа и опросы ==============================
@router.callback_query(F.data == "wbest")
async def wbest(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "works_review"):
        return
    await state.clear()
    tasks = db.tasks_with_works()
    rows = [[(f"#{t['id']} {preview(t['text'], 30)} · работ: {t['wcount']}", f"wbt:{t['id']}")] for t in tasks]
    if has_perm(cb.from_user.id, "polls_create"):
        rows.append([("🗳 Активные опросы", "wpl")])
    rows.append([("🔙 Назад", "sec:works")])
    await show(cb, "🏆 Лучшая работа и опросы\n\nВыберите задание:" if tasks else
               "🏆 Работ пока нет — выбирать не из чего.", kb(*rows))


async def _task_works_screen(cb: CallbackQuery, tid: int):
    t = db.get_task(tid)
    works = db.works_of_task(tid)
    if not t or not works:
        await cb.answer("По этому заданию нет работ.", show_alert=True)
        return
    lines = [f"🏆 Задание #{tid}: {preview(t['text'], 80)}\n"]
    rows = []
    for w in works:
        name = fmt_user(db.get_user(w["user_id"]))
        lines.append(f"{'🏆 ' if w['best'] else ''}#{w['id']} {name} — {_work_status(w)}")
        if not w["best"]:
            rows.append([(f"🏆 Выбрать лучшей: #{w['id']} {preview(name, 20)}", f"wbs:{w['id']}")])
    if len(works) >= 2 and has_perm(cb.from_user.id, "polls_create"):
        rows.append([("🗳 Создать опрос в группе", f"wpoll:{tid}")])
    rows.append([("🔙 Назад", "wbest")])
    await show(cb, "\n".join(lines), kb(*rows))


@router.callback_query(F.data.startswith("wbt:"))
async def wbt(cb: CallbackQuery):
    if not await need(cb, "works_review"):
        return
    await _task_works_screen(cb, int(cb.data.split(":")[1]))


async def _make_best(wid: int, reason_prefix: str = "лучшая работа") -> bool:
    w = db.get_work(wid)
    if not w or w["best"]:
        return False
    db.set_work(wid, best=1)
    bonus = int(db.get_setting("best_bonus", "5"))
    await award(w["user_id"], bonus, f"{reason_prefix} #{wid} 🏆")
    return True


@router.callback_query(F.data.startswith("wbs:"))
async def wbs(cb: CallbackQuery):
    if not await need(cb, "works_review"):
        return
    w = db.get_work(int(cb.data.split(":")[1]))
    if not w:
        await cb.answer("Работа не найдена.", show_alert=True)
        return
    if not await _make_best(w["id"]):
        await cb.answer("Эта работа уже выбрана лучшей.", show_alert=True)
        return
    await cb.answer("🏆 Лучшая работа выбрана, бонус начислен.")
    await _task_works_screen(cb, w["task_id"])


@router.callback_query(F.data.startswith("wpoll:"))
async def wpoll(cb: CallbackQuery):
    if not await need(cb, "polls_create"):
        return
    tid = int(cb.data.split(":")[1])
    chat, thread = db.place()
    if not chat:
        await cb.answer("Место публикации не задано. Раздел «Задания» → «Место публикации».", show_alert=True)
        return
    works = db.works_of_task(tid)[:10]
    if len(works) < 2:
        await cb.answer("Для опроса нужно минимум 2 работы.", show_alert=True)
        return
    bot = get_bot()
    try:
        await bot.send_message(chat, f"🗳 Голосуем за лучшую работу по заданию #{tid}!\nНиже — работы участников, затем опрос.",
                               message_thread_id=thread)
        options = []
        for i, w in enumerate(works, 1):
            name = fmt_user(db.get_user(w["user_id"]))
            await send_work(chat, w, thread=thread, title=clip(f"Работа {i} — {name}\n\n{work_body(w)}"),
                            attach=f"📎 Вложение к работе {i} — {name}")
            options.append(f"Работа {i} — {name}"[:100])
        poll = await bot.send_poll(chat, f"🏆 Лучшая работа по заданию #{tid}", options=options,
                                   is_anonymous=True, message_thread_id=thread)
    except TelegramAPIError as e:
        await show(cb, f"❌ Не удалось создать опрос: {err_text(e)}.\nПроверьте, что бот состоит в группе "
                       f"и может в ней писать.", kb([("🔙 Назад", f"wbt:{tid}")]))
        return
    pid = db.add_poll(tid, chat, thread, poll.message_id, [w["id"] for w in works])
    await show(cb, f"✅ Опрос #{pid} создан в группе. Когда голосование закончится, нажмите кнопку — "
                   f"победитель получит бонус.", kb([("🏁 Завершить опрос", f"wpe:{pid}")], [("🔙 Назад", f"wbt:{tid}")]))


@router.callback_query(F.data == "wpl")
async def wpl(cb: CallbackQuery):
    if not await need(cb, "polls_create"):
        return
    polls = db.open_polls()
    rows = [[(f"🏁 Опрос #{p['id']} · задание #{p['task_id']}", f"wpe:{p['id']}")] for p in polls]
    rows.append([("🔙 Назад", "wbest")])
    await show(cb, "🗳 Активные опросы:" if polls else "🗳 Активных опросов нет.", kb(*rows))


@router.callback_query(F.data.startswith("wpe:"))
async def wpe(cb: CallbackQuery):
    if not await need(cb, "polls_create"):
        return
    p = db.get_poll(int(cb.data.split(":")[1]))
    if not p or p["closed"]:
        await cb.answer("Опрос не найден или уже завершён.", show_alert=True)
        return
    back = kb([("🔙 К опросам", "wpl")])
    try:
        result = await get_bot().stop_poll(p["chat_id"], p["message_id"])
    except TelegramBadRequest as e:
        if is_gone(e) or "closed" in str(e).lower():
            db.set_poll(p["id"], closed=1)
        await show(cb, f"❌ Не удалось завершить опрос: {err_text(e)}", back)
        return
    except TelegramAPIError as e:
        await show(cb, f"❌ Ошибка Telegram при завершении опроса: {err_text(e)}", back)
        return
    db.set_poll(p["id"], closed=1)
    work_ids = db.jl(p["work_ids"])
    counts = [o.voter_count for o in result.options]
    top = max(counts) if counts else 0
    if top == 0:
        text = "🗳 Опрос завершён: никто не проголосовал, лучшая работа не выбрана."
    else:
        names = []
        for i, c in enumerate(counts):
            if c == top and i < len(work_ids):
                w = db.get_work(work_ids[i])
                if w:
                    await _make_best(w["id"], "победа в опросе, работа")
                    names.append(fmt_user(db.get_user(w["user_id"])))
        text = f"🏆 Опрос завершён. Побеждает: {', '.join(names)} (голосов: {top}). Бонус начислен."
    await safe_send(p["chat_id"], text, message_thread_id=p["thread"])
    await show(cb, text, back)


# ============================== Кураторы ==============================
@router.callback_query(F.data == "cur")
async def cur(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "perms_edit"):
        return
    await state.clear()
    cur_map = db.curators()
    rows = []
    for p in perms.POS_ORDER:
        uid = cur_map.get(p)
        rows.append([(f"{perms.POS_NAMES[p]}: {fmt_user(db.get_user(uid)) if uid else 'не назначен'}", f"curp:{p}")])
    rows.append([("🔙 Назад", "sec:works")])
    await show(cb, "🧑‍🏫 Кураторы должностей\n\nКуратору приходят работы по его должности "
                   "(владелец получает все работы).", kb(*rows))


@router.callback_query(F.data.startswith("curp:"))
async def curp(cb: CallbackQuery):
    if not await need(cb, "perms_edit"):
        return
    pos = cb.data.split(":")[1]
    staff = db.q("SELECT * FROM users WHERE role IN ('admin','owner') AND banned=0 ORDER BY role DESC, name")
    rows = [[(fmt_user(u), f"curs:{pos}:{u['id']}")] for u in staff[:40]]
    rows.append([("❌ Снять куратора", f"curx:{pos}")])
    rows.append([("🔙 Назад", "cur")])
    await show(cb, f"Выберите куратора для должности {perms.POS_NAMES.get(pos, pos)}:", kb(*rows))


@router.callback_query(F.data.startswith("curs:"))
async def curs(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "perms_edit"):
        return
    _, pos, uid = cb.data.split(":")
    u = db.get_user(int(uid))
    if pos not in perms.POS_NAMES or not u or u["role"] not in ("admin", "owner"):
        await cb.answer("Куратором можно назначить только админа или владельца.", show_alert=True)
        return
    db.set_curator(pos, u["id"])
    await notify(u["id"], f"🧑‍🏫 Вас назначили куратором должности {perms.POS_NAMES[pos]}. "
                          f"Вам будут приходить работы на проверку.")
    await cb.answer("Куратор назначен.")
    await cur(cb, state)


@router.callback_query(F.data.startswith("curx:"))
async def curx(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "perms_edit"):
        return
    db.del_curator(cb.data.split(":")[1])
    await cb.answer("Куратор снят.")
    await cur(cb, state)


# ============================== Формы выполнения ==============================
def _forms_screen(scope: str, uid: int):
    if scope == "c":
        forms = db.list_forms(None, True)
        title, back = "📝 Общие формы (видны всем)", ("🔙 Назад", "sec:works")
    else:
        forms = db.list_forms(uid, False)
        title, back = "📝 Мои личные формы (видны только вам)", ("🔙 Профиль", "prof")
    rows = [[("➕ Создать форму", f"fadd:{scope}")]]
    for f in forms[:40]:
        rows.append([(f"📝 {preview(f['title'], 35)} · вопросов: {len(db.jl(f['questions']))}", f"fv:{f['id']}")])
    rows.append([back])
    return (title if forms else title + "\n\nПока пусто."), kb(*rows)


@router.callback_query(F.data == "fman")
async def fman(cb: CallbackQuery, state: FSMContext):
    if not await need(cb, "forms_edit"):
        return
    await state.clear()
    text, markup = _forms_screen("c", cb.from_user.id)
    await show(cb, text, markup)


@router.callback_query(F.data == "myforms")
async def myforms(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    text, markup = _forms_screen("p", cb.from_user.id)
    await show(cb, text, markup)


def _can_edit_form(uid: int, form: dict) -> bool:
    return has_perm(uid, "forms_edit") if form["owner_id"] is None else form["owner_id"] == uid


async def _form_card(cb: CallbackQuery, fid: int) -> None:
    form = db.get_form(fid)
    if not form:
        await cb.answer("Форма не найдена.", show_alert=True)
        return
    if not _can_edit_form(cb.from_user.id, form):
        await cb.answer("⛔ Нет разрешения на эту форму.", show_alert=True)
        return
    qs = db.jl(form["questions"])
    back = "fman" if form["owner_id"] is None else "myforms"
    rows = [[("✏️ Название", f"fet:{fid}"), ("➕ Вопрос", f"feq:{fid}")]]
    if len(qs) > 1:
        rows.append([("🗑 Удалить вопрос", f"fqd:{fid}")])
    rows.append([("🗑 Удалить форму", f"fdel:{fid}")])
    rows.append([("🔙 Назад", back)])
    await show(cb, f"📝 «{form['title']}»\n\n" + "\n".join(f"{i}. {q}" for i, q in enumerate(qs, 1)), kb(*rows))


@router.callback_query(F.data.startswith("fv:"))
async def fv(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await _form_card(cb, int(cb.data.split(":")[1]))


class FormEdit(StatesGroup):
    title = State()
    question = State()


async def _form_for_edit(cb: CallbackQuery, fid: int):
    form = db.get_form(fid)
    if not form:
        await cb.answer("Форма не найдена.", show_alert=True)
        return None
    if not _can_edit_form(cb.from_user.id, form):
        await cb.answer("⛔ Нет разрешения на эту форму.", show_alert=True)
        return None
    return form


@router.callback_query(F.data.startswith("fet:"))
async def fet(cb: CallbackQuery, state: FSMContext):
    form = await _form_for_edit(cb, int(cb.data.split(":")[1]))
    if form:
        await state.set_data({"fid": form["id"]})
        await state.set_state(FormEdit.title)
        await show(cb, f"✏️ Сейчас: «{form['title']}»\n\nВведите новое название:", kb([("↩️ Отмена", f"fv:{form['id']}")]))


@router.callback_query(F.data.startswith("feq:"))
async def feq(cb: CallbackQuery, state: FSMContext):
    form = await _form_for_edit(cb, int(cb.data.split(":")[1]))
    if not form:
        return
    if len(db.jl(form["questions"])) >= 20:
        await cb.answer("В форме уже 20 вопросов — это максимум.", show_alert=True)
        return
    await state.set_data({"fid": form["id"]})
    await state.set_state(FormEdit.question)
    await show(cb, "➕ Отправьте текст нового вопроса (он добавится в конец формы):", kb([("↩️ Отмена", f"fv:{form['id']}")]))


@router.message(FormEdit.title, F.text)
async def fet_text(m: Message, state: FSMContext):
    fid = (await state.get_data()).get("fid")
    form = db.get_form(fid) if fid else None
    if not form or not _can_edit_form(m.from_user.id, form):
        await state.clear()
        await m.answer("⚠️ Форма недоступна или удалена.")
        return
    db.update("forms", fid, title=m.text.strip()[:100])
    await state.clear()
    await m.answer("✅ Название изменено.", reply_markup=kb([("📝 К форме", f"fv:{fid}")]))


@router.message(FormEdit.question, F.text)
async def feq_text(m: Message, state: FSMContext):
    fid = (await state.get_data()).get("fid")
    form = db.get_form(fid) if fid else None
    if not form or not _can_edit_form(m.from_user.id, form):
        await state.clear()
        await m.answer("⚠️ Форма недоступна или удалена.")
        return
    qs = db.jl(form["questions"]) + [m.text.strip()[:300]]
    db.update("forms", fid, questions=json.dumps(qs, ensure_ascii=False))
    await state.clear()
    await m.answer(f"✅ Вопрос добавлен (теперь их {len(qs)}).", reply_markup=kb([("📝 К форме", f"fv:{fid}")]))


@router.message(FormEdit.title)
@router.message(FormEdit.question)
async def form_edit_bad(m: Message):
    await m.answer("⚠️ Нужен текст. Попробуйте ещё раз или отправьте /cancel.")


@router.callback_query(F.data.startswith("fqd:"))
async def fqd(cb: CallbackQuery):
    form = await _form_for_edit(cb, int(cb.data.split(":")[1]))
    if not form:
        return
    qs = db.jl(form["questions"])
    rows = [[(f"🗑 {i}. {preview(q, 40)}", f"fqx:{form['id']}:{i - 1}")] for i, q in enumerate(qs, 1)]
    rows.append([("🔙 Назад", f"fv:{form['id']}")])
    await show(cb, "🗑 Какой вопрос удалить?", kb(*rows))


@router.callback_query(F.data.startswith("fqx:"))
async def fqx(cb: CallbackQuery):
    _, fid, idx = cb.data.split(":")
    form = await _form_for_edit(cb, int(fid))
    if not form:
        return
    qs = db.jl(form["questions"])
    if len(qs) <= 1 or not 0 <= int(idx) < len(qs):
        await cb.answer("В форме должен остаться хотя бы один вопрос.", show_alert=True)
        return
    qs.pop(int(idx))
    db.update("forms", form["id"], questions=json.dumps(qs, ensure_ascii=False))
    await cb.answer("Вопрос удалён.")
    await _form_card(cb, form["id"])


@router.callback_query(F.data.startswith("fdel:"))
async def fdel(cb: CallbackQuery):
    form = db.get_form(int(cb.data.split(":")[1]))
    if not form:
        await cb.answer("Форма уже удалена.", show_alert=True)
        return
    if not _can_edit_form(cb.from_user.id, form):
        await cb.answer("⛔ Нет разрешения на эту форму.", show_alert=True)
        return
    db.del_form(form["id"])
    await cb.answer("Форма удалена.")
    text, markup = _forms_screen("c" if form["owner_id"] is None else "p", cb.from_user.id)
    await show(cb, text, markup)


@router.callback_query(F.data.startswith("fadd:"))
async def fadd(cb: CallbackQuery, state: FSMContext):
    scope = cb.data.split(":")[1]
    if scope == "c" and not await need(cb, "forms_edit"):
        return
    await state.set_data({"scope": scope, "questions": []})
    await state.set_state(FormNew.title)
    await show(cb, "✏️ Введите название формы:", kb([("↩️ Отмена", "fman" if scope == "c" else "myforms")]))


@router.message(FormNew.title, F.text)
async def form_title(m: Message, state: FSMContext):
    await state.update_data(title=m.text.strip()[:100])
    await state.set_state(FormNew.questions)
    await m.answer("Отправляйте вопросы по одному сообщению. Когда закончите — нажмите «✅ Готово».",
                   reply_markup=kb([("✅ Готово", "fdone")]))


@router.message(FormNew.questions, F.text)
async def form_question(m: Message, state: FSMContext):
    d = await state.get_data()
    qs = d["questions"]
    if len(qs) >= 20:
        await m.answer("⚠️ Максимум 20 вопросов. Нажмите «✅ Готово».", reply_markup=kb([("✅ Готово", "fdone")]))
        return
    qs.append(m.text.strip()[:300])
    await state.update_data(questions=qs)
    await m.answer(f"➕ Вопрос {len(qs)} добавлен. Ещё один или «✅ Готово».", reply_markup=kb([("✅ Готово", "fdone")]))


@router.message(FormNew.title)
@router.message(FormNew.questions)
async def form_bad(m: Message):
    await m.answer("⚠️ Нужен текст. Отправьте название или вопрос текстом.")


@router.callback_query(F.data == "fdone")
async def fdone(cb: CallbackQuery, state: FSMContext):
    d = await state.get_data()
    if "scope" not in d or not d.get("title"):
        await cb.answer("Сессия создания формы устарела.", show_alert=True)
        return
    if not d["questions"]:
        await cb.answer("Добавьте хотя бы один вопрос.", show_alert=True)
        return
    if d["scope"] == "c" and not await need(cb, "forms_edit"):
        return
    db.add_form(d["title"], d["questions"], None if d["scope"] == "c" else cb.from_user.id)
    await state.clear()
    text, markup = _forms_screen(d["scope"], cb.from_user.id)
    await show(cb, "✅ Форма сохранена.\n\n" + text, markup)
